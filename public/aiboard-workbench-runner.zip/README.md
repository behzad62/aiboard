# AI Board WorkBench runner bundle

This bundle includes the Bench Runner and its managed Runner V2 source.

## Prerequisites

- Node.js 24.x
- Git installed and available on PATH

## Install and start

1. Extract `aiboard-workbench-runner.zip`.
2. Open PowerShell in the extracted directory.
3. Install Runner V2 and its Chromium browser:

   ```powershell
   Set-Location .\aiboard-runner-v2
   npm install
   npm run setup:browser
   Set-Location ..
   ```

4. Start the Bench Runner:

   ```powershell
   node .\bench-runner.mjs
   ```

The startup banner prints the localhost URL, token, and managed Runner V2 readiness.
Paste the URL and token into Benchmark -> WorkBench. Keep both bundled paths together
so the Bench Runner can discover `aiboard-runner-v2` automatically.
