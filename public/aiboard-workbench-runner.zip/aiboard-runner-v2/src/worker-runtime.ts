import type {
  AgentMessage,
  AgentModel,
} from "./agent-contracts.js";
import type { AcceptanceCriterion } from "./acceptance-contracts.js";
import {
  runAgentLoop,
  type AgentLoopResult,
  type RunAgentLoopOptions,
} from "./agent-loop.js";
import type { ArtifactStore } from "./artifact-store.js";
import { createArtifactTools } from "./artifact-tools.js";
import type { BudgetLedger } from "./budget-ledger.js";
import { BudgetedToolRuntime } from "./budgeted-tool-runtime.js";
import { createBrowserTools, type BrowserBackend } from "./browser-tools.js";
import type { CapabilityRegistry } from "./capability-registry.js";
import { createCodeIntelligenceTools } from "./code-intelligence-tools.js";
import {
  createChangeSet,
  type ChangeSet,
  type ExternalEffectReference,
} from "./change-set.js";
import type { PermissionProfile } from "./contracts.js";
import { createEvidenceTools } from "./evidence-tools.js";
import { evidenceFactArtifactHashes, type EvidenceStore } from "./evidence-store.js";
import { createFilesystemTools } from "./filesystem-tools.js";
import { createGitTools } from "./git-tools.js";
import { createProcessTools } from "./process-tools.js";
import { createResearchTools } from "./research-tools.js";
import { RepositoryIntelligence } from "./repository-intelligence.js";
import { createSessionTools } from "./session-tools.js";
import type { SqliteAgentSessionStore } from "./sqlite-agent-session-store.js";
import type { SchedulerStore } from "./scheduler-store.js";
import { rebuildSchedulerProjection } from "./scheduler-store.js";
import type { SkillCatalog } from "./skill-catalog.js";
import { createSkillTools } from "./skill-tools.js";
import { createSubagentTools } from "./subagent-tools.js";
import type { ProjectMemoryStore } from "./project-memory.js";
import { rebuildProjectMemories } from "./project-memory.js";
import { createMemoryTools } from "./memory-tools.js";
import { createMcpTools, type McpManager } from "./mcp-tools.js";
import type { SqlitePermissionStore } from "./permission-store.js";
import type { ManagedProcessService } from "./managed-process.js";
import { createManagedProcessTools } from "./managed-process-tools.js";
import { ToolBroker } from "./tool-broker.js";
import { TypeScriptIntelligence } from "./typescript-intelligence.js";
import type { LanguageIntelligenceProvider } from "./language-intelligence.js";
import type { OneShotCommandExecutor } from "./one-shot-command-executor.js";
import type { ExecutionGrantAuthority } from "./execution-grants.js";
import { registerExtensionCapabilities } from "./extension-runtime.js";
import type {
  ToolInvocationLedger,
  ToolLedgerEvent,
} from "./tool-ledger.js";
import type {
  TaskWorkspace,
  TaskCommit,
  WorkspaceManager,
} from "./workspace-manager.js";
import { NoTaskChangesError } from "./workspace-manager.js";
import {
  createSubmitTaskTool,
  createWorkerLifecycleTools,
} from "./worker-lifecycle-tools.js";

export interface RunWorkerTaskOptions {
  model: AgentModel;
  subagentModelForSession?: (sessionId: string) => AgentModel;
  runId: string;
  sessionId: string;
  taskId: string;
  acceptanceCriteria?: readonly AcceptanceCriterion[];
  acceptanceCriteriaVersion?: number;
  attempt?: number;
  actorId: string;
  permissionProfile: PermissionProfile;
  workspace: TaskWorkspace;
  workspaceManager: WorkspaceManager;
  artifacts: ArtifactStore;
  ledger: ToolInvocationLedger;
  sessions: SqliteAgentSessionStore;
  schedulerStore?: SchedulerStore;
  evidenceStore?: EvidenceStore;
  skillCatalog?: SkillCatalog;
  memoryStore?: ProjectMemoryStore;
  projectId?: string;
  continuationMessages?: readonly AgentMessage[];
  initialMessages: readonly AgentMessage[];
  clock?: () => string;
  browserBackend?: BrowserBackend;
  mcpManager?: McpManager;
  permissions?: SqlitePermissionStore;
  managedProcesses?: ManagedProcessService;
  budgetLedger?: BudgetLedger;
  capabilityRegistry?: CapabilityRegistry;
  language?: LanguageIntelligenceProvider;
  allowedCommands?: readonly string[];
  hiddenPaths?: readonly string[];
  protectedPaths?: readonly string[];
  providerRetry?: RunAgentLoopOptions["providerRetry"];
  signal?: AbortSignal;
  execution?: OneShotCommandExecutor;
  executionGrants?: ExecutionGrantAuthority;
}

export interface WorkerTaskResult {
  loop: AgentLoopResult;
  changeSet?: ChangeSet;
}

export async function runWorkerTask(
  options: RunWorkerTaskOptions
): Promise<WorkerTaskResult> {
  const clock = options.clock ?? (() => new Date().toISOString());
  const schedulerProjection = schedulerState(options);
  const taskContract = schedulerProjection?.tasks[options.taskId];
  const acceptanceCriteria = options.acceptanceCriteria ?? taskContract?.acceptanceCriteria;
  const attempt = options.attempt ?? taskContract?.attempt;
  let messages = [...options.initialMessages];
  if (options.sessions.events(options.sessionId).length === 0) {
    await options.sessions.create({
      sessionId: options.sessionId,
      runId: options.runId,
      actor: { role: "worker", id: options.actorId },
      occurredAt: clock(),
    });
  } else {
    const recovered = await options.sessions.load(options.sessionId);
    if (recovered.checkpoint) messages = [...recovered.checkpoint.messages];
    if (recovered.status === "submitted" && recovered.changeSet) {
      return {
        loop: {
          status: "submitted",
          changeSetId: recovered.changeSet.id,
          turns: recovered.checkpoint?.turns ?? 0,
          messages,
        },
        changeSet: recovered.changeSet,
      };
    }
  }
  if (options.continuationMessages) {
    const existingIds = new Set(messages.map((message) => message.id));
    messages.push(
      ...options.continuationMessages.filter(
        (message) => !existingIds.has(message.id)
      )
    );
  }

  const broker = new ToolBroker({
    permissionProfile: options.permissionProfile,
    workspacePath: options.workspace.path,
    artifacts: options.artifacts,
    ledger: options.ledger,
    ...(options.permissions
      ? { approve: (request) => options.permissions!.requestTool(request) }
      : {}),
    ...(options.executionGrants ? { executionGrants: options.executionGrants } : {}),
  });
  const repository = new RepositoryIntelligence();
  const language = options.language ?? new TypeScriptIntelligence(repository);
  for (const tool of createFilesystemTools({
    artifacts: options.artifacts,
    repository,
    diagnostics: language,
    ...(options.hiddenPaths ? { hiddenPaths: options.hiddenPaths } : {}),
    ...(options.protectedPaths ? { protectedPaths: options.protectedPaths } : {}),
  })) {
    broker.register(tool);
  }
  for (const tool of createCodeIntelligenceTools({
    repository,
    language,
  })) {
    broker.register(tool);
  }
  for (const tool of createArtifactTools(options.artifacts)) broker.register(tool);
  for (const tool of createSessionTools(options.sessions)) broker.register(tool);
  for (const tool of createProcessTools({
    ...(options.execution ? { execution: options.execution } : {}),
    ...(options.allowedCommands
      ? { allowedCommands: options.allowedCommands }
      : {}),
  })) broker.register(tool);
  if (options.managedProcesses) {
    for (const tool of createManagedProcessTools(options.managedProcesses)) {
      broker.register(tool);
    }
  }
  for (const tool of createResearchTools({ artifacts: options.artifacts })) {
    broker.register(tool);
  }
  if (options.browserBackend) {
    for (const tool of createBrowserTools({
      backend: options.browserBackend,
      artifacts: options.artifacts,
      ...(options.evidenceStore ? { evidenceStore: options.evidenceStore } : {}),
      taskId: options.taskId,
      ...(attempt !== undefined ? { attempt } : {}),
      clock,
      ...(options.allowedCommands
        ? { allowedCommands: options.allowedCommands }
        : {}),
    })) broker.register(tool);
  }
  if (options.mcpManager) {
    for (const tool of createMcpTools(options.mcpManager, options.artifacts)) {
      broker.register(tool);
    }
  }
  for (const tool of createGitTools()) broker.register(tool);
  if (options.evidenceStore) {
    for (const tool of createEvidenceTools({
      store: options.evidenceStore,
      artifacts: options.artifacts,
      taskId: options.taskId,
      ...(options.execution ? { execution: options.execution } : {}),
      clock,
      ...(attempt !== undefined ? { attempt } : {}),
      ...(options.allowedCommands ? { allowedCommands: options.allowedCommands } : {}),
    })) broker.register(tool);
  }
  if (options.skillCatalog) {
    for (const tool of createSkillTools(options.skillCatalog)) broker.register(tool);
  }
  if (options.memoryStore && options.projectId) {
    for (const tool of createMemoryTools({
      store: options.memoryStore,
      projectId: options.projectId,
      runId: options.runId,
      taskId: options.taskId,
      clock,
    })) broker.register(tool);
  }
  if (options.schedulerStore) {
    for (const tool of createWorkerLifecycleTools({
      store: options.schedulerStore,
      taskId: options.taskId,
      clock,
    })) broker.register(tool);
  }
  for (const tool of createSubagentTools({
    model: options.model,
    ...(options.subagentModelForSession
      ? { subagentModelForSession: options.subagentModelForSession }
      : {}),
    runId: options.runId,
    parentSessionId: options.sessionId,
    taskId: options.taskId,
    ...(attempt !== undefined ? { attempt } : {}),
    parentActorId: options.actorId,
    permissionProfile: options.permissionProfile,
    workspacePath: options.workspace.path,
    artifacts: options.artifacts,
    ledger: options.ledger,
    sessions: options.sessions,
    ...(options.budgetLedger ? { budgetLedger: options.budgetLedger } : {}),
    ...(options.evidenceStore ? { evidenceStore: options.evidenceStore } : {}),
    ...(options.skillCatalog ? { skillCatalog: options.skillCatalog } : {}),
    ...(options.memoryStore ? { memoryStore: options.memoryStore } : {}),
    ...(options.projectId ? { projectId: options.projectId } : {}),
    ...(options.clock ? { clock: options.clock } : {}),
    ...(options.browserBackend ? { browserBackend: options.browserBackend } : {}),
    ...(options.mcpManager ? { mcpManager: options.mcpManager } : {}),
    ...(options.permissions ? { permissions: options.permissions } : {}),
    ...(options.managedProcesses
      ? { managedProcesses: options.managedProcesses }
      : {}),
    ...(options.allowedCommands
      ? { allowedCommands: options.allowedCommands }
      : {}),
    ...(options.hiddenPaths ? { hiddenPaths: options.hiddenPaths } : {}),
    ...(options.protectedPaths ? { protectedPaths: options.protectedPaths } : {}),
    ...(options.execution ? { execution: options.execution } : {}),
    ...(options.executionGrants ? { executionGrants: options.executionGrants } : {}),
    language,
  })) broker.register(tool);

  let producedChangeSet: ChangeSet | undefined;
  broker.register(createSubmitTaskTool(async ({
    summary,
    unresolvedConcerns,
    criterionEvidenceLinks,
  }) => {
    if (
      schedulerState(options)?.acceptanceContractStatus ===
      "acceptance_contract_upgrade_required"
    ) {
      throw new Error(
        "Task submission is blocked until the Architect upgrades the acceptance contract."
      );
    }
    const evidenceRecords = options.evidenceStore
      ? acceptanceCriteria
        ? options.evidenceStore.getByIds({
            runId: options.runId,
            taskId: options.taskId,
            ids: [...new Set((criterionEvidenceLinks ?? []).map((link) => link.evidenceId))],
          })
        : options.evidenceStore.list({
            runId: options.runId,
            taskId: options.taskId,
            limit: 1_000,
          })
      : [];
    const evidenceHashes = evidenceArtifactHashes(
      evidenceRecords,
      options.actorId,
      attempt
    );
    if (!acceptanceCriteria && evidenceHashes.length === 0) {
      throw new Error(
        "Task submission requires durable evidence; record command or browser facts first."
      );
    }
    let commit: TaskCommit;
    try {
      commit = await options.workspaceManager.commitWorkspace(
        options.workspace,
        summary
      );
    } catch (error) {
      if (!(error instanceof NoTaskChangesError)) throw error;
      commit = {
        runId: options.runId,
        taskId: options.taskId,
        revision: options.workspace.baselineRevision,
        baselineRevision: options.workspace.baselineRevision,
        commits: [],
        changedPaths: [],
      };
    }
    producedChangeSet = await createChangeSet({
      workspacePath: options.workspace.path,
      taskCommit: commit,
      artifacts: options.artifacts,
      ...(acceptanceCriteria
        ? {
            acceptanceCriteria,
            ...(options.acceptanceCriteriaVersion ?? taskContract?.acceptanceCriteriaVersion) !== undefined
              ? {
                  acceptanceCriteriaVersion:
                    options.acceptanceCriteriaVersion ?? taskContract?.acceptanceCriteriaVersion,
                }
              : {},
            criterionEvidenceLinks,
            evidenceRecords,
            taskId: options.taskId,
            attempt,
            assignedWorkerId: options.actorId,
          }
        : { evidenceArtifactHashes: evidenceHashes }),
      externalEffects: externalEffectReferences(
        options.ledger.listRun(options.runId),
        options.sessionId
      ),
      guidanceIds: taskGuidanceIds(options),
      memoryIds: taskMemoryIds(options),
      unresolvedConcerns,
    });
    return producedChangeSet;
  }, { requireCriterionEvidenceLinks: acceptanceCriteria !== undefined }));
  if (options.capabilityRegistry) {
    registerExtensionCapabilities(options.capabilityRegistry, broker);
  }

  const toolRuntime = options.budgetLedger
    ? new BudgetedToolRuntime({
        runtime: broker,
        ledger: options.budgetLedger,
        scopeId: options.runId,
        clock,
      })
    : broker;
  const loop = await runAgentLoop({
    model: options.model,
    registry: toolRuntime,
    context: {
      runId: options.runId,
      sessionId: options.sessionId,
      actor: { role: "worker", id: options.actorId },
      workspacePath: options.workspace.path,
      signal: options.signal,
    },
    initialMessages: messages,
    signal: options.signal,
    ...(options.providerRetry ? { providerRetry: options.providerRetry } : {}),
    onCheckpoint: async (checkpoint) => {
      await options.sessions.checkpoint(options.sessionId, checkpoint, clock());
    },
  });

  if (loop.status === "submitted") {
    producedChangeSet ??= changeSetFromMessages(loop.messages, loop.changeSetId);
    if (!producedChangeSet) {
      throw new Error(`Submitted change set ${loop.changeSetId} is unavailable.`);
    }
    await options.sessions.submit(options.sessionId, producedChangeSet, clock());
  } else if (loop.status === "suspended") {
    options.sessions.suspend(
      options.sessionId,
      loop.reason,
      loop.error,
      clock()
    );
  } else if (loop.status === "waiting_for_architect") {
    options.sessions.suspend(
      options.sessionId,
      "waiting_for_architect",
      loop.requestId,
      clock()
    );
  }
  return { loop, ...(producedChangeSet ? { changeSet: producedChangeSet } : {}) };
}

export function externalEffectReferences(
  events: readonly ToolLedgerEvent[],
  sessionId: string
): ExternalEffectReference[] {
  const started = new Map<string, ToolLedgerEvent>();
  const effects: ExternalEffectReference[] = [];
  for (const event of events) {
    if (event.sessionId !== sessionId) continue;
    if (event.type === "tool.started" || event.type === "tool.retry_started") {
      started.set(event.key, event);
      continue;
    }
    const origin = started.get(event.key);
    if (!origin) continue;
    const external =
      origin.effect === "external" ||
      origin.access?.external === true ||
      origin.access?.credentialChange === true ||
      origin.outsideWorkspace === true;
    if (!external) continue;
    const artifactHash = event.result?.content.find(
      (block) => block.type === "artifact"
    );
    effects.push({
      kind: origin.access?.capability ?? origin.toolName ?? "external",
      idempotencyKey: origin.key,
      ...(artifactHash?.type === "artifact"
        ? { artifactHash: artifactHash.hash }
        : {}),
    });
  }
  return effects;
}

function taskGuidanceIds(options: RunWorkerTaskOptions): string[] {
  if (!options.schedulerStore) return [];
  const projection = rebuildSchedulerProjection(
    options.schedulerStore.readRun(options.runId)
  );
  return Object.values(projection.guidance)
    .filter((guidance) => guidance.taskId === options.taskId)
    .map((guidance) => guidance.requestId);
}

function taskMemoryIds(options: RunWorkerTaskOptions): string[] {
  if (!options.memoryStore || !options.projectId) return [];
  return [...rebuildProjectMemories(
    options.memoryStore.events(options.projectId)
  ).values()]
    .filter(
      (memory) =>
        memory.runId === options.runId &&
        memory.taskId === options.taskId
    )
    .map((memory) => memory.id);
}

function evidenceArtifactHashes(
  records: ReturnType<EvidenceStore["list"]>,
  actorId: string,
  attempt?: number
): string[] {
  return [
    ...new Set(
      records
        .filter(
          (record) =>
            record.actor.id === actorId ||
            (record.actor.role === "subagent" &&
              record.actor.id.startsWith(`${actorId}:`))
        )
        .filter((record) =>
          attempt === undefined ||
          record.attempt === undefined ||
          record.attempt === attempt
        )
        .flatMap((record) => evidenceFactArtifactHashes(record.fact))
    ),
  ];
}

function schedulerState(options: RunWorkerTaskOptions) {
  if (!options.schedulerStore) return undefined;
  const events = options.schedulerStore.readRun(options.runId);
  if (events.length === 0) return undefined;
  return rebuildSchedulerProjection(events);
}

function changeSetFromMessages(
  messages: readonly AgentMessage[],
  changeSetId: string
): ChangeSet | undefined {
  for (const message of [...messages].reverse()) {
    if (
      message.role !== "tool" ||
      typeof message.content !== "object" ||
      Array.isArray(message.content)
    ) {
      continue;
    }
    for (const block of message.content.content) {
      if (
        block.type === "json" &&
        typeof block.value === "object" &&
        block.value !== null &&
        (block.value as { id?: unknown }).id === changeSetId
      ) {
        return block.value as ChangeSet;
      }
    }
  }
  return undefined;
}
