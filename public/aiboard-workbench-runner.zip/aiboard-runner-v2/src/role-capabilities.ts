import { EXTENSION_MANAGEMENT_TOOL_NAMES } from "./extension-management-tools.js";
import type { ToolEffect } from "./agent-contracts.js";

/**
 * Explicit per-role tool allow-lists. A1 records the static surfaces and
 * admits against them. Server-named MCP tools are not static entries;
 * `mcpPolicy` admits that dynamic group. A2 limits the Architect to the
 * read-only MCP class. A3 adds `run_evidence_command` for the Architect
 * inspection surface and the verifier verdict surface. The Architect tool is
 * optional: it is registered only when a disposable copy exists.
 */
export type RoleCapabilityRole = "architect" | "verifier" | "plan-critic" | "worker";

export type RoleCapabilityBroker = "inspection" | "planOnly" | "expectations" | "coverage" | "answer" | "delivery_obligations" | "delivery" | "delivery_commands" | "task";

/**
 * `all` registers every MCP tool the manager exposes (the worker).
 * `none` registers none (verifier and plan critic).
 * `read-only-class` admits a tool only when `readOnly === true`,
 * `effect === "external"`, and the name is an MCP tool name. That is the
 * shape `createMcpTools` produces for `readOnlyHint === true &&
 * destructiveHint === false`.
 * `read-only-non-workspace` is the pre-A2 Plan-only predicate
 * `readOnly && effect !== "workspace"`. It admits a read-only MCP definition
 * whose effect is `none`, which the class refuses, so no surface selects it.
 */
export type McpPolicy = "all" | "none" | "read-only-class" | "read-only-non-workspace";

export interface RoleToolSurface {
  readonly role: RoleCapabilityRole;
  readonly broker: RoleCapabilityBroker;
  /** Sorted static tools that are always registered for this broker. */
  readonly tools: readonly string[];
  /** Sorted static tools registered only when their dependency is configured. */
  readonly optionalTools: readonly string[];
  readonly mcpPolicy: McpPolicy;
}

export const ROLE_CAPABILITY_BROKERS = [
  { role: "architect", broker: "inspection" },
  { role: "architect", broker: "planOnly" },
  { role: "verifier", broker: "inspection" },
  { role: "verifier", broker: "expectations" },
  { role: "verifier", broker: "coverage" },
  { role: "verifier", broker: "answer" },
  { role: "verifier", broker: "delivery_obligations" },
  { role: "verifier", broker: "delivery" },
  { role: "verifier", broker: "delivery_commands" },
  { role: "plan-critic", broker: "inspection" },
  { role: "worker", broker: "task" },
] as const satisfies readonly { role: RoleCapabilityRole; broker: RoleCapabilityBroker }[];

/**
 * Background processes for the verifiers that may run commands: they start the built product in
 * their own checkout and exercise it live. Tunnel run: a verifier limited to run-to-exit commands
 * could not start the relay, so the documented pair/connect/call workflow was never run end to end.
 * Registered only when the runner wires a managed-process service.
 */
const VERIFIER_LIVE_PROCESS_TOOLS = [
  "process.list",
  "process.poll",
  "process.read_output",
  "process.signal",
  "process.start",
  "process.write_stdin",
] as const;

const ARCHITECT_INSPECTION_BROWSER_TOOLS = [
  "browser.click",
  "browser.close",
  "browser.drag",
  "browser.events",
  "browser.fill",
  "browser.navigate",
  "browser.open",
  "browser.screenshot",
  "browser.snapshot",
  "browser.wheel",
] as const;

const ARCHITECT_PLAN_ONLY_BROWSER_TOOLS = [
  "browser.events",
  "browser.navigate",
  "browser.open",
  "browser.screenshot",
  "browser.snapshot",
] as const;

const SURFACES: Readonly<Record<string, RoleToolSurface>> = {
  "architect:inspection": surface("architect", "inspection", "read-only-class", [
    "image.inspect",
    "archive_project_memory",
    "artifact.read",
    "code.definition",
    "code.diagnostics",
    "code.references",
    "code.workspace_symbols",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.remotes",
    "git.show",
    "git.status",
    "inspect_evidence",
    "list_memory_proposals",
    "list_skills",
    "promote_project_memory",
    "propose_project_memory",
    "read_skill",
    "recall_project_memory",
    "repo.manifest",
    "repo.map",
    "research.fetch",
    "search_session_history",
  ], [...ARCHITECT_INSPECTION_BROWSER_TOOLS, ...EXTENSION_MANAGEMENT_TOOL_NAMES, "record_external_blocker", "record_repair_approach_decision", "run_evidence_command"]),
  "architect:planOnly": surface("architect", "planOnly", "read-only-class", [
    "image.inspect",
    "artifact.read",
    "code.definition",
    "code.diagnostics",
    "code.references",
    "code.workspace_symbols",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.remotes",
    "git.show",
    "git.status",
    "inspect_evidence",
    "list_memory_proposals",
    "list_skills",
    "read_skill",
    "recall_project_memory",
    "repo.manifest",
    "repo.map",
    "research.fetch",
    "search_session_history",
  ], [...ARCHITECT_PLAN_ONLY_BROWSER_TOOLS, "record_external_blocker", "record_repair_approach_decision"]),
  "verifier:inspection": surface("verifier", "inspection", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.show",
    "git.status",
    "inspect_evidence",
    "run_evidence_command",
  ], [...VERIFIER_LIVE_PROCESS_TOOLS, "submit_verifier_verdict"]),
  "verifier:expectations": surface("verifier", "expectations", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.status",
    "inspect_evidence",
    "record_verification_expectations",
  ], []),
  // T3b (OA-1) repair cycle 1 (B2): the independent source-coverage
  // reviewer. Read-only inspection only: no run_evidence_command, no process
  // control, no filesystem mutation, no MCP. The blind deriving pass
  // registers record_coverage_obligations, the re-review own-view pass
  // record_coverage_correction_view, the verdict pass submit_coverage_verdict
  // — each pass registers exactly one of the three optional tools.
  "verifier:coverage": surface("verifier", "coverage", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.show",
    "git.status",
    "inspect_evidence",
  ], ["record_coverage_correction_view", "record_coverage_obligations", "submit_coverage_verdict"]),
  // T9 (OA-5/OA-10 #2): the opt-in independent answer reviewer. Read-only
  // inspection only: no run_evidence_command, no process control, no
  // filesystem mutation, no MCP. The findings pass registers
  // record_answer_review_findings, the verdict pass
  // submit_answer_review_verdict — each pass registers exactly one.
  "verifier:answer": surface("verifier", "answer", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.show",
    "git.status",
    "inspect_evidence",
  ], ["record_answer_review_findings", "submit_answer_review_verdict"]),
  // T6a (OA-3/OA-4/OA-10): the mandatory deliverable reviewer, one broker per
  // kernel-ordered pass. The high-tier obligations pass sees criteria only and
  // has no inspection tools. The findings pass inspects the task-revision
  // checkout read-only; at high tier it may also run audited evidence
  // commands and, like the final verifier, run the product live in its own
  // checkout. The verdict pass is read-only. No filesystem mutation or MCP;
  // each pass registers exactly one optional lifecycle tool.
  "verifier:delivery_obligations": surface("verifier", "delivery_obligations", "none", [], [
    "record_deliverable_obligations",
  ]),
  "verifier:delivery": surface("verifier", "delivery", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.show",
    "git.status",
    "inspect_evidence",
  ], ["record_deliverable_findings", "submit_deliverable_verdict"]),
  "verifier:delivery_commands": surface("verifier", "delivery_commands", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.show",
    "git.status",
    "inspect_evidence",
    "run_evidence_command",
  ], [...VERIFIER_LIVE_PROCESS_TOOLS, "record_deliverable_findings"]),
  "plan-critic:inspection": surface("plan-critic", "inspection", "none", [
    "artifact.read",
    "fs.list",
    "fs.read",
    "fs.search",
    "fs.stat",
    "git.diff",
    "git.log",
    "git.show",
    "git.status",
    "submit_plan_critique",
  ], []),
  "worker:task": surface("worker", "task", "all", [
    "image.inspect",
    "artifact.read",
    "code.definition",
    "code.diagnostics",
    "code.references",
    "code.workspace_symbols",
    "fs.delete",
    "fs.list",
    "fs.move",
    "fs.patch",
    "fs.read",
    "fs.search",
    "fs.stat",
    "fs.write",
    "git.commit",
    "git.diff",
    "git.log",
    "git.push",
    "git.remotes",
    "git.show",
    "git.status",
    "process.run",
    "repo.manifest",
    "repo.map",
    "research.fetch",
    "search_session_history",
    "spawn_readonly_subagent",
    "spawn_subagent",
    "submit_task",
  ], [
    "archive_project_memory",
    "ask_architect",
    "browser.click",
    "browser.close",
    "browser.drag",
    "browser.events",
    "browser.fill",
    "browser.navigate",
    "browser.open",
    "browser.screenshot",
    "browser.snapshot",
    "browser.wheel",
    "challenge_guidance",
    "inspect_evidence",
    "list_memory_proposals",
    "list_skills",
    "process.list",
    "process.poll",
    "process.read_output",
    "process.signal",
    "process.start",
    "process.write_stdin",
    "promote_project_memory",
    "propose_project_memory",
    "read_skill",
    "recall_project_memory",
    "request_replan",
    "run_evidence_command",
  ]),
};

const CATALOG_TOOL_NAMES = new Set<string>(
  Object.values(SURFACES).flatMap((entry) => [...entry.tools, ...entry.optionalTools]),
);

/** Lifecycle and authorship tools AC-9a keeps off the verifier and plan critic. */
export const READER_AUTHORITY_FORBIDDEN_TOOLS = Object.freeze([
  "complete_run",
  "git.commit",
  "plan_final_verification",
  "plan_tasks",
  "plan_verification_repairs",
  "plan_verifier_repairs",
  "reconcile_plan",
  "request_integration",
  "resolve_plan_critique",
  "review_final_verification",
  "review_task",
  "revise_task",
  "upgrade_acceptance_contract",
]);

/** Architect lifecycle tools that live on `createArchitectTools`, not the inspection broker. */
export const ARCHITECT_LIFECYCLE_TOOLS = Object.freeze([
  "complete_run",
  "request_integration",
  "review_task",
]);

/**
 * T9 (EP39): the required lifecycle core on triage-`answer` turns, which
 * omit the mutation tools by design. Every answer turn offers questions,
 * completion, and the triage tools.
 */
export const ANSWER_PATH_LIFECYCLE_TOOLS = Object.freeze([
  "ask_user",
  "complete_run",
  "convert_to_build",
  "record_answer",
  "record_triage",
]);

export function roleToolSurface(
  role: RoleCapabilityRole,
  broker: RoleCapabilityBroker,
): RoleToolSurface {
  const surface = SURFACES[`${role}:${broker}`];
  if (!surface) {
    throw new Error(`Role ${role} has no tool surface for broker ${broker}.`);
  }
  return surface;
}

/** Sorted union of required and optional static tools. */
export function roleAllowList(
  role: RoleCapabilityRole,
  broker: RoleCapabilityBroker,
): readonly string[] {
  const entry = roleToolSurface(role, broker);
  return Object.freeze([...entry.tools, ...entry.optionalTools].sort(compareNames));
}

export function staticToolAdmitted(
  role: RoleCapabilityRole,
  broker: RoleCapabilityBroker,
  name: string,
): boolean {
  const entry = roleToolSurface(role, broker);
  return entry.tools.includes(name) || entry.optionalTools.includes(name);
}

export function isCatalogToolName(name: string): boolean {
  return CATALOG_TOOL_NAMES.has(name);
}

export function isMcpToolName(name: string): boolean {
  return name.startsWith("mcp.");
}

export function mcpToolAdmitted(
  policy: McpPolicy,
  definition: { readonly name?: string; readonly readOnly: boolean; readonly effect: ToolEffect },
): boolean {
  if (policy === "none") return false;
  if (policy === "all") return true;
  if (policy === "read-only-class") return isReadOnlyMcpClass(definition);
  return definition.readOnly === true && definition.effect !== "workspace";
}

/**
 * External effect on the Architect inspection broker is accepted only for the
 * read-only MCP class. Static allow-list tools are skipped: A1 already names
 * them, including `research.fetch` and `browser.*`, which are external.
 * Every other external-effect definition throws.
 */
export function assertArchitectInspectionMcpClass(
  definitions: readonly { readonly name: string; readonly readOnly: boolean; readonly effect: ToolEffect }[],
): void {
  for (const definition of definitions) {
    if (staticToolAdmitted("architect", "inspection", definition.name)) continue;
    if (isReadOnlyMcpClass(definition)) continue;
    if (definition.effect === "external") {
      throw new Error(
        `Architect inspection tool ${definition.name} has external effect outside the read-only MCP class.`,
      );
    }
  }
}

function isReadOnlyMcpClass(definition: {
  readonly name?: string;
  readonly readOnly: boolean;
  readonly effect: ToolEffect;
}): boolean {
  return definition.readOnly === true
    && definition.effect === "external"
    && typeof definition.name === "string"
    && isMcpToolName(definition.name);
}

/**
 * Fails closed when a registered static name is not allow-listed, when a
 * required name is absent, or when MCP policy is `none` and an MCP name appears.
 * MCP names under any other policy are dynamic and are not static allow-list
 * entries; callers admit those definitions with `mcpToolAdmitted`.
 */
export function assertRoleToolSurface(
  role: RoleCapabilityRole,
  broker: RoleCapabilityBroker,
  registeredNames: readonly string[],
): void {
  const entry = roleToolSurface(role, broker);
  const allowed = new Set<string>([...entry.tools, ...entry.optionalTools]);
  const registered = new Set<string>();
  for (const name of registeredNames) {
    if (isMcpToolName(name)) {
      if (entry.mcpPolicy === "none") {
        throw new Error(
          `Role ${role} broker ${broker} MCP tool ${name} is not admitted by policy none.`,
        );
      }
      continue;
    }
    if (!allowed.has(name)) {
      throw new Error(
        `Role ${role} broker ${broker} registered tool ${name} is not on the allow-list.`,
      );
    }
    registered.add(name);
  }
  for (const name of entry.tools) {
    if (!registered.has(name)) {
      throw new Error(`Role ${role} broker ${broker} required tool ${name} is missing.`);
    }
  }
}

function surface(
  role: RoleCapabilityRole,
  broker: RoleCapabilityBroker,
  mcpPolicy: McpPolicy,
  tools: readonly string[],
  optionalTools: readonly string[],
): RoleToolSurface {
  const required = freezeSorted(`${role}:${broker} required`, tools);
  const optional = freezeSorted(`${role}:${broker} optional`, optionalTools);
  const requiredSet = new Set<string>(required);
  for (const name of optional) {
    if (requiredSet.has(name)) {
      throw new Error(`Role ${role} broker ${broker} tool ${name} is both required and optional.`);
    }
  }
  return Object.freeze({ role, broker, tools: required, optionalTools: optional, mcpPolicy });
}

function freezeSorted(label: string, names: readonly string[]): readonly string[] {
  const sorted = [...names].sort(compareNames);
  for (let index = 1; index < sorted.length; index += 1) {
    if (sorted[index] === sorted[index - 1]) {
      throw new Error(`Duplicate tool ${sorted[index]} on ${label}.`);
    }
  }
  return Object.freeze(sorted);
}

function compareNames(left: string, right: string): number {
  return left.localeCompare(right);
}
