# AI Board account-provider runner

This package runs the local account bridge for ChatGPT Plus/Pro, GitHub Copilot,
and NVIDIA NIM. The GitHub Copilot discussion transport uses the official
Copilot SDK and its built-in web_search/web_fetch tools.

## Install and start

1. Extract every file in this ZIP into its own directory (separate from Runner V2).
2. Open a terminal in that directory.
3. Install the runner dependencies:

   ```powershell
   npm install
   ```

4. Start the runner:

   ```powershell
   npm start
   ```

The runner prints the local URL and token to paste into AI Board Settings.
Restarting the runner creates a new session token; save the new token in each
account provider that uses this runner. GitHub authorization remains saved.
Keep the runner and Copilot helper from the same ZIP together. The SDK and CLI
versions are pinned to the combination validated by this release.
