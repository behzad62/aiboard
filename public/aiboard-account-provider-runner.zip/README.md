# AI Board account-provider runner

This package runs the local account bridge for ChatGPT Plus/Pro, GitHub Copilot,
and NVIDIA NIM. The GitHub Copilot discussion transport uses the official
Copilot SDK and its built-in web_search/web_fetch tools.

## Install and start

1. Extract this ZIP to a directory.
2. Open a terminal in that directory.
3. Install the runner dependencies:

   ```powershell
   npm install
   ```

4. Start the runner:

   ```powershell
   npm start
   ```

The runner prints the local URL and token to paste into AI Board Settings.
