# AI Board Recoverable Job Service WorkBench runner

This self-contained local package runs the Recoverable Job Service benchmark with its exact trusted runtime and accepted Runner V2 source. Model-driven runs require Windows and Node.js 24.18.0 because the accepted Runner uses Windows Job Objects. The standalone evaluator also runs on Linux.

1. Run `npm ci`.
2. Run `npm run setup:browser`.
3. Run `npm start`.
4. Paste the printed local URL and token into AI Board.

The private evaluator is trusted against benchmark agents, but it is present on and inspectable by the machine owner. Give models only the candidate-visible files shown in AI Board; do not provide the private evaluator or controls as solution material.
