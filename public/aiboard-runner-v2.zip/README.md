# AI Board Runner V2

Runner V2 is the native process required by AI Board Build mode.

## Prerequisites

- Node.js 24.x
- Git installed and available on PATH

## Install and start

1. Extract `aiboard-runner-v2.zip` to a directory on your computer.
2. Open a terminal in the extracted directory.
3. Install the package and Chromium:

   ```powershell
   npm install
   npm run setup:browser
   ```

4. Start Runner V2. The state directory must be outside the project directory:

   ```powershell
   npm start -- --project C:\path\to\project --state-dir C:\path\to\aiboard-state --port 8787
   ```

5. Optional flags can be passed in:

   ```powershell
   npm start -- --project C:\path\to\project --state-dir C:\path\to\aiboard-state --allow-origin https://aiboard.me
   ```

Default behavior already allows `https://aiboard.me` and `https://www.aiboard.me`.
Run `npm start -- --help` to list all options.

Runner V2 prints its localhost URL and control token. Paste both into AI Board Build setup, then test the connection.
