import type {
  NativeTool,
  ToolExecutionContext,
  ToolExecutionOutput,
  ValidationResult,
} from "./agent-contracts.js";
import { requireGitRunner } from "./git-command.js";
import type { RunGitExecutionContext } from "./git-run-context.js";

type Input = Record<string, unknown>;

const WORKER_IDENTITY: Readonly<Record<string, string>> = {
  GIT_AUTHOR_NAME: "AIBoard Worker",
  GIT_AUTHOR_EMAIL: "worker@aiboard.local",
  GIT_COMMITTER_NAME: "AIBoard Worker",
  GIT_COMMITTER_EMAIL: "worker@aiboard.local",
};

export function createGitTools(runContext?: Pick<RunGitExecutionContext, "forCall">): NativeTool<unknown>[] {
  const tools: NativeTool<Input>[] = [
    {
      definition: definition("git.status", "Inspect exact Git worktree state", true),
      validate: objectInput,
      assessAccess: () => readAccess("git.status"),
      execute: async (_input, context) => {
        const output = await git(runContext, context, [
          "status",
          "--porcelain=v1",
          "-z",
          "--untracked-files=all",
        ]);
        const entries = output.stdout
          .split("\0")
          .filter((entry) => entry.length >= 4)
          .map((entry) => ({
            index: entry[0],
            worktree: entry[1],
            path: entry.slice(3),
          }));
        return okJson({ entries });
      },
    },
    {
      definition: definition("git.diff", "Read a Git patch without changing state", true),
      validate: objectInput,
      assessAccess: () => readAccess("git.diff"),
      execute: async (input, context) => {
        const args = ["diff", "--no-ext-diff", "--full-index"];
        if (input.staged === true) args.push("--cached");
        if (input.base !== undefined) {
          if (!validRevision(input.base)) return invalidRevision();
          args.push(input.base);
        }
        args.push("--");
        const output = await git(runContext, context, args, false, 64 * 1024 * 1024);
        return { content: [{ type: "text", text: output.stdout }], isError: false };
      },
    },
    {
      definition: definition("git.log", "Read bounded commit history", true),
      validate: objectInput,
      assessAccess: () => readAccess("git.log"),
      execute: async (input, context) => {
        const limit = Number.isSafeInteger(input.limit)
          ? Math.min(100, Math.max(1, input.limit as number))
          : 20;
        const output = await git(runContext, context, [
          "log",
          `--max-count=${limit}`,
          "--format=%H%x1f%P%x1f%an%x1f%aI%x1f%s%x1e",
        ]);
        const commits = output.stdout
          .split("\x1e")
          .map((record) => record.trim())
          .filter(Boolean)
          .map((record) => {
            const [revision, parents, author, authoredAt, subject] = record.split("\x1f");
            return {
              revision,
              parents: parents ? parents.split(" ").filter(Boolean) : [],
              author,
              authoredAt,
              subject,
            };
          });
        return okJson({ commits });
      },
    },
    {
      definition: definition("git.show", "Show one revision and its patch, or with path one file's content at that revision (e.g. a submitted taskRevision, which the fs tools do not show). <revision>^{tree} shows its tree id and entries, e.g. to match an evidence workingTreeIdentity.treeId.", true),
      validate: objectInput,
      assessAccess: () => readAccess("git.show"),
      execute: async (input, context) => {
        const revision = input.revision ?? "HEAD";
        // A reviewer matching evidence tree ids to the submission asked for <rev>^{tree} and was
        // refused twice with no hint (tunnel run).
        if (typeof revision !== "string") return invalidRevision();
        const peel = /\^\{(?:tree|commit)\}$/.exec(revision)?.[0] ?? "";
        if (!validRevision(peel ? revision.slice(0, -peel.length) : revision) || (peel && input.path !== undefined)) {
          return failure("invalid_revision", "Revision syntax is invalid: use a commit id, branch or tag, optionally with ~N, ^N or a ^{tree}/^{commit} suffix (no path with a suffix).");
        }
        if (input.path !== undefined) {
          // The Architect reviewing a submission read the user's project with fs tools and found
          // only the old scaffold (tunnel run); this reads the submitted file itself.
          if (!validRevisionPath(input.path)) return invalidRevision();
          const file = await git(runContext, context, ["show", "--no-ext-diff", `${revision}:${input.path}`], false, 64 * 1024 * 1024);
          // LF like fs.read: a CRLF file's \r\n otherwise flows into every later argument (tunnel run).
          return { content: [{ type: "text", text: file.stdout.replace(/\r\n/g, "\n") }], isError: false };
        }
        const output = await git(
          runContext, context,
          ["show", "--no-ext-diff", "--format=fuller", revision, "--"],
          false,
          64 * 1024 * 1024
        );
        if (peel === "^{tree}") {
          // git show names a tree as typed, never by id; the id is what evidence records.
          const id = (await git(runContext, context, ["rev-parse", "--verify", "--end-of-options", revision])).stdout.trim();
          return { content: [{ type: "text", text: `tree ${id}\n${output.stdout.replace(/^tree [^\n]*\n/, "")}` }], isError: false };
        }
        return { content: [{ type: "text", text: output.stdout }], isError: false };
      },
    },
    {
      definition: definition("git.remotes", "Inspect configured Git remotes", true),
      validate: objectInput,
      assessAccess: () => readAccess("git.remotes"),
      execute: async (_input, context) => {
        const names = (await git(runContext, context, ["remote"]))
          .stdout.split(/\r?\n/)
          .map((name) => name.trim())
          .filter(Boolean);
        const remotes = await Promise.all(names.map(async (name) => ({
          name,
          fetchUrl: (await git(runContext, context, ["remote", "get-url", name])).stdout.trim(),
          pushUrl: (
            await git(runContext, context, ["remote", "get-url", "--push", name])
          ).stdout.trim(),
        })));
        return okJson({ remotes });
      },
    },
    {
      definition: {
        ...definition("git.push", "Push one explicit revision to a remote branch", false),
        effect: "external",
      },
      validate: validatePush,
      assessAccess: () => ({ capability: "git.push", external: true }),
      execute: async (input, context) => {
        const remote = (input.remote as string | undefined) ?? "origin";
        const source = (input.source as string | undefined) ?? "HEAD";
        const destination = input.destination as string;
        const args = ["push"];
        if (input.forceWithLease === true) args.push("--force-with-lease");
        if (input.setUpstream === true) args.push("--set-upstream");
        args.push(remote, `${source}:${destination}`);
        const output = await git(runContext, context, args);
        const revision = (await git(runContext, context, ["rev-parse", source])).stdout.trim();
        return okJson({
          remote,
          source,
          destination,
          revision,
          output: [output.stdout, output.stderr].filter(Boolean).join("\n").trim(),
        });
      },
    },
    {
      definition: {
        ...definition("git.commit", "Commit all task-workspace changes", false),
        effect: "workspace",
      },
      validate: (input) =>
        isObject(input) && typeof input.message === "string" && input.message.trim()
          ? { ok: true, value: input }
          : { ok: false, issues: ["message must be a non-empty string"] },
      assessAccess: () => ({
        capability: "git.commit",
        paths: [{ path: ".", access: "write" }],
      }),
      execute: async (input, context) => {
        const branch = await git(
          runContext, context,
          ["symbolic-ref", "--quiet", "HEAD"],
          true
        );
        const ref = branch.stdout.trim();
        if (
          branch.exitCode !== 0 ||
          !ref.startsWith("refs/heads/aiboard/") ||
          !ref.includes("/tasks/")
        ) {
          return failure(
            "protected_ref",
            "Workers may commit only to runner-owned task branches."
          );
        }
        await git(runContext, context, ["add", "-A"]);
        const changed = await git(runContext, context, ["diff", "--cached", "--quiet"], true);
        if (changed.exitCode === 0) {
          return failure("nothing_to_commit", "Task workspace has no staged changes.");
        }
        if (changed.exitCode !== 1) {
          return failure("git_state_error", changed.stderr || "Could not inspect staged changes.");
        }
        await requireGitRunner(runContext).forCall(context).run({
          cwd: workspace(context),
          args: ["commit", "-m", (input.message as string).trim()],
          env: WORKER_IDENTITY,
        });
        const revision = (await git(runContext, context, ["rev-parse", "HEAD"])).stdout.trim();
        return okJson({ revision, ref });
      },
    },
  ];
  return tools as NativeTool<unknown>[];
}

function definition(name: string, description: string, readOnly: boolean) {
  return {
    name,
    description,
    inputSchema: gitSchema(name),
    readOnly,
    effect: "none" as const,
  };
}

function gitSchema(name: string): Record<string, unknown> {
  switch (name) {
    case "git.status":
      return objectSchema({}, []);
    case "git.diff":
      return objectSchema(
        {
          staged: { type: "boolean" },
          base: { type: "string", minLength: 1 },
        },
        []
      );
    case "git.log":
      return objectSchema(
        { limit: { type: "integer", minimum: 1, maximum: 100 } },
        []
      );
    case "git.show":
      return objectSchema(
        { revision: { type: "string", minLength: 1 }, path: { type: "string", minLength: 1 } },
        []
      );
    case "git.remotes":
      return objectSchema({}, []);
    case "git.push":
      return objectSchema(
        {
          remote: { type: "string", minLength: 1 },
          source: { type: "string", minLength: 1 },
          destination: { type: "string", minLength: 1 },
          forceWithLease: { type: "boolean" },
          setUpstream: { type: "boolean" },
        },
        ["destination"]
      );
    case "git.commit":
      return objectSchema(
        { message: { type: "string", minLength: 1 } },
        ["message"]
      );
    default:
      throw new Error(`Unknown Git tool ${name}.`);
  }
}

function objectSchema(
  properties: Record<string, unknown>,
  required: string[]
): Record<string, unknown> {
  return { type: "object", properties, required, additionalProperties: false };
}

function objectInput(input: unknown): ValidationResult<Input> {
  return isObject(input)
    ? { ok: true, value: input }
    : { ok: false, issues: ["input must be an object"] };
}

function validatePush(input: unknown): ValidationResult<Input> {
  if (!isObject(input)) return { ok: false, issues: ["input must be an object"] };
  const remote = input.remote ?? "origin";
  const source = input.source ?? "HEAD";
  if (typeof remote !== "string" || !/^[A-Za-z0-9._-]+$/.test(remote)) {
    return { ok: false, issues: ["remote name is invalid"] };
  }
  if (!validRevision(source)) {
    return { ok: false, issues: ["source revision is invalid"] };
  }
  if (!validDestination(input.destination)) {
    return { ok: false, issues: ["destination branch is invalid"] };
  }
  if (
    input.forceWithLease !== undefined &&
    typeof input.forceWithLease !== "boolean"
  ) return { ok: false, issues: ["forceWithLease must be boolean"] };
  if (input.setUpstream !== undefined && typeof input.setUpstream !== "boolean") {
    return { ok: false, issues: ["setUpstream must be boolean"] };
  }
  return { ok: true, value: input };
}

function isObject(input: unknown): input is Input {
  return typeof input === "object" && input !== null && !Array.isArray(input);
}

function readAccess(capability: string) {
  return {
    capability,
    paths: [{ path: ".", access: "read" as const }],
  };
}

function workspace(context: ToolExecutionContext): string {
  if (!context.workspacePath) throw new Error("Git tool requires a workspace.");
  return context.workspacePath;
}

async function git(
  runContext: Pick<RunGitExecutionContext, "forCall"> | undefined,
  context: ToolExecutionContext,
  args: readonly string[],
  allowFailure = false,
  maxOutputBytes?: number
) {
  return await requireGitRunner(runContext).forCall(context).run({
    cwd: workspace(context),
    args,
    allowFailure,
    ...(maxOutputBytes ? { maxOutputBytes } : {}),
  });
}

/** A repository-relative file path: no absolute, parent, empty or option-like segments. */
function validRevisionPath(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const path = value.replaceAll("\\", "/");
  return !path.startsWith("/") && !path.startsWith("-") && !/^[A-Za-z]:/.test(path) && !/[\x00-\x1f]/.test(path) &&
    path.split("/").every((segment) => segment !== "" && segment !== "." && segment !== "..");
}

function validRevision(value: unknown): value is string {
  return (
    typeof value === "string" &&
    /^[A-Za-z0-9][A-Za-z0-9._~^/-]*$/.test(value) &&
    !value.includes("..")
  );
}

function validDestination(value: unknown): value is string {
  return (
    typeof value === "string" &&
    /^(?:refs\/heads\/)?[A-Za-z0-9][A-Za-z0-9._/-]*$/.test(value) &&
    !value.includes("..") &&
    !value.includes("//") &&
    !value.endsWith("/") &&
    !value.endsWith(".lock")
  );
}

function invalidRevision(): ToolExecutionOutput {
  return failure("invalid_revision", "Revision syntax is invalid.");
}

function okJson(value: unknown): ToolExecutionOutput {
  return { content: [{ type: "json", value }], isError: false };
}

function failure(code: string, message: string): ToolExecutionOutput {
  return {
    content: [{ type: "text", text: message }],
    isError: true,
    error: { code, message },
  };
}
