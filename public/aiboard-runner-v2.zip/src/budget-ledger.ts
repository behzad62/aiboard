export type BudgetReservationKind = "model" | "tool";

export type ModelCallRole = "architect" | "worker" | "subagent" | "verifier";

export interface ModelCallAttribution {
  runtimeId: string;
  providerId: string;
  modelId: string;
  role: ModelCallRole;
  sessionId: string;
  taskId?: string;
}

export type ModelTokenSource = "reported" | "estimated";

export interface ModelTokenSources {
  inputTokens: ModelTokenSource;
  outputTokens: ModelTokenSource;
}

export type ModelCostBasisSnapshot =
  | {
      kind: "api_estimate";
      billingBasis?: "api_priced";
      inputCostMicrosPerMillion: number;
      outputCostMicrosPerMillion: number;
      cachedInputCostMicrosPerMillion: number;
      cacheWriteInputCostMicrosPerMillion: number;
    }
  | { kind: "account_not_metered"; billingBasis?: "account_not_metered" }
  | { kind: "unknown"; billingBasis?: "unknown" };

export interface BudgetUsage {
  modelCalls: number;
  toolCalls: number;
  inputTokens: number;
  cachedInputTokens?: number;
  cacheWriteInputTokens?: number;
  outputTokens: number;
  estimatedCostMicros: number;
  activeMs: number;
  artifactBytes: number;
}

export type BudgetAmount = Partial<Omit<BudgetUsage, "modelCalls" | "toolCalls" | "activeMs">>;

export interface BudgetLimits {
  maxModelCalls?: number;
  maxToolCalls?: number;
  maxInputTokens?: number;
  maxOutputTokens?: number;
  maxEstimatedCostMicros?: number;
  maxActiveMs?: number;
  maxArtifactBytes?: number;
}

export type BudgetDimension = Exclude<
  keyof BudgetUsage,
  "cachedInputTokens" | "cacheWriteInputTokens"
>;

export class BudgetExceededError extends Error {
  constructor(
    readonly scopeId: string,
    readonly dimension: BudgetDimension,
    readonly attempted: number,
    readonly limit: number
  ) {
    super(
      `Budget ${dimension} for ${scopeId} would reach ${attempted}, above limit ${limit}.`
    );
    this.name = "BudgetExceededError";
  }
}

export type BudgetEventType =
  | "budget.reserved"
  | "budget.settled"
  | "budget.window_started"
  | "active.started"
  | "active.stopped";

export interface BudgetEvent {
  sequence: number;
  eventId: string;
  scopeId: string;
  type: BudgetEventType;
  occurredAt: string;
  idempotencyKey: string;
  payload: Record<string, unknown>;
}

export interface BudgetReservationProjection {
  reservationId: string;
  kind: BudgetReservationKind;
  attribution?: ModelCallAttribution;
  estimate: BudgetAmount;
  actual?: BudgetAmount;
  tokenSources?: ModelTokenSources;
  costBasis?: ModelCostBasisSnapshot;
  settledAt?: string;
  status: "reserved" | "settled";
  windowIndex: number;
}

export interface ActiveSegmentProjection {
  segmentId: string;
  startedAt: string;
  reserveMs: number;
  durationMs?: number;
  windowIndex: number;
}

export interface BudgetProjection {
  scopeId: string;
  reservations: Record<string, BudgetReservationProjection>;
  activeSegments: Record<string, ActiveSegmentProjection>;
  effective: BudgetUsage;
  lifetime: BudgetUsage;
  window: {
    index: number;
    startedAt?: string;
  };
  lastSequence: number;
}

export interface StartBudgetWindowInput {
  scopeId: string;
  occurredAt: string;
  idempotencyKey: string;
}

interface ReserveBudgetInputBase {
  scopeId: string;
  reservationId: string;
  estimate: BudgetAmount;
  occurredAt: string;
  idempotencyKey: string;
}

export type ReserveBudgetInput =
  | (ReserveBudgetInputBase & {
      kind: "model";
      attribution: ModelCallAttribution;
      costBasis?: ModelCostBasisSnapshot;
    })
  | (ReserveBudgetInputBase & {
      kind: "tool";
      attribution?: never;
    });

export interface SettleBudgetInput {
  scopeId: string;
  reservationId: string;
  actual: BudgetAmount;
  tokenSources?: ModelTokenSources;
  costBasis?: ModelCostBasisSnapshot;
  occurredAt: string;
  idempotencyKey: string;
}

export interface StartActiveInput {
  scopeId: string;
  segmentId: string;
  reserveMs?: number;
  occurredAt: string;
  idempotencyKey: string;
}

export interface StopActiveInput {
  scopeId: string;
  segmentId: string;
  occurredAt: string;
  idempotencyKey: string;
}

export interface BudgetLedger {
  reserve(input: ReserveBudgetInput): BudgetEvent;
  settle(input: SettleBudgetInput): BudgetEvent;
  startActive(input: StartActiveInput): BudgetEvent;
  stopActive(input: StopActiveInput): BudgetEvent;
  startWindow(input: StartBudgetWindowInput): BudgetEvent;
  snapshot(scopeId: string): BudgetProjection;
  events(scopeId: string): BudgetEvent[];
  close(): void;
}

export function rebuildBudgetProjection(
  scopeId: string,
  events: readonly BudgetEvent[]
): BudgetProjection {
  const projection: BudgetProjection = {
    scopeId,
    reservations: {},
    activeSegments: {},
    effective: emptyUsage(),
    lifetime: emptyUsage(),
    window: { index: 1 },
    lastSequence: 0,
  };
  for (const event of events) reduceBudgetEvent(projection, event);
  return projection;
}

export function reduceBudgetEvent(
  projection: BudgetProjection,
  event: BudgetEvent
): void {
  if (event.scopeId !== projection.scopeId) {
    throw new Error(`Budget event ${event.eventId} belongs to another scope.`);
  }
  if (event.type === "budget.window_started") {
    projection.window = {
      index: projection.window.index + 1,
      startedAt: event.occurredAt,
    };
    projection.effective = emptyUsage();
  } else if (event.type === "budget.reserved") {
    const reservationId = requiredString(event.payload, "reservationId");
    if (projection.reservations[reservationId]) {
      throw new Error(`Duplicate budget reservation ${reservationId}.`);
    }
    const kind = requiredString(event.payload, "kind");
    if (kind !== "model" && kind !== "tool") throw new Error(`Invalid budget kind ${kind}.`);
    const attribution = optionalModelCallAttribution(event.payload.attribution);
    const costBasis = optionalModelCostBasisSnapshot(event.payload.costBasis);
    const reservation: BudgetReservationProjection = {
      reservationId,
      kind,
      ...(attribution ? { attribution } : {}),
      ...(costBasis ? { costBasis } : {}),
      estimate: usageAmount(event.payload.estimate),
      status: "reserved",
      windowIndex: projection.window.index,
    };
    projection.reservations[reservationId] = reservation;
    const callDimension = kind === "model" ? "modelCalls" : "toolCalls";
    projection.lifetime[callDimension] += 1;
    projection.effective[callDimension] += 1;
    adjustAmount(projection.lifetime, reservation.estimate, 1);
    adjustAmount(projection.effective, reservation.estimate, 1);
  } else if (event.type === "budget.settled") {
    const reservationId = requiredString(event.payload, "reservationId");
    const reservation = projection.reservations[reservationId];
    if (!reservation || reservation.status !== "reserved") {
      throw new Error(`Budget reservation ${reservationId} is not open.`);
    }
    const actual = usageAmount(event.payload.actual);
    projection.reservations[reservationId] = {
      ...reservation,
      status: "settled",
      actual,
      ...(event.payload.tokenSources === undefined
        ? {}
        : { tokenSources: modelTokenSources(event.payload.tokenSources) }),
      ...(event.payload.settledAt === undefined
        ? {}
        : { settledAt: requiredString(event.payload, "settledAt") }),
      ...(event.payload.costBasis === undefined
        ? {}
        : { costBasis: modelCostBasisSnapshot(event.payload.costBasis) }),
    };
    adjustAmount(projection.lifetime, reservation.estimate, -1);
    adjustAmount(projection.lifetime, actual, 1);
    if (reservation.windowIndex === projection.window.index) {
      adjustAmount(projection.effective, reservation.estimate, -1);
      adjustAmount(projection.effective, actual, 1);
    }
  } else if (event.type === "active.started") {
    const segmentId = requiredString(event.payload, "segmentId");
    if (projection.activeSegments[segmentId]) {
      throw new Error(`Duplicate active segment ${segmentId}.`);
    }
    const segment: ActiveSegmentProjection = {
      segmentId,
      startedAt: event.occurredAt,
      reserveMs: requiredNonNegative(event.payload, "reserveMs"),
      windowIndex: projection.window.index,
    };
    projection.activeSegments[segmentId] = segment;
    projection.lifetime.activeMs += segment.reserveMs;
    projection.effective.activeMs += segment.reserveMs;
  } else {
    const segmentId = requiredString(event.payload, "segmentId");
    const segment = projection.activeSegments[segmentId];
    if (!segment || segment.durationMs !== undefined) {
      throw new Error(`Active segment ${segmentId} is not open.`);
    }
    const durationMs = requiredNonNegative(event.payload, "durationMs");
    projection.activeSegments[segmentId] = {
      ...segment,
      durationMs,
    };
    const activeDelta = durationMs - segment.reserveMs;
    projection.lifetime.activeMs += activeDelta;
    if (segment.windowIndex === projection.window.index) {
      projection.effective.activeMs += activeDelta;
    }
  }
  projection.lastSequence = event.sequence;
}

function adjustAmount(
  target: BudgetUsage,
  amount: BudgetAmount,
  direction: 1 | -1
): void {
  target.inputTokens += direction * (amount.inputTokens ?? 0);
  target.cachedInputTokens =
    (target.cachedInputTokens ?? 0) + direction * (amount.cachedInputTokens ?? 0);
  target.cacheWriteInputTokens =
    (target.cacheWriteInputTokens ?? 0) + direction * (amount.cacheWriteInputTokens ?? 0);
  target.outputTokens += direction * (amount.outputTokens ?? 0);
  target.estimatedCostMicros += direction * (amount.estimatedCostMicros ?? 0);
  target.artifactBytes += direction * (amount.artifactBytes ?? 0);
}

export function emptyUsage(): BudgetUsage {
  return {
    modelCalls: 0,
    toolCalls: 0,
    inputTokens: 0,
    cachedInputTokens: 0,
    cacheWriteInputTokens: 0,
    outputTokens: 0,
    estimatedCostMicros: 0,
    activeMs: 0,
    artifactBytes: 0,
  };
}

export function usageAmount(value: unknown): BudgetAmount {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error("Budget amount must be an object.");
  }
  const input = value as Record<string, unknown>;
  const result: BudgetAmount = {};
  for (const key of [
    "inputTokens",
    "cachedInputTokens",
    "cacheWriteInputTokens",
    "outputTokens",
    "estimatedCostMicros",
    "artifactBytes",
  ] as const) {
    const amount = input[key];
    if (amount === undefined) continue;
    if (!Number.isSafeInteger(amount) || (amount as number) < 0) {
      throw new Error(`Budget ${key} must be a non-negative integer.`);
    }
    result[key] = amount as number;
  }
  return result;
}

export function modelCallAttribution(value: unknown): ModelCallAttribution {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error("Model reservation attribution must be an object.");
  }
  const input = value as Record<string, unknown>;
  const role = requiredString(input, "role");
  if (
    role !== "architect" &&
    role !== "worker" &&
    role !== "subagent" &&
    role !== "verifier"
  ) {
    throw new Error(`Invalid model call role ${role}.`);
  }
  return {
    runtimeId: requiredString(input, "runtimeId"),
    providerId: requiredString(input, "providerId"),
    modelId: requiredString(input, "modelId"),
    role,
    sessionId: requiredString(input, "sessionId"),
    ...(input.taskId === undefined
      ? {}
      : { taskId: requiredString(input, "taskId") }),
  };
}

export function modelTokenSources(value: unknown): ModelTokenSources {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new Error("Model token sources must be an object.");
  }
  const input = value as Record<string, unknown>;
  return {
    inputTokens: modelTokenSource(input.inputTokens, "inputTokens"),
    outputTokens: modelTokenSource(input.outputTokens, "outputTokens"),
  };
}

export function modelCostBasisSnapshot(value: unknown): ModelCostBasisSnapshot {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("Invalid model cost basis snapshot.");
  }
  const input = value as Record<string, unknown>;
  if (input.kind === "account_not_metered" || input.kind === "unknown") {
    const expected = input.kind;
    if (input.billingBasis !== undefined && input.billingBasis !== expected) {
      throw new Error("Invalid model cost basis billingBasis.");
    }
    return expected === "account_not_metered"
      ? { kind: "account_not_metered", billingBasis: "account_not_metered" }
      : { kind: "unknown", billingBasis: "unknown" };
  }
  if (input.kind !== "api_estimate") {
    throw new Error("Invalid model cost basis snapshot.");
  }
  const fields = [
    "inputCostMicrosPerMillion",
    "outputCostMicrosPerMillion",
    "cachedInputCostMicrosPerMillion",
    "cacheWriteInputCostMicrosPerMillion",
  ] as const;
  for (const field of fields) {
    if (!Number.isSafeInteger(input[field]) || (input[field] as number) < 0) {
      throw new Error(`Invalid model cost basis ${field}.`);
    }
  }
  return {
    kind: "api_estimate",
    billingBasis: "api_priced",
    inputCostMicrosPerMillion: input.inputCostMicrosPerMillion as number,
    outputCostMicrosPerMillion: input.outputCostMicrosPerMillion as number,
    cachedInputCostMicrosPerMillion: input.cachedInputCostMicrosPerMillion as number,
    cacheWriteInputCostMicrosPerMillion: input.cacheWriteInputCostMicrosPerMillion as number,
  };
}

function optionalModelCostBasisSnapshot(value: unknown): ModelCostBasisSnapshot | undefined {
  return value === undefined ? undefined : modelCostBasisSnapshot(value);
}

function optionalModelCallAttribution(
  value: unknown
): ModelCallAttribution | undefined {
  return value === undefined ? undefined : modelCallAttribution(value);
}

function modelTokenSource(value: unknown, dimension: string): ModelTokenSource {
  if (value !== "reported" && value !== "estimated") {
    throw new Error(`Invalid ${dimension} token source.`);
  }
  return value;
}

function requiredString(payload: Record<string, unknown>, key: string): string {
  const value = payload[key];
  if (typeof value !== "string" || !value) throw new Error(`Missing ${key}.`);
  return value;
}

function requiredNonNegative(payload: Record<string, unknown>, key: string): number {
  const value = payload[key];
  if (!Number.isSafeInteger(value) || (value as number) < 0) {
    throw new Error(`Missing ${key}.`);
  }
  return value as number;
}
