import { createHash } from "node:crypto";
import type { AssignmentClaim } from "./planning-contracts.js";
import { claimPathContains, literalClaimPathContains } from "./task-resource-claims.js";
import { isSensitiveKey } from "./sensitive-redaction.js";

export interface SubmissionFile {
  path: string;
  added: boolean;
  addedLines: readonly string[];
}
export interface SubmissionScopeFinding {
  id: string;
  code: "outside_claim" | "forbidden_surface" | "instruction_surface" | "harness_diary";
  path: string;
  severity: "blocking";
  message: string;
}

/**
 * Refusal never carries the matching value, line content, or a sensitive filename. It names an
 * ordinary file and the field the value was assigned to, so the worker can fix it: the bare refusal
 * left a worker resubmitting until its turn budget ran out (tunnel run).
 */
export function assertSubmissionHasNoSecrets(files: readonly SubmissionFile[]): void {
  for (const file of files) {
    const path = submissionPath(file.path);
    if (file.added && secretFilePath(path)) {
      throw new Error("Submission refused: secret or key material detected [REDACTED].");
    }
    const code = sourceCodePath(path);
    for (const line of file.addedLines) {
      const hit = secretLine(line, code);
      if (hit === false) continue;
      throw new Error(
        `Submission refused: secret or key material detected [REDACTED] in ${path}` +
        `${hit === true ? "" : ` (value assigned to ${hit})`}. Use an obviously fake placeholder or build test values at runtime.`,
      );
    }
  }
}

/**
 * The refusal submit_task would give for this file's content, or undefined. Writes report it at once:
 * a worker found out only at submission, after every build and test run, and had to redo them all
 * (tunnel run).
 */
export function submissionSecretNotice(path: string, text: string): string | undefined {
  const normalized = submissionPath(path);
  if (secretFilePath(normalized)) return `submit_task will refuse ${normalized}: secret or key material files cannot be submitted.`;
  const code = sourceCodePath(normalized);
  for (const line of text.split("\n")) {
    const hit = secretLine(line, code);
    if (hit === false) continue;
    return `submit_task will refuse ${normalized}: secret or key material detected [REDACTED]` +
      `${hit === true ? "" : ` (value assigned to ${hit})`}. Use an obviously fake placeholder or build test values at runtime.`;
  }
  return undefined;
}

function secretFilePath(path: string): boolean {
  const name = path.split("/").at(-1)!.toLowerCase();
  return name === ".env" || name.startsWith(".env.") || /\.(?:pem|p12|pfx|key)$/.test(name) || /^id_(?:rsa|dsa|ecdsa|ed25519)$/.test(name);
}

/** Program source, where a literal secret must be quoted: an unquoted value there is code. */
function sourceCodePath(path: string): boolean {
  return /\.(?:[cm]?[jt]sx?|py|go|rs|java|kts?|cs|rb|php|swift|scala|c|cc|cpp|h|hpp)$/i.test(path);
}

/** False when clean; true for a token-pattern match; the field name for a sensitive assignment. */
function secretLine(line: string, code = false): boolean | string {
  if (/-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----/.test(line) ||
    /\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/.test(line) ||
    /\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}\b/.test(line) ||
    /\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|xox[baprs]-[A-Za-z0-9-]{20,})\b/.test(line)) return true;
  for (const match of line.matchAll(/["']?([A-Za-z_][A-Za-z0-9_-]*)["']?\s*[:=]\s*(?:(["'`])([^"'`\r\n]{16,})\2|([A-Za-z0-9_./+=:@%-]{16,}))/g)) {
    // In source an unquoted value is an identifier or expression (`adminTokenSource: AdminTokenSource`),
    // never a literal; the worker renamed its API fields to get past this (tunnel run).
    if (code && match[2] === undefined) continue;
    const value = match[3] ?? match[4]!;
    const environmentReference = match[2] === undefined && /^(?:process\.env\.|os\.environ\.|env\.)[A-Za-z_][A-Za-z0-9_]*$/.test(value);
    const templateReference = match[2] === "`" && /^\$\{[A-Za-z_][A-Za-z0-9_.$]*\}$/.test(value);
    const wholePlaceholder = /^\{\{\s*[A-Za-z_][A-Za-z0-9_.]*\s*\}\}$/.test(value);
    // Code, not a literal: a call (generateDeviceToken()), a member reference (config.adminToken), a
    // template that is mostly interpolation (`Bearer ${token}`), or an angle-bracket placeholder.
    const end = (match.index ?? 0) + match[0].length;
    const callExpression = match[2] === undefined && /^\s*\(/.test(line.slice(end));
    const memberReference = match[2] === undefined && /^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+$/.test(value);
    const interpolatedTemplate = match[2] === "`" && value.includes("${") && value.replace(/\$\{[^}]*\}/g, "").length < 16;
    const anglePlaceholder = /<[A-Za-z][\w-]*>/.test(value);
    // The name of an environment variable (`ADMIN_TOKEN_ENV = "RELAY_ADMIN_TOKEN"`), not its value.
    const environmentName = /^[A-Z]+(?:_[A-Z0-9]+)+$/.test(value);
    // The refusal tells the worker to use an obviously fake placeholder, so one must pass: a value that
    // says so, or one with almost no variety. A redaction task's tests need credential-named fields, and
    // without this the worker obfuscated its own field names to get through (tunnel run). The token
    // patterns above still refuse unconditionally.
    // A long run of one character (`atc_wrong_token_0000000000`) never occurs in a random secret; the
    // worker rewrote such test tokens and dropped an assertion to get past the guard (tunnel run).
    const obviouslyFake = /fake|dummy|example|placeholder|not[-_ ]?a[-_ ]?real|redacted|changeme/i.test(value) ||
      new Set(value).size < 6 || /(.)\1{7,}/.test(value);
    if (
      isSensitiveKey(match[1]!) && !environmentReference && !templateReference && !wholePlaceholder &&
      !callExpression && !memberReference && !interpolatedTemplate && !anglePlaceholder && !obviouslyFake &&
      !environmentName
    ) return match[1]!;
  }
  return false;
}

/** Mechanical scope facts only; the Architect owns their disposition. */
export function inspectSubmissionScope(files: readonly SubmissionFile[], claim: Pick<AssignmentClaim, "writableSurfaces" | "forbiddenSurfaces">, options: { literalPaths?: boolean } = {}): SubmissionScopeFinding[] {
  const findings: SubmissionScopeFinding[] = [];
  for (const file of files) {
    const path = submissionPath(file.path);
    const contains = options.literalPaths ? literalClaimPathContains : claimPathContains;
    const claimed = claim.writableSurfaces.some((surface) => !surface.startsWith("resource:") && contains(surface, path));
    const codes: SubmissionScopeFinding["code"][] = [];
    if (!claimed) codes.push("outside_claim");
    if (claim.forbiddenSurfaces.some((surface) => contains(surface, path))) codes.push("forbidden_surface");
    if (!claimed && /(?:^|\/)(?:agents\.md|claude\.md|\.github(?:\/|$)|\.git[^/]*)/i.test(path)) codes.push("instruction_surface");
    if (file.added && diaryPath(path)) codes.push("harness_diary");
    for (const code of codes) findings.push({
      id: `scope:${createHash("sha256").update(`${code}\0${path}`).digest("hex")}`,
      code, path, severity: "blocking", message: `${code}: submission path requires an explicit Architect scope resolution.`,
    });
  }
  return findings;
}

function submissionPath(input: string): string {
  const path = input.replaceAll("\\", "/");
  if (!path || path.startsWith("/") || /^[a-z]:/i.test(path) || /[\x00-\x1f\x7f]/.test(path) || path.split("/").some((part) => !part || part === "." || part === "..")) {
    throw new Error("Submission path identity is invalid.");
  }
  return path;
}

function diaryPath(path: string): boolean {
  return /(?:^|\/)(?:progress|evidence|reviews?|test[-_]?outputs?)(?:[._-]|\/|$)/i.test(path);
}
