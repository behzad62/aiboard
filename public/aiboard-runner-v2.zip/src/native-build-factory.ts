import { workingTreeForRunner } from "./command-evidence-identity.js";
import { projectPlanningReadiness, buildPlanningExportDocument } from "./planning-controls.js";
import { inspectTestIntegrityPin } from "./test-integrity-profile.js";
import { testIntegrityPinDigest, testIntegrityProfileFindings } from "./test-integrity.js";
import { explicitStartBlocked } from "./scheduler-store.js";
import { createExecutionHostLspTransportFactory, cleanupRecoveredLspTransports } from "./execution-host-lsp-transport.js";
import { createWindowsJobProcessHost } from "./windows-job-process-host.js";
import type { LspTransportFactory } from "./lsp-transport.js";
import type { McpDiscoveryResult } from "./runner-internal-execution-context.js";
import { requireGitRunner, unavailableGitRunner } from "./git-command.js";
import type { RunGitExecutionContext } from "./git-run-context.js";
import { createHash, randomBytes } from "node:crypto";
import { AUTHORIZED_STOP_CLEANUP_TIMEOUT_MS } from "./cleanup-timeouts.js";
import { readFileSync, statSync, writeFileSync } from "node:fs";
import { copyFile, lstat, mkdir, mkdtemp, open, readFile, rm } from "node:fs/promises";
import { createSchedulerTempRecorders, decideRecordedTempCleanup, filterRecordsForOwner, recordTempCreation, searchOwnedProcesses, type LeftoverCleanupRecord, type TempCreationRecord } from "./cleanup-ownership.js";
import { homedir, tmpdir } from "node:os";
import { basename, isAbsolute, join, relative } from "node:path";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { AccountRunnerModel } from "./account-runner-model.js";
import { AnthropicModel } from "./anthropic-model.js";
import type { AgentModel } from "./agent-contracts.js";
import {
  rebuildBudgetProjection,
  type BudgetProjection,
  type ModelCostBasisSnapshot,
} from "./budget-ledger.js";
import { ArtifactStore } from "./artifact-store.js";
import {
  createDeliveryBoundaryDriver,
  createDeliveryDepthRunner,
  createDeliveryWorkspaceSlot,
  currentWorkerAuthor,
  loadDeliverableReviewInputs,
  submitTaskSummary,
  type DurableSubmission,
} from "./delivery-execution.js";
import { NativeDeliverableReviewRuntime, type DeliverableReviewInputs } from "./native-deliverable-review.js";
import type { ExecutionTaskContract } from "./planning-contracts.js";
import type { BuildTask, TaskContractRef } from "./task-contracts.js";
import type { MutationFileSystem } from "./mutation-probe.js";
import { ArtifactReachabilityGuard } from "./artifact-reachability.js";
import { CapabilityRegistry } from "./capability-registry.js";
import {
  BuildRuntime,
  type FinalVerificationCheckDriver,
  type FlakyIsolationDriver,
  type IndependentVerifierDriver,
  type IntegrationRuntimeDriver,
  type DeliveryBoundaryDriver,
  type DeliveryReviewDriver,
  type PlanCriticDriver,
} from "./build-runtime.js";
import type { AgentSessionProjection } from "./agent-session-store.js";
import { nativeBuildBudgetEnforceabilityError } from "./budget-enforceability.js";
import type { ModelCostEstimator } from "./budgeted-model.js";
import type {
  BuildObservabilitySnapshot,
  BuildToolObservation,
} from "./build-observability.js";
import {
  loadFinalVerificationDiagnostics,
  projectExecutionSafetyObservability,
  projectFinalVerificationObservability,
  projectIndependentVerifierObservability,
  projectPlanningObservability,
} from "./build-observability.js";
import { PlaywrightBrowserBackend } from "./browser-tools.js";
import { cloneBuildSpec, validateBuildSpec, type NativeBuildSpec } from "./build-spec.js";
import {
  assertManifestMatchesBytes,
  computeArtifactDigest,
  type ApprovedSourceManifest,
} from "./source-manifest.js";
import {
  approvedSourceApprover,
  buildApprovedSourceManifest,
  ensurePlanningProvisioningPrefix,
  registerApprovedSource,
  validateApprovedSourceInput,
  validateProvisioningPrepareOptions,
  verifyPreparedApprovedSource,
  type ProvisioningPrepareOptions,
  type ValidatedApprovedSource,
} from "./native-planning-provisioner.js";
import { IntegrationManager } from "./integration-manager.js";
import { FinalVerificationRuntime, type FinalVerificationCommand } from "./final-verification-runtime.js";
import { flakyRerunPattern, isPackageRunTestCommand, judgeFlakyRerun, narrowNodeTestCommand } from "./flaky-rerun.js";
import { topDefectClasses } from "./defect-history.js";
import {
  finalVerificationProfileDigest,
  inspectFinalVerificationExecutionProfile,
  FinalVerificationProfileAuthority,
  projectTierCommandsToRuntimeCommands,
} from "./final-verification-profile.js";
import { FinalVerificationPortAuthority } from "./final-verification-port-authority.js";
import {
  FinalVerificationDiagnosticsArchive,
  OwnedFinalVerificationCleanup,
  retireInvalidatedFinalVerificationGeneration,
  validateOwnedFinalVerificationCleanupReceipt,
  type FinalVerificationCleanupReceiptIdentity,
} from "./final-verification-cleanup.js";
import { GoogleModel } from "./google-model.js";
import { LanguageProviderRouter } from "./language-provider-router.js";
import {
  ManagedProcessService,
  readHistoricalManagedProcessObservations,
} from "./managed-process.js";
import type {
  HistoricalTerminalState,
  NativeBuildRuntimeHandle,
} from "./native-build-manager.js";
import {
  projectNativeModelUsage,
  type NativeModelUsageRuntime,
} from "./model-usage-projection.js";
import { NativeArchitectRuntime } from "./native-architect-runtime.js";
import {
  buildCoverageHostCapabilities,
  NativeCoverageReviewRuntime,
  SchedulerCoverageReviewAuthority,
  type CoverageReviewDriver,
} from "./planning-review.js";
import {
  NativeAnswerReviewRuntime,
  SchedulerAnswerReviewAuthority,
  type AnswerReviewDriver,
} from "./request-triage.js";
import {
  NativePlanCriticRuntime,
  type NativePlanCritiqueRequest,
} from "./native-plan-critic-runtime.js";
import {
  NativeVerifierRuntime,
  type NativeVerifierInspectionRequest,
} from "./native-verifier-runtime.js";
import { SchedulerPlanCritiqueAuthority } from "./plan-critique-authority.js";
import type { PlanRiskReason } from "./plan-critique-contracts.js";
import { isFinalVerificationTask } from "./task-contracts.js";
import { NativeWorkerDriver } from "./native-worker-driver.js";
import { resolveWorkerSessionId, standardWorkerId } from "./worker-identity.js";
import { OpenAICompatibleModel } from "./openai-compatible-model.js";
import { createConfiguredOciIsolationSelector } from "./oci-execution-isolation-provider.js";
import { readExecutionEnforcementState } from "./execution-isolation-provider.js";
import {
  createMcpTools,
  McpManager,
  type LiveMcpStatusRegistry,
} from "./mcp-tools.js";
import {
  cleanupRecoveredMcpTransports,
  createExecutionHostMcpTransportFactory,
} from "./execution-host-mcp-transport.js";
import type { SqlitePermissionStore } from "./permission-store.js";
import type {
  ProviderConfigStore,
  RunnerProviderConfig,
} from "./provider-config-store.js";
import {
  LocalPluginLoader,
  RunnerExtensionLoadError,
  type LoadedRunnerExtensions,
  type RunnerExtensionCleanupDisposer,
} from "./plugin-loader.js";
import {
  emptyRunnerCapabilitiesConfig,
  type RunnerCapabilitiesConfig,
} from "./runner-capabilities-config.js";
import {
  attestRunnerCapabilitiesLanguageServers,
  RunnerCapabilityContractError,
  cloneRunnerCapabilityContract,
  createRunnerCapabilityContractSnapshot,
  runnerCapabilitiesForContract,
  runnerCapabilitySnapshotExtensionDirectories,
  validateRunnerCapabilityContract,
  validateRunnerCapabilityContractSnapshot,
  type RunnerCapabilityContractErrorCode,
} from "./runner-capability-contract.js";
import { RUNNER_BUILTIN_TOOL_NAMES } from "./runner-extension.js";
import { runnerRunStateSegment } from "./run-state-identity.js";
import { RepositoryIntelligence } from "./repository-intelligence.js";
import {
  providerUsageConfig,
  resolvedProviderBillingBasis,
} from "./provider-config-store.js";
import { ProviderHealthRegistry, type ProviderHealthState } from "./provider-health.js";
import { runnerProviderRetryDeadlineMs } from "./provider-call-retry.js";
import { RuntimeRouter, type AgentRuntimeCandidate } from "./runtime-router.js";
import { isSensitiveKey } from "./sensitive-redaction.js";
import {
  readyPlanIdentity,
  rebuildSchedulerProjection,
  repairParentContractId,
  resolveTaskContractReference,
  taskPlanMembership,
  type SchedulerEvent,
  type SchedulerProjection,
  type BuildRiskAssessmentProjection,
} from "./scheduler-store.js";
import type { BuildRiskAssessmentInput } from "./risk-policy.js";
import {
  SkillCatalog,
  type SharedSkillRoot,
  type SkillMetadata,
} from "./skill-catalog.js";
import type {
  HistoricalReadProvenance,
} from "./historical-read-provenance.js";
import { SqliteAgentSessionStore } from "./sqlite-agent-session-store.js";
import { SqliteBudgetLedger } from "./sqlite-budget-ledger.js";
import { isRunValidationBudgetScope } from "./validation-budget.js";
import { readValidationBudgetMsAtRevision } from "./project-validation-config.js";
import { SqliteEvidenceStore } from "./sqlite-evidence-store.js";
import { SqliteProjectMemoryStore } from "./sqlite-project-memory.js";
import { rebuildProjectMemories } from "./project-memory.js";
import { SqliteSchedulerStore } from "./sqlite-scheduler-store.js";
import { SqliteToolLedger } from "./sqlite-tool-ledger.js";
import { SqliteContextManifestStore } from "./sqlite-context-manifest-store.js";
import type { ToolLedgerEvent } from "./tool-ledger.js";
import { TypeScriptIntelligence } from "./typescript-intelligence.js";
import { SchedulerVerifierVerdictAuthority } from "./verifier-verdict-authority.js";
import { WorkspaceManager } from "./workspace-manager.js";
import { VerificationWorkspaceManager } from "./verification-workspace.js";
import { verifyHandoffSnapshotDigest } from "./handoff-snapshot.js";
import { createChildEnvironmentFactory } from "./child-environment.js";
import {
  createExecutionGrantAuthority,
  type ExecutionGrantAuthority,
} from "./execution-grants.js";
import type {
  ExecutionHost,
  ExecutionHostRunBinding,
} from "./execution-host.js";
import type {
  McpConfigurationAttestation,
  RunnerInternalExecutionContext,
} from "./runner-internal-execution-context.js";
import {
  createProcessBackendRegistration,
  createProcessBackendRegistry,
} from "./process-backend.js";
import { createPosixProcessBackend } from "./posix-process-backend.js";
import { probeProcessHostSemantics, selectWindowsProcessBackendKinds, type ProcessHostSemanticFacts } from "./process-host-semantic-probes.js";
import { createWindowsProcessBackend, WindowsJobObjectProcessBackend } from "./windows-process-backend.js";
import { createWindowsProcessSemanticProbeSource } from "./windows-process-semantic-probes.js";
import { createSubprocessRuntimeKernel } from "./subprocess-runtime.js";
import {
  ProcessRecoveryController,
  createAgentProcessRecoveryGenerator,
  createSubprocessProcessRecoveryRuntime,
  type ProcessRecoveryRuntime,
} from "./process-recovery.js";
import {
  createBoundedProcessOutputFactory,
  bindCommandEvidenceReuse,
  createRuntimeBackedOneShotCommandExecutor,
  type OneShotCommandExecutor,
} from "./one-shot-command-executor.js";

export type NativeBuildRuntimeResourceStage =
  | "execution_host_binding"
  | "mcp_discovery"
  | "mcp_manager"
  | "capabilities"
  | "execution_isolation"
  | "subprocess_runtime"
  | "evidence_store"
  | "scheduler_store"
  | "session_store"
  | "tool_ledger"
  | "budget_ledger"
  | "workspace_manager"
  | "integration_workspace"
  | "verification_workspace"
  | "independent_verifier_workspace"
  | "independent_verifier_baseline_workspace"
  | "memory_store"
  | "managed_process_service";

export type NativeBuildRuntimeInitializationStage =
  | NativeBuildRuntimeResourceStage
  | "baseline"
  | "runtime_configuration"
  | "models"
  | "runtime_drivers";

/** A bounded, attributable failure while rebuilding a live native Build. */
export class NativeBuildRuntimeInitializationError extends Error {
  constructor(
    readonly stage: NativeBuildRuntimeInitializationStage,
    message: string,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = "NativeBuildRuntimeInitializationError";
  }
}

export type NativeBuildRecoveryErrorClassification =
  | { kind: "capability"; code: RunnerCapabilityContractErrorCode }
  | { kind: "runtime"; stage: NativeBuildRuntimeInitializationStage };

/**
 * Cleanup aggregation must not erase the attributable construction failure.
 * The primary error is always first, but recursively walking also handles the
 * capability loader's own startup-plus-cleanup aggregate.
 */
export function classifyNativeBuildRecoveryError(
  error: unknown,
): NativeBuildRecoveryErrorClassification | undefined {
  return classifyNativeBuildRecoveryErrorValue(error, new Set());
}

function classifyNativeBuildRecoveryErrorValue(
  error: unknown,
  seen: Set<unknown>,
): NativeBuildRecoveryErrorClassification | undefined {
  if (seen.has(error)) return undefined;
  seen.add(error);
  if (error instanceof RunnerCapabilityContractError) {
    return { kind: "capability", code: error.code };
  }
  if (error instanceof NativeBuildRuntimeInitializationError) {
    return { kind: "runtime", stage: error.stage };
  }
  if (error instanceof AggregateError) {
    for (const nested of error.errors) {
      const classified = classifyNativeBuildRecoveryErrorValue(nested, seen);
      if (classified) return classified;
    }
  }
  if (error instanceof Error && error.cause !== undefined) {
    return classifyNativeBuildRecoveryErrorValue(error.cause, seen);
  }
  return undefined;
}

/** Test seam for exercising every construction boundary with real resources. */
export interface NativeBuildRuntimeConstructionHooks {
  afterAcquire?(stage: NativeBuildRuntimeResourceStage): void | Promise<void>;
  beforeCleanup?(stage: NativeBuildRuntimeResourceStage): void | Promise<void>;
}

export interface NativeBuildFactoryOptions {
  /** Explicit injected owner for non-CLI embeddings/tests; never a raw fallback. */
  gitForRun?: (spec: NativeBuildSpec) => RunGitExecutionContext;
  projectRoot: string;
  stateDirectory: string;
  providerConfigs: ProviderConfigStore;
  mcpManager?: McpManager;
  permissions?: SqlitePermissionStore;
  capabilitiesConfig?: RunnerCapabilitiesConfig;
  /** Production supplies the single CLI-owned execution composition root. */
  executionHost?: ExecutionHost;
  /** Production MCP configuration is attested once, discovered ephemerally per run, then bound live per run. */
  mcpServers?: readonly import("./mcp-tools.js").McpServerSpec[];
  mcpAttestation?: readonly McpConfigurationAttestation[];
  mcpStatusRegistry?: LiveMcpStatusRegistry;
  internalExecutionContext?: RunnerInternalExecutionContext;
  baselineFor(runId: string): string;
  skillRoots?: readonly SharedSkillRoot[];
  /** The CLI owns provider configuration cleanup when it manages the full process lifecycle. */
  closeProviderConfigs?: boolean;
  /** Injected only by focused lifecycle tests; live callers leave this undefined. */
  runtimeConstructionHooks?: NativeBuildRuntimeConstructionHooks;
  /** Injected only by focused construction-order tests. */
  providerModelFactory?: (
    config: RunnerProviderConfig,
    artifacts: ArtifactStore,
  ) => AgentModel;
}

export const NATIVE_BUILD_RUNTIME_RECOVERY_COVERAGE = Object.freeze([
  "processes",
  "backends",
  "isolation",
  "grants",
  "spills",
  "tempRoots",
] as const);

/**
 * T7b: the current event-registered source manifest for a run whose saved
 * spec carries no initial source â€” the latest `planning.source_registered`
 * or `planning.source_amended` payload. Undefined when no source was ever
 * registered. Read-only; the spec store keeps no mutable copy.
 */
function currentEventRegisteredSourceManifest(
  events: readonly SchedulerEvent[],
): ApprovedSourceManifest | undefined {
  let current: ApprovedSourceManifest | undefined;
  for (const event of events) {
    if (
      event.type !== "planning.source_registered" &&
      event.type !== "planning.source_amended"
    ) {
      continue;
    }
    const manifest = (event.payload as { manifest?: unknown }).manifest as
      | ApprovedSourceManifest
      | undefined;
    if (manifest !== undefined) current = manifest;
  }
  return current;
}

const NATIVE_BUILD_ARCHITECT_ACTOR_ID = "architect_1";

export class NativeBuildFactory {
  private readonly artifacts: ArtifactStore;
  private readonly artifactReachability: ArtifactReachabilityGuard;
  private memoryStore: SqliteProjectMemoryStore | undefined;
  private readonly browserBackend: PlaywrightBrowserBackend;
  private managedProcesses: ManagedProcessService | undefined;
  private readonly incompleteConstructionCleanups = new Set<NativeBuildResourceCleanupStack>();
  private closePromise: Promise<void> | undefined;
  private providerConfigsClosed = false;
  private browserBackendClosed = false;
  private closed = false;
  private windowsProcessFactsPromise: Promise<ProcessHostSemanticFacts> | undefined;

  constructor(private readonly options: NativeBuildFactoryOptions) {
    this.artifacts = options.executionHost?.artifacts ??
      new ArtifactStore(join(options.stateDirectory, "artifacts"));
    this.artifactReachability = new ArtifactReachabilityGuard(
      options.stateDirectory,
      this.artifacts
    );
    this.browserBackend = new PlaywrightBrowserBackend(
      join(options.stateDirectory, "browser-sessions")
    );
  }

  async prepareSpec(
    spec: NativeBuildSpec,
    options?: ProvisioningPrepareOptions,
  ): Promise<NativeBuildSpec> {
    if (this.closed) throw new Error("Native Build factory is closed.");
    validateProvisioningPrepareOptions(options);
    let validated: ValidatedApprovedSource | undefined;
    if (options?.approvedSourceInput !== undefined) {
      if (spec.planningPolicy?.version !== 1) {
        throw new Error("An approved source requires explicit planningPolicy version 1 opt-in; refusing to change the run default.");
      }
      if (spec.approvedSource !== undefined) {
        throw new Error(
          "Specify either raw approved-source bytes or a prepared approvedSource manifest, not both.",
        );
      }
      validated = validateApprovedSourceInput(options.approvedSourceInput);
    }
    const config = this.capabilitiesConfig();
    const prepared = {
      ...cloneBuildSpec(spec),
      capabilityContract: await createRunnerCapabilityContractSnapshot(
        config,
        this.options.stateDirectory,
        { commandSearchDirectory: this.options.projectRoot, environment: this.options.executionHost?.filteredEnvironmentSource() ?? {} },
      ),
    };
    if (validated === undefined) return prepared;
    const artifactDigest = computeArtifactDigest(validated.bytes);
    await this.artifacts.put(validated.bytes, validated.mediaType, `approved-source:${spec.runId}`);
    const manifest = buildApprovedSourceManifest({
      runId: spec.runId,
      validated,
      artifactDigest,
      ...(options?.approvedBy !== undefined ? { approvedBy: options.approvedBy } : {}),
      createdAt: spec.createdAt,
    });
    return { ...prepared, approvedSource: manifest };
  }

  async validateRecoveryCapabilityContract(spec: NativeBuildSpec): Promise<void> {
    if (this.closed) throw new Error("Native Build factory is closed.");
    await validateRunnerCapabilityContract(
      spec.capabilityContract,
      this.capabilitiesConfig(),
      { commandSearchDirectory: this.options.projectRoot, environment: this.options.executionHost?.filteredEnvironmentSource() ?? {} },
    );
  }

  async create(spec: NativeBuildSpec): Promise<NativeBuildRuntimeHandle> {
    if (this.closed) throw new Error("Native Build factory is closed.");
    await this.closeIncompleteConstructionResources();
    validateBuildSpec(spec);
    if (!spec.capabilityContract) {
      throw new Error("Native Build runtime requires a Runner-prepared capability contract.");
    }
    await this.validateRecoveryCapabilityContract(spec);
    await validateRunnerCapabilityContractSnapshot(
      spec.capabilityContract,
      this.options.stateDirectory,
    );
    const capabilitiesConfig = runnerCapabilitiesForContract(
      this.capabilitiesConfig(),
      spec.capabilityContract,
    );
    const runRoot = join(this.options.stateDirectory, "builds", safeSegment(spec.runId));
    await mkdir(runRoot, { recursive: true });
    const constructionResources = new NativeBuildResourceCleanupStack(
      this.options.runtimeConstructionHooks,
    );
    let ownedMcpCleanup: RetryableNativeBuildCleanup | undefined;
    let ownedExecutionHostBindingCleanup: RetryableNativeBuildCleanup | undefined;
    let initializationStage: NativeBuildRuntimeInitializationStage = "capabilities";
    try {
    initializationStage = "baseline";
    const baselineRevision = this.options.baselineFor(spec.runId);
    let executionHostBinding: ExecutionHostRunBinding | undefined;
    if (this.options.executionHost) {
      initializationStage = "execution_host_binding";
      executionHostBinding = await this.options.executionHost.bindRun({
        runId: spec.runId,
        permissionProfile: spec.permissionProfile,
        capabilityContract: spec.capabilityContract,
        capabilitiesConfig,
      });
      if (relative(runRoot, executionHostBinding.runRoot) !== "") {
        throw new Error("ExecutionHost returned a mismatched run root.");
      }
      constructionResources.add(
        "execution_host_binding",
        () => ownedExecutionHostBindingCleanup!.close(),
        true,
      );
      ownedExecutionHostBindingCleanup = retryableNativeBuildCleanup(
        () => executionHostBinding!.close(),
      );
      const hostRecovery = await executionHostBinding.recover({
        maxRecords: 1_024,
        timeoutMs: AUTHORIZED_STOP_CLEANUP_TIMEOUT_MS,
      });
      assertIsolationRecoveryClear(hostRecovery.isolation);
      await cleanupRecoveredMcpTransports(executionHostBinding);
      await cleanupRecoveredLspTransports(executionHostBinding);
      await this.options.runtimeConstructionHooks?.afterAcquire?.("execution_host_binding");
    }
    let runMcpManager = this.options.mcpManager;
    if (this.options.internalExecutionContext) {
      const servers = this.options.mcpServers ?? [];
      const attestation = this.options.mcpAttestation ?? [];
      initializationStage = "mcp_discovery";
      const discovery = this.options.internalExecutionContext.createMcpDiscoveryExecutor({
        runId: spec.runId,
        servers,
        attestation,
      });
      let discovered: McpDiscoveryResult;
      try {
        discovered = await discovery.discover();
      } finally {
        await discovery.close();
      }
      await this.options.runtimeConstructionHooks?.afterAcquire?.("mcp_discovery");
      initializationStage = "mcp_manager";
      if (!executionHostBinding) {
        throw new Error("Live per-Build MCP requires its exact ExecutionHost run binding.");
      }
      const runtimeLaunches = await this.options.internalExecutionContext.resolveMcpRuntimeLaunches({
        servers,
        attestation,
      });
      runMcpManager = new McpManager({
        runId: spec.runId,
        discovery: discovered,
        reattest: () => this.options.internalExecutionContext!.resolveMcpRuntimeLaunches({ servers, attestation }),
        cwd: this.options.projectRoot,
        servers,
        transportFactory: createExecutionHostMcpTransportFactory({
          run: executionHostBinding,
          permissionProfile: spec.permissionProfile,
          projectDirectory: this.options.projectRoot,
          launches: runtimeLaunches,
        }),
      });
      const statusRegistration: {
        value?: Readonly<{ dispose(): void }>;
      } = {};
      const ownedMcpManager = runMcpManager;
      ownedMcpCleanup = retryableNativeBuildCleanup(async () => {
        await ownedMcpManager.close();
        statusRegistration.value?.dispose();
      });
      constructionResources.add(
        "mcp_manager",
        () => ownedMcpCleanup!.close(),
        true,
      );
      await runMcpManager.start();
      statusRegistration.value = this.options.mcpStatusRegistry?.register(spec.runId, runMcpManager);
      await this.options.runtimeConstructionHooks?.afterAcquire?.("mcp_manager");
    }
    initializationStage = "execution_isolation";
    const executionIsolation = executionHostBinding?.isolation ??
      await createConfiguredOciIsolationSelector(
        capabilitiesConfig,
        join(runRoot, "execution-isolation"),
      );
    if (!executionHostBinding) {
      assertIsolationRecoveryClear(await executionIsolation.recoverOwnedLeases());
      constructionResources.add("execution_isolation", async () => {
        assertIsolationRecoveryClear(await executionIsolation.recoverOwnedLeases());
      }, true);
    }
    await this.options.runtimeConstructionHooks?.afterAcquire?.("execution_isolation");
    initializationStage = "capabilities";
    const gitContext = executionHostBinding?.git ?? this.options.gitForRun?.(spec);
    const runCapabilities = await createNativeRunCapabilities({
      git: gitContext,
      environment: this.options.executionHost?.filteredEnvironmentSource() ?? {},
      ...(executionHostBinding ? { lspTransportFactory: createExecutionHostLspTransportFactory({
        run: executionHostBinding, permissionProfile: spec.permissionProfile,
        environment: this.options.executionHost!.filteredEnvironmentSource(),
      }) } : {}),
      config: {
        ...capabilitiesConfig,
        extensions: runnerCapabilitySnapshotExtensionDirectories(
          spec.capabilityContract,
          this.options.stateDirectory,
        ),
      },
      projectDirectory: this.options.projectRoot,
      stateDirectory: runRoot,
      verifyExtensionIntegrity: async () => {
        await validateRunnerCapabilityContractSnapshot(
          spec.capabilityContract!,
          this.options.stateDirectory,
        );
      },
      reservedToolNames: [
        ...RUNNER_BUILTIN_TOOL_NAMES,
        ...(runMcpManager
          ? createMcpTools(runMcpManager, this.artifacts).map(
              (tool) => tool.definition.name,
            )
          : []),
      ],
    });
    constructionResources.add("capabilities", () => runCapabilities.close(), true);
    await runCapabilities.preflight();
    await this.options.runtimeConstructionHooks?.afterAcquire?.("capabilities");
    initializationStage = "runtime_configuration";
    const selected = selectRuntimeCandidates(
      this.options.providerConfigs.load(),
      spec
    );
    const selectedConfigs = selected.configs;
    assertEnforceableBuildBudget(spec, selectedConfigs);
    const candidates = selected.all;
    const workerCandidates = selected.workers;
    const modelUsageRuntimes = selectedConfigs.map((config) =>
      configuredModelUsageRuntime(config, spec)
    );
    const modelCostEstimators = new Map<string, ModelCostEstimator>(
      selectedConfigs.flatMap((config) => {
        const estimator = providerCostEstimator(config);
        return estimator ? [[config.runtimeId, estimator] as const] : [];
      })
    );
    const modelCostBases = new Map<string, ModelCostBasisSnapshot>(
      selectedConfigs.map((config) => [config.runtimeId, providerModelCostBasis(config)])
    );
    initializationStage = "evidence_store";
    const evidenceStore = new SqliteEvidenceStore(join(runRoot, "evidence.sqlite"));
    constructionResources.add("evidence_store", () => evidenceStore.close(), true);
    await this.options.runtimeConstructionHooks?.afterAcquire?.("evidence_store");
    const finalVerificationPorts = new FinalVerificationPortAuthority(this.options.stateDirectory);
    const finalVerificationProfiles = new FinalVerificationProfileAuthority({
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      portAuthority: finalVerificationPorts,
      ambientEnvironment: this.options.executionHost?.filteredEnvironmentSource() ?? snapshotNativeBuildAmbientEnvironment(),
    });
    initializationStage = "scheduler_store";
    const schedulerStore = new SqliteSchedulerStore(join(runRoot, "scheduler.sqlite"), {
      evidenceStore,
      artifacts: this.artifacts,
      validateCleanupReceipt: (identity) =>
        validateOwnedFinalVerificationCleanupReceipt(this.options.stateDirectory, identity),
      validateExecutionProfile: ({ targetRevision, profile }) =>
        finalVerificationProfiles.validate(profile, targetRevision),
    });
    constructionResources.add("scheduler_store", () => schedulerStore.close(), true);
    await this.options.runtimeConstructionHooks?.afterAcquire?.("scheduler_store");
    // T7a: early explicit-policy/source provisioning — immediately after
    // opening scheduler storage and before any factory consumer reads
    // planning/docs policy or creates run integration/context resources.
    // Legacy specs (no planningPolicy) pass through untouched.
    if (spec.approvedSource !== undefined) {
      if (spec.planningPolicy?.version !== 1) {
        throw new Error(
          "Build spec approvedSource requires explicit planningPolicy version 1 opt-in.",
        );
      }
      let storedBytes: Uint8Array;
      try {
        storedBytes = await this.artifacts.get(spec.approvedSource.artifactDigest);
      } catch (error) {
        throw new Error(
          `Approved source artifact ${spec.approvedSource.artifactDigest} is not provisioned for ${spec.runId}.`,
          { cause: error },
        );
      }
      verifyPreparedApprovedSource({
        runId: spec.runId,
        manifest: spec.approvedSource,
        storedBytes,
        createdAt: spec.createdAt,
      });
    }
    ensurePlanningProvisioningPrefix(schedulerStore, spec);
    if (spec.planningPolicy?.version === 1) {
      // Lane-B guards activate only during fresh explicit-policy
      // construction, immediately after the T7a prefix (sequences 4-5),
      // before source registration. A log carrying run history beyond
      // the bare construction stamps is a recovery and is never
      // restamped: historical shape is preserved, and the
      // pending-guidance/open-question gates (which correctly deny
      // mid-log advancement) are never tripped by factory creation. The
      // bare-prefix-plus-evidence shape covers a crash between the two
      // stamps; anything longer is real history.
      const constructionEvents = schedulerStore.readRun(spec.runId);
      const barePrefix = constructionEvents.length === 3;
      const barePrefixPlusEvidence =
        constructionEvents.length === 4 &&
        constructionEvents[3]?.type === "run.evidence_policy_activated";
      if (barePrefix || barePrefixPlusEvidence) {
        if (rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).evidenceContentPolicyVersion !== 1) {
          schedulerStore.append({runId: spec.runId, type: "run.evidence_policy_activated", actor: {role: "runner", id: "build-runtime"}, occurredAt: new Date().toISOString(), idempotencyKey: "evidence-content-policy:v1", payload: {version: 1}});
        }
        const integrityInitialization = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).testIntegrity;
        if (integrityInitialization && integrityInitialization.initialRevision === undefined) {
          schedulerStore.append({ runId: spec.runId, type: "delivery.test_integrity_initialized", occurredAt: spec.createdAt,
            actor: { role: "runner", id: "build-runtime" }, idempotencyKey: "test-integrity-initial-revision:v1",
            payload: { revision: baselineRevision, architectActorId: NATIVE_BUILD_ARCHITECT_ACTOR_ID } });
        }
      }
    } else if (schedulerStore.readRun(spec.runId).length === 0) {
      // Fresh legacy run (no planningPolicy): initialize legitimately
      // before any factory consumer reads the projection, mirroring
      // BuildRuntime's legacy order (docs policy v1, then
      // run.initialized carrying the spec objective).
      // BuildRuntime.initializeRun runs later and reuses these durable
      // records. Recovered legacy logs are never restamped, and the
      // downgrade guard above still refuses a legacy spec against a
      // recorded new-policy prefix.
      schedulerStore.append({ runId: spec.runId, type: "project_docs.policy_configured", occurredAt: spec.createdAt,
        actor: { role: "runner", id: "build-runtime" }, idempotencyKey: "project-docs-policy", payload: { version: 1 } });
      schedulerStore.append({ runId: spec.runId, type: "run.initialized", occurredAt: spec.createdAt,
        actor: { role: "runner", id: "build-runtime" }, idempotencyKey: "run-initialized",
        payload: { objective: spec.objective } });
    }
    if (spec.approvedSource !== undefined) {
      registerApprovedSource(
        schedulerStore,
        spec.runId,
        spec.approvedSource,
        approvedSourceApprover(spec.approvedSource),
      );
    }
    // Authenticated, saved per-run user intent. Before model calls, once only;
    // a later durable opt-out remains authoritative through restart.
    if (spec.answerReview === true) {
      const approvalKey = `${spec.idempotencyKey}:answer-review-opt-in`;
      if (!schedulerStore.readRun(spec.runId).some((event) => event.idempotencyKey === approvalKey)) {
        schedulerStore.append({ runId: spec.runId, type: "answer.review_opted_in", occurredAt: spec.createdAt,
          actor: { role: "user", id: "local-user" }, idempotencyKey: approvalKey, payload: {} });
      }
    }
    const schedulerEvents = schedulerStore.readRun(spec.runId);
    // T7b: a saved spec without an initial source may still carry a later
    // owner-registered current source in its durable events (post-creation
    // approval or amendment). Verify those bytes exist and match before any
    // consumer reads them; no mutable current-source state is duplicated
    // into the spec store. Missing or drifted bytes fail closed here.
    if (spec.planningPolicy?.version === 1) {
      const currentManifest = currentEventRegisteredSourceManifest(schedulerEvents);
      if (currentManifest !== undefined) {
        let storedBytes: Uint8Array;
        try {
          storedBytes = await this.artifacts.get(currentManifest.artifactDigest);
        } catch (error) {
          throw new Error(
            `Registered source artifact ${currentManifest.artifactDigest} is not provisioned for ${spec.runId}.`,
            { cause: error },
          );
        }
        assertManifestMatchesBytes(currentManifest, storedBytes);
      }
    }
    initializationStage = "session_store";
    // T6b repair (OA-17): Runner-private durable creation records for
    // this run, keyed to the real run and project ids. The temp-path
    // search below reads these same records, so writers and the search
    // always agree on keys.
    const tempRecorders = createSchedulerTempRecorders(schedulerStore, { runId: spec.runId, projectId: spec.projectId }, () => new Date().toISOString());
    const sessions = new SqliteAgentSessionStore(
      join(runRoot, "sessions.sqlite"),
      this.artifacts,
      {
        deleteArtifactIfGloballyUnreachable: (hash) =>
          this.artifactReachability.removeIfGloballyUnreachable(hash),
      }
    );
    constructionResources.add("session_store", () => sessions.close(), true);
    await this.options.runtimeConstructionHooks?.afterAcquire?.("session_store");
    initializationStage = "tool_ledger";
    const ledger = new SqliteToolLedger(join(runRoot, "tool-ledger.sqlite"));
    const contextManifests = new SqliteContextManifestStore(join(runRoot, "context-manifests.sqlite"));
    constructionResources.add("tool_ledger", () => {
      contextManifests.close();
      ledger.close();
    }, true);
    await this.options.runtimeConstructionHooks?.afterAcquire?.("tool_ledger");
    initializationStage = "budget_ledger";
    const budgetLedger = new SqliteBudgetLedger(join(runRoot, "budget.sqlite"), {
      limitsFor: (scopeId) => {
        if (scopeId === spec.runId) return { ...spec.budgetLimits };
        if (isRunValidationBudgetScope(scopeId, spec.runId)) return {};
        throw new Error(`Unknown budget scope ${scopeId}.`);
        return { ...spec.budgetLimits };
      },
    });
    constructionResources.add("budget_ledger", () => budgetLedger.close(), true);
    await this.options.runtimeConstructionHooks?.afterAcquire?.("budget_ledger");
    budgetLedger.recoverInterruptedActive(
      spec.runId,
      `startup-recovery:${spec.runId}`,
    );
    initializationStage = "workspace_manager";
    const workspaceManager = new WorkspaceManager({
      execute: requireGitRunner(gitContext).lifecycle("workspace").run,
      repositoryRoot: this.options.projectRoot,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      baselineRevision,
    });
    constructionResources.add("workspace_manager", () => workspaceManager.cleanup());
    await this.options.runtimeConstructionHooks?.afterAcquire?.("workspace_manager");
    initializationStage = "integration_workspace";
    const integrationManager = new IntegrationManager({
      execute: requireGitRunner(gitContext).lifecycle("integration").run,
      executeBytes: requireGitRunner(gitContext).lifecycle("integration").runBytes,
      repositoryRoot: this.options.projectRoot,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      baselineRevision,
      initializationMode: integrationInitializationModeFromEvents(schedulerEvents),
    });
    constructionResources.add("integration_workspace", () => integrationManager.cleanup());
    await integrationManager.initialize();
    await this.options.runtimeConstructionHooks?.afterAcquire?.("integration_workspace");
    const docsV2 = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).projectDocsPolicyVersion === 2;
    const snapshotVerificationOptions = docsV2 ? {
      validateCanonicalState: async (input: { targetRevision: string; canonicalRevision: string }) =>
        validateKernelSnapshotVerificationAdvance({
          ...input,
          projection: rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)),
          integrationManager,
          execute: requireGitRunner(gitContext).lifecycle("verification").run,
        }),
    } : {};
    const verificationRevisionSource = docsV2 ? {
      get revision(): string {
        const revision = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).integrationRevision;
        if (!revision) throw new Error("Final verification requires the authoritative canonical revision.");
        return revision;
      },
    } : integrationManager;
    initializationStage = "verification_workspace";
    const verificationWorkspace = new VerificationWorkspaceManager({
      execute: requireGitRunner(gitContext).lifecycle("verification").run,
      repositoryRoot: integrationManager.path,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      integrationManager: verificationRevisionSource,
      ...snapshotVerificationOptions,
    });
    constructionResources.add("verification_workspace", () => verificationWorkspace.cleanup());
    await this.options.runtimeConstructionHooks?.afterAcquire?.("verification_workspace");
    initializationStage = "independent_verifier_workspace";
    const verifierWorkspace = new VerificationWorkspaceManager({
      execute: requireGitRunner(gitContext).lifecycle("verification").run,
      repositoryRoot: integrationManager.path,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      ...(!docsV2 ? { integrationManager } : {}),
      kind: "independent-verifier",
      ...snapshotVerificationOptions,
    });
    // Every caller pins the exact scheduler-derived target revision, so no
    // live-tip default: after a kernel snapshot the tip is a snapshot, not
    // the verified target, and resolving it would strand the check.
    const architectCommandWorkspace = new VerificationWorkspaceManager({
      execute: requireGitRunner(gitContext).lifecycle("verification").run,
      repositoryRoot: integrationManager.path,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      ...(!docsV2 ? { integrationManager } : {}),
      kind: "independent-verifier",
      workspaceSuffix: "architect-commands",
    });
    const deliveryWorkspaceFor = (suffix: string) => (targetRevision?: string) => new VerificationWorkspaceManager({
      execute: requireGitRunner(gitContext).lifecycle("verification").run,
      repositoryRoot: integrationManager.path,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      kind: "independent-verifier",
      workspaceSuffix: suffix,
      // Pinned to the exact task or integration revision under check.
      ...(targetRevision ? { targetRevision } : { integrationManager }),
    });
    const deliveryReviewWorkspace = createDeliveryWorkspaceSlot(deliveryWorkspaceFor("delivery-review"));
    const deliveryBoundaryWorkspace = createDeliveryWorkspaceSlot(deliveryWorkspaceFor("delivery-boundary"));
    const testIntegrityBaselineWorkspace = createDeliveryWorkspaceSlot(deliveryWorkspaceFor("test-integrity-baseline"));
    constructionResources.add(
      "independent_verifier_workspace",
      async () => {
        try {
          await verifierWorkspace.cleanup();
        } finally {
          try {
            await architectCommandWorkspace.cleanup();
          } finally {
            try {
              await deliveryReviewWorkspace.cleanup();
            } finally {
              try { await deliveryBoundaryWorkspace.cleanup(); }
              finally { await testIntegrityBaselineWorkspace.cleanup(); }
            }
          }
        }
      },
    );
    await this.options.runtimeConstructionHooks?.afterAcquire?.("independent_verifier_workspace");
    initializationStage = "independent_verifier_baseline_workspace";
    const verifierBaselineWorkspace = new VerificationWorkspaceManager({
      execute: requireGitRunner(gitContext).lifecycle("verification").run,
      repositoryRoot: integrationManager.path,
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      ...(!docsV2 ? { integrationManager } : {}),
      kind: "independent-verifier",
      workspaceSuffix: "baseline",
    });
    constructionResources.add(
      "independent_verifier_baseline_workspace",
      () => verifierBaselineWorkspace.cleanup(),
    );
    await this.options.runtimeConstructionHooks?.afterAcquire?.("independent_verifier_baseline_workspace");
    // T6b repair (R3 N-6): the disposable verification checkouts are
    // creation-recorded here at creation time — not at the first cleanup
    // search — so a crash before the first search still leaves an
    // owner-visible record. Retained: their own manager removes them; the
    // policy-gated search only reads these records. Bookkeeping never
    // breaks creation (and re-creation is an idempotent no-op).
    for (const workspacePath of nativeBuildCleanupRoots(this.options.stateDirectory, spec.runId)) {
      try {
        tempRecorders.recorded({ path: workspacePath, ownerRunId: spec.runId, kind: "directory", createdAt: new Date().toISOString(), retained: true });
      } catch { /* bookkeeping never breaks workspace creation */ }
    }
    if (
      schedulerEvents.length > 0 &&
      rebuildSchedulerProjection(schedulerEvents).verifier?.current?.status ===
        "submitted"
    ) {
      await verifierWorkspace.cleanup();
      await verifierBaselineWorkspace.cleanup();
    }
    const finalVerificationCleanup = new OwnedFinalVerificationCleanup({
      stateDirectory: this.options.stateDirectory,
      runId: spec.runId,
      stopRun: (runId) => this.liveManagedProcesses().stopRun(runId),
      closeBrowserRun: (runId) => this.browserBackend.closeRun(runId),
      workspaceManager: verificationWorkspace,
      diagnostics: new FinalVerificationDiagnosticsArchive({
      execute: requireGitRunner(gitContext).lifecycle("verification").run,
        stateDirectory: this.options.stateDirectory,
        runId: spec.runId,
        workspaceManager: verificationWorkspace,
      }),
    });
    const hadMemoryStore = this.memoryStore !== undefined;
    initializationStage = "memory_store";
    const memoryStore = this.liveMemoryStore();
    if (!hadMemoryStore) {
      constructionResources.add("memory_store", () => {
        memoryStore.close();
        if (this.memoryStore === memoryStore) this.memoryStore = undefined;
      });
    }
    await this.options.runtimeConstructionHooks?.afterAcquire?.("memory_store");
    const hadManagedProcesses = this.managedProcesses !== undefined;
    initializationStage = "managed_process_service";
    const managedProcesses = executionHostBinding?.managedProcesses ?? this.liveManagedProcesses();
    if (!executionHostBinding && !hadManagedProcesses) {
      constructionResources.add("managed_process_service", async () => {
        await managedProcesses.close();
        if (this.managedProcesses === managedProcesses) this.managedProcesses = undefined;
      });
    }
    await this.options.runtimeConstructionHooks?.afterAcquire?.("managed_process_service");
    initializationStage = "subprocess_runtime";
    let executionGrants: ExecutionGrantAuthority;
    let commandExecution: OneShotCommandExecutor;
    let processRecoveryRuntime: ProcessRecoveryRuntime;
    if (executionHostBinding) {
      executionGrants = executionHostBinding.executionGrants;
      commandExecution = executionHostBinding.commandExecution;
      processRecoveryRuntime = executionHostBinding.processRecoveryRuntime;
    } else {
    const windowsJobHost = createWindowsJobProcessHost({ stateDirectory: join(this.options.stateDirectory, "managed-processes-job-host") });
    const childEnvironments = createChildEnvironmentFactory({
      credentialResolver: {
        consume: () => {
          throw new Error("No Runner child-environment credential grant is configured.");
        },
      },
    });
    const windowsFacts = process.platform === "win32"
      ? await (this.windowsProcessFactsPromise ??= probeProcessHostSemantics({
          ...createWindowsProcessSemanticProbeSource({
            ambientEnvironment: this.options.executionHost?.filteredEnvironmentSource() ?? snapshotNativeBuildAmbientEnvironment(),
          }),
          activeJobCreateClose: async () => await windowsJobHost.probeActiveJobCreateClose(),
        }))
      : undefined;
    const windowsPortableBackend = process.platform === "win32" && windowsFacts
      ? createWindowsProcessBackend({ stateDirectory: join(runRoot, "process-backend"), jobObjects: "unavailable", semanticFacts: windowsFacts })
      : undefined;
    const windowsBackendKinds = new Set(windowsFacts ? selectWindowsProcessBackendKinds(windowsFacts) : []);
    const processBackends = process.platform === "win32"
      ? [
          ...(windowsBackendKinds.has("job") ? [{
            stableAdapterId: "runner-windows-job-adapter-v1",
            backendId: "runner-windows-job-v1",
            codeIdentity: "runner-v2/windows-job-process-backend@1",
            backend: new WindowsJobObjectProcessBackend(
              windowsJobHost,
              windowsFacts!.windowsBatchArgv,
              windowsFacts!.jobContainment,
            ),
          }] : []),
          ...(windowsBackendKinds.has("portable") ? [{
            stableAdapterId: "runner-windows-portable-adapter-v1",
            backendId: "runner-windows-supervisor-v1",
            codeIdentity: "runner-v2/windows-portable-process-backend@1",
            backend: windowsPortableBackend!,
          }] : []),
        ]
      : [{
          stableAdapterId: "runner-posix-process-group-adapter-v1",
          backendId: "runner-posix-process-group-v1",
          codeIdentity: "runner-v2/posix-process-backend@1",
          backend: createPosixProcessBackend({ stateDirectory: join(runRoot, "process-backend") }),
        }];
    const subprocessKernel = createSubprocessRuntimeKernel({
      registry: createProcessBackendRegistry(processBackends.map((processBackend) =>
        createProcessBackendRegistration({
          stableAdapterId: processBackend.stableAdapterId,
          backendId: processBackend.backendId,
          codeDigest: createHash("sha256")
            .update(processBackend.codeIdentity)
            .digest("hex"),
          configDigest: createHash("sha256")
            .update("runner-v2/native-one-shot-process-backend@1")
            .digest("hex"),
          backend: processBackend.backend,
        }),
      )),
      state: { kind: "sqlite", path: join(runRoot, "subprocess-runtime.sqlite") },
      stateKey: await loadOrCreateProcessStateKey(join(runRoot, "subprocess-runtime.key")),
      clock: {
        now: () => new Date(),
        sleep: async (milliseconds) => await new Promise<void>((resolveSleep) => {
          const timer = setTimeout(resolveSleep, milliseconds);
          timer.unref();
        }),
      },
      environments: childEnvironments,
      outputs: createBoundedProcessOutputFactory({
        spillRoot: join(runRoot, "subprocess-output"),
        projectRoot: this.options.projectRoot,
        artifacts: this.artifacts,
      }),
    });
    await subprocessKernel.runtime.reconcileStartup();
    executionGrants = createExecutionGrantAuthority();
    commandExecution = createRuntimeBackedOneShotCommandExecutor({
      runtime: subprocessKernel.runtime,
      runtimeGrants: subprocessKernel.grantsController,
      executionGrants,
      isolation: executionIsolation,
      permissionProfile: spec.permissionProfile,
      ambientEnvironment: snapshotNativeBuildAmbientEnvironment(),
      environments: childEnvironments,
    });
    processRecoveryRuntime = createSubprocessProcessRecoveryRuntime({
      runtime: subprocessKernel.runtime,
      canRecoverExceptional: subprocessKernel.canRecoverExceptional,
      store: subprocessKernel.readOnlyStore,
      executionGrants,
      permissionProfile: spec.permissionProfile,
      workspacePath: this.options.projectRoot,
    });
    constructionResources.add("subprocess_runtime", async () => {
      await executionGrants.revokeAll("cleanup");
      await subprocessKernel.runtime.reconcileStartup();
      subprocessKernel.readOnlyStore.close();
    }, true);
    }
    await this.options.runtimeConstructionHooks?.afterAcquire?.("subprocess_runtime");
    bindCommandEvidenceReuse(commandExecution, spec.runId, {store: evidenceStore, artifacts: this.artifacts,
      captureTree: async (cwd, request) => {
        const captured = await gitContext?.workingTreeForCurrentCall?.(cwd);
        if (captured) return captured;
        // Model commands without their original call scope cannot borrow lifecycle authority.
        if (!request.context.runnerInternal) return {status: "unknown", reason: "capture_unavailable"};
        return await workingTreeForRunner(requireGitRunner(gitContext).lifecycle("verification").run, cwd);
      }});
    const initialHealth = providerHealthFromSchedulerEvents(
      schedulerStore.readRun(spec.runId)
    );
    const health = new ProviderHealthRegistry({ initial: initialHealth });
    const workerRouter = new RuntimeRouter({
      candidates: workerCandidates,
      health,
    });
    const architectRouter = new RuntimeRouter({ candidates, health });
    const verifierRouter = new RuntimeRouter({ candidates, health });
    const skillCatalog = new SkillCatalog({
      projectRoot: this.options.projectRoot,
      sharedRoots: this.options.skillRoots ?? defaultSharedSkillRoots(),
    });
    initializationStage = "models";
    const providerModelFactory = this.options.providerModelFactory ?? createProviderModel;
    const models = new Map<string, AgentModel>(
      selectedConfigs.map((config) => [
        config.runtimeId,
        providerModelFactory(config, this.artifacts),
      ])
    );
    const recoveryModel = models.get(spec.architectRuntimeId);
    if (!recoveryModel) throw new Error("Exceptional recovery requires the configured Architect runtime.");
    const processRecovery = new ProcessRecoveryController({
      runId: spec.runId,
      store: schedulerStore,
      runtime: processRecoveryRuntime,
      generate: createAgentProcessRecoveryGenerator({ model: recoveryModel }),
    });
    initializationStage = "runtime_drivers";
    const workerDriver = new NativeWorkerDriver({
      git: gitContext,
      schedulerStore,
      router: workerRouter,
      validationBudgetMsForTask: async ({ baselineRevision, workspacePath }) =>
        readValidationBudgetMsAtRevision({ git: requireGitRunner(gitContext).lifecycle("inspection").run, cwd: workspacePath, revision: baselineRevision }),
      health,
      candidates: workerCandidates,
      models,
      permissionProfile: spec.permissionProfile,
      workspaceManager,
      artifacts: this.artifacts,
      ledger,
      sessions,
      evidenceStore,
      skillCatalog,
      memoryStore,
      projectId: spec.projectId,
      projectRoot: this.options.projectRoot,
      capabilityRegistry: runCapabilities.registry,
      language: runCapabilities.language,
      budgetLedger,
      modelCostEstimators,
      modelCostBases,
      browserBackend: this.browserBackend,
      ...(runMcpManager ? { mcpManager: runMcpManager } : {}),
      ...(this.options.permissions ? { permissions: this.options.permissions } : {}),
      managedProcesses,
      execution: commandExecution,
      executionGrants,
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
      defectClassesFor: () => topDefectClasses(this.liveMemoryStore().defectClasses(spec.projectId)),
      ...(spec.benchmark
        ? {
            allowedCommands: spec.benchmark.allowedCommands,
            hiddenPaths: spec.benchmark.hiddenPaths,
            protectedPaths: spec.benchmark.protectedPaths,
          }
        : {}),
    });
    const architectDriver = new NativeArchitectRuntime({
      git: gitContext,
      executionGrants,
      schedulerStore,
      router: architectRouter,
      health,
      candidates,
      models,
      initialRuntimeId: spec.architectRuntimeId,
      sessions,
      artifacts: this.artifacts,
      skillCatalog,
      memoryStore,
      evidenceStore,
      projectId: spec.projectId,
      projectRoot: this.options.projectRoot,
      canonicalProjectRoot: integrationManager.path,
      objective: spec.objective,
      runPolicy: spec.runPolicy,
      capabilityRegistry: runCapabilities.registry,
      language: runCapabilities.language,
      ...(spec.benchmark
        ? {
            allowedCommands: spec.benchmark.allowedCommands,
            hiddenPaths: spec.benchmark.hiddenPaths,
            protectedPaths: spec.benchmark.protectedPaths,
          }
        : {}),
      budgetLedger,
      modelCostEstimators,
      modelCostBases,
      permissionProfile: spec.permissionProfile,
      ledger,
      ...(this.options.permissions ? { permissions: this.options.permissions } : {}),
      browserBackend: this.browserBackend,
      ...(runMcpManager ? { mcpManager: runMcpManager } : {}),
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
      commandWorkspace: {
        workspaceKind: "independent-verifier" as const,
        create: (targetRevision: string) => architectCommandWorkspace.create(targetRevision),
        cleanup: () => architectCommandWorkspace.cleanup(),
      },
      // T9 (EP41): answer-path command base revision — the integration
      // baseline, since answered runs have no integration revision yet.
      answerCommandRevision: integrationManager.revision,
      execution: commandExecution,
      // C4 (AR-R11): live base-snapshot read for docs-v2 triage/planning
      // turns. The revision is captured HERE, at each eligible context —
      // never at factory construction — through the audited Git read path
      // with case guards. No user-tree or unbound-HEAD read: only the
      // immutable blob at the manager's current revision. A missing or
      // unreadable blob reports null content at its revision (honestly
      // unavailable); a read failure reports no snapshot at all.
      readBaseSnapshot: async () => {
        let revision: string;
        try {
          revision = integrationManager.revision;
        } catch {
          return undefined;
        }
        try {
          const stored = await integrationManager.readHandoffSnapshotFile({
            commit: revision,
            path: "docs/project/STATE.md",
          });
          return { revision, content: stored.content };
        } catch {
          return undefined;
        }
      },
    });
    const verifierWorkspaceProvider = {
      workspaceKind: "independent-verifier" as const,
      create: async (targetRevision: string) =>
        await verifierWorkspace.create(targetRevision),
      createBaseline: (revision: string) => verifierBaselineWorkspace.create(revision),
      cleanupBaseline: () => verifierBaselineWorkspace.cleanup(),
    };
    const nativeVerifier = new NativeVerifierRuntime({
      git: gitContext,
      executionGrants,
      router: verifierRouter,
      candidates,
      models,
      verifierRuntimeIds: spec.verifierRuntimeIds,
      sessions,
      artifacts: this.artifacts,
      evidenceStore,
      workspaceManager: verifierWorkspaceProvider,
      budgetLedger,
      ledger,
      modelCostEstimators,
      modelCostBases,
      permissionProfile: spec.permissionProfile,
      ...(this.options.permissions ? { permissions: this.options.permissions } : {}),
      execution: commandExecution,
      verdictAuthority: new SchedulerVerifierVerdictAuthority(schedulerStore),
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
    });
    const planCritic = new NativePlanCriticRuntime({
      git: gitContext,
      executionGrants,
      router: verifierRouter,
      candidates,
      models,
      verifierRuntimeIds: spec.verifierRuntimeIds,
      sessions,
      artifacts: this.artifacts,
      workspaceManager: verifierWorkspaceProvider,
      critiqueAuthority: new SchedulerPlanCritiqueAuthority(schedulerStore),
      budgetLedger,
      ledger,
      modelCostEstimators,
      modelCostBases,
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
    });
    const planCriticDriver: PlanCriticDriver = {
      candidateRuntimeIds: [...spec.verifierRuntimeIds],
      mode: spec.planCritique ?? "risk_based",
      stricterQualification: spec.alwaysRequireIndependentVerifier,
      architectDeclaration: (projection) => projection.planRiskDeclaration?.risk ?? "low",
      critique: async ({ projection, riskReasons, preferredRuntimeId, signal }) => {
        const result = await planCritic.critique(buildPlanCritiqueRequest({
          runId: spec.runId,
          objective: spec.objective,
          architectRuntimeId: projection.runtime.architect.runtimeId ?? spec.architectRuntimeId,
          projection,
          baselineRevision: integrationManager.revision,
          riskReasons,
          ...(preferredRuntimeId ? { preferredRuntimeId } : {}),
          ...(signal ? { signal } : {}),
          providerRetryDeadlineMs: runnerProviderRetryDeadlineMs(
            spec.budgetLimits.maxActiveMs,
            budgetLedger.snapshot(spec.runId).effective.activeMs,
            Date.now(),
          ),
        }));
        if (result.status === "submitted") {
          await verifierWorkspace.cleanup();
          return { status: "submitted", critiqueId: result.critiqueId };
        }
        if (result.status === "unavailable") return { status: "unavailable", reason: result.reason };
        return { status: "suspended", reason: result.reason, runtimeId: result.runtimeId, ...(result.error ? { error: result.error } : {}) };
      },
    };
    const independentVerifier: IndependentVerifierDriver = {
      candidateRuntimeIds: [...spec.verifierRuntimeIds],
      alwaysRequireIndependentVerifier:
        spec.alwaysRequireIndependentVerifier,
      twoPass: spec.verifierTwoPass ?? true,
      assessRisk: async ({ projection }) => deriveNativeVerifierRiskInput({
        projection,
        sessions: await sessions.listRun(spec.runId),
        schedulerEvents: schedulerStore.readRun(spec.runId),
        toolEvents: ledger.listRun(spec.runId),
        stricterQualification: spec.alwaysRequireIndependentVerifier,
      }),
      verify: async (request) => {
        const result = await nativeVerifier.inspect(
          buildNativeVerifierInspectionRequest({
            runId: spec.runId,
            objective: spec.objective,
            architectRuntimeId:
              request.projection.runtime.architect.runtimeId ??
              spec.architectRuntimeId,
            projection: request.projection,
            sessions: await sessions.listRun(spec.runId),
            schedulerEvents: schedulerStore.readRun(spec.runId),
            twoPass: spec.verifierTwoPass ?? true,
            risk: request.risk,
            ...(request.preferredRuntimeId
              ? { preferredRuntimeId: request.preferredRuntimeId }
              : {}),
            ...(request.signal ? { signal: request.signal } : {}),
            providerRetryDeadlineMs: runnerProviderRetryDeadlineMs(
              spec.budgetLimits.maxActiveMs,
              budgetLedger.snapshot(spec.runId).effective.activeMs,
              Date.now(),
            ),
          }),
        );
        if (
          (result.status === "verdict_submitted" ||
            (result.status === "suspended" && result.reason === "provider_error")) &&
          result.runtimeId
        ) {
          const candidate = candidates.find(
            (item) => item.runtimeId === result.runtimeId,
          );
          if (candidate) {
            persistProviderHealth(
              schedulerStore,
              spec.runId,
              health.get(candidate.providerId),
              `verifier:${result.runtimeId}`,
            );
          }
        }
        if (result.status === "verdict_submitted") {
          await verifierWorkspace.cleanup();
          await verifierBaselineWorkspace.cleanup();
          return { status: "verdict_submitted" };
        }
        if (result.status === "unavailable") {
          return { status: "unavailable", reason: result.reason };
        }
        if (result.status === "suspended") {
          return {
            status: "suspended",
            reason: result.reason,
            runtimeId: result.runtimeId,
            ...(result.error ? { error: result.error } : {}),
          };
        }
        return {
          status: "suspended",
          reason: `unexpected_verifier_result:${result.status}`,
        };
      },
    };
    // T3b: the independent source-coverage reviewer. Reuses the verifier
    // candidate pool (the OA-3 selector picks a distinct model when one
    // exists), the shared sessions/artifacts/evidence/manifests, and the
    // project root for read-only inspection. Source bytes still come from the
    // artifact store by digest until T7 provisions the planning source reader.
    const nativeCoverageReview = new NativeCoverageReviewRuntime({
      git: gitContext,
      executionGrants,
      router: verifierRouter,
      candidates,
      models,
      coverageRuntimeIds: spec.verifierRuntimeIds,
      sessions,
      artifacts: this.artifacts,
      evidenceStore,
      projectRoot: this.options.projectRoot,
      authority: new SchedulerCoverageReviewAuthority(schedulerStore),
      budgetLedger,
      ledger,
      modelCostEstimators,
      modelCostBases,
      ...(this.options.permissions ? { permissions: this.options.permissions } : {}),
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
    });
    const coverageReviewDriver: CoverageReviewDriver = {
      candidateRuntimeIds: [...spec.verifierRuntimeIds],
      review: async (input) => {
        const result = await nativeCoverageReview.review({
          ...input,
          providerRetryDeadlineMs: runnerProviderRetryDeadlineMs(
            spec.budgetLimits.maxActiveMs,
            budgetLedger.snapshot(spec.runId).effective.activeMs,
            Date.now(),
          ),
        });
        if (
          (result.status === "reviewed" ||
            (result.status === "suspended" && result.reason === "provider_error")) &&
          result.runtimeId
        ) {
          const candidate = candidates.find(
            (item) => item.runtimeId === result.runtimeId,
          );
          if (candidate) {
            persistProviderHealth(
              schedulerStore,
              spec.runId,
              health.get(candidate.providerId),
              `coverage:${result.runtimeId}`,
            );
          }
        }
        return result;
      },
    };
    // T9 (OA-5): the opt-in independent answer review, a sibling of the
    // coverage reviewer with the same model/router/session/budget wiring.
    // The BuildRuntime consults it only for triage-`answer` runs with a
    // recorded user opt-in and no verdict yet.
    const nativeAnswerReview = new NativeAnswerReviewRuntime({
      git: gitContext,
      executionGrants,
      router: verifierRouter,
      candidates,
      models,
      answerRuntimeIds: spec.verifierRuntimeIds,
      sessions,
      artifacts: this.artifacts,
      evidenceStore,
      projectRoot: this.options.projectRoot,
      authority: new SchedulerAnswerReviewAuthority(schedulerStore),
      budgetLedger,
      ledger,
      modelCostEstimators,
      modelCostBases,
      ...(this.options.permissions ? { permissions: this.options.permissions } : {}),
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
    });
    const answerReviewDriver: AnswerReviewDriver = {
      candidateRuntimeIds: [...spec.verifierRuntimeIds],
      review: async (input) => {
        const result = await nativeAnswerReview.review({
          ...input,
          providerRetryDeadlineMs: runnerProviderRetryDeadlineMs(
            spec.budgetLimits.maxActiveMs,
            budgetLedger.snapshot(spec.runId).effective.activeMs,
            Date.now(),
          ),
        });
        if (
          (result.status === "reviewed" ||
            (result.status === "suspended" && result.reason === "provider_error")) &&
          result.runtimeId
        ) {
          const candidate = candidates.find(
            (item) => item.runtimeId === result.runtimeId,
          );
          if (candidate) {
            persistProviderHealth(
              schedulerStore,
              spec.runId,
              health.get(candidate.providerId),
              `answer:${result.runtimeId}`,
            );
          }
        }
        return result;
      },
    };
    // T6a: the mandatory deliverable reviewer (a sibling of the coverage and
    // answer reviewers with the same router/session/budget wiring) and the
    // post-integration boundary checks. Reviewer inputs are read from durable
    // state only (session change set, diff artifact, submit_task summary);
    // commands run through FinalVerificationRuntime and the audited executor
    // in disposable checkouts (independent-verifier kind).
    // C5 (AR-R16): the authoritative accepted contract for review inputs,
    // resolved from durable state only. The CURRENT ready revision is the
    // only authority: an invalid, stale, dropped or mismatched reference
    // fails closed before any provider call — there is no historical
    // fallback on the live readiness path (resolveTaskContractAtRef stays
    // available for historical operations only). The exact current ref
    // rides with the contract so the reviewer renders pinned identity.
    const resolveReviewContract = (projection: SchedulerProjection, task: BuildTask): { contract: ExecutionTaskContract; ref: TaskContractRef } => {
      const resolution = resolveTaskContractReference(projection, task.id);
      if (resolution.status === "current") return { contract: resolution.contract, ref: resolution.ref };
      throw new Error(
        `Deliverable review inputs unavailable: task ${task.id} has no current accepted contract (resolution: ${resolution.status}).`,
      );
    };
    const durableSubmission = async (projection: SchedulerProjection, taskId: string): Promise<DurableSubmission> => {
      const task = projection.tasks[taskId];
      if (!task) throw new Error(`Unknown task ${taskId}.`);
      const author = currentWorkerAuthor(projection, task);
      if (!author) throw new Error(`Task ${taskId} has no recorded author runtime.`);
      const session = await sessions.load(resolveWorkerSessionId(
        spec.runId,
        task.id,
        task.attempt,
        task.assignedWorkerId ?? standardWorkerId(task.id, task.attempt),
        projection.runtime.workerAssignments[`${task.id}:${task.attempt}`]?.sessionId,
      ));
      if (!session.changeSet || session.changeSet.id !== task.changeSetId) {
        throw new Error(`Submitted change set ${task.changeSetId} is unavailable.`);
      }
      const summary = submitTaskSummary(session.checkpoint?.messages ?? []);
      if (!summary) throw new Error(`Task ${taskId} submit_task summary is not in its durable session.`);
      return { changeSet: session.changeSet, summary, authorRuntimeId: author };
    };
    // W1 (AR-R27): cheap authority subset for the reuse decision — the
    // baseline guard, the current contract and the durable submission
    // bytes, but no candidate-pin workspace. The full loader below adds
    // the test-integrity pin only when a real review actually proceeds.
    const peekDeliverableReviewInputs = async (input: { task: BuildTask; projection: SchedulerProjection }): Promise<DeliverableReviewInputs> => {
      await deliveryBoundaryDriver.captureInitialBaseline?.(input.task.id);
      const resolved = resolveReviewContract(input.projection, input.task);
      return loadDeliverableReviewInputs({
        task: input.task,
        submission: await durableSubmission(input.projection, input.task.id),
        artifacts: this.artifacts,
        contract: resolved.contract,
        contractRef: resolved.ref,
        evidenceStore,
      });
    };
    const deliveryGit = requireGitRunner(gitContext).lifecycle("verification").run;
    // The same ambient source the audited executor uses for children, so the
    // project's own NODE_OPTIONS is kept when the reporter flags are added.
    const deliveryNodeOptions = () => {
      const source = this.options.executionHost?.filteredEnvironmentSource() ?? snapshotNativeBuildAmbientEnvironment();
      // Windows environment names are case-insensitive.
      const name = Object.keys(source).find((key) => key.toUpperCase() === "NODE_OPTIONS");
      return name ? source[name] : undefined;
    };
    const nativeDeliverableReview = new NativeDeliverableReviewRuntime({
      store: schedulerStore,
      architectRuntimeId: spec.architectRuntimeId,
      git: gitContext,
      executionGrants,
      execution: commandExecution,
      permissionProfile: spec.permissionProfile,
      ...(this.options.permissions ? { permissions: this.options.permissions } : {}),
      router: verifierRouter,
      candidates,
      models,
      reviewerRuntimeIds: spec.verifierRuntimeIds,
      sessions,
      artifacts: this.artifacts,
      evidenceStore,
      loadInputs: async ({ task, projection }) => {
        const inputs = await peekDeliverableReviewInputs({ task, projection });
        const resolved = resolveReviewContract(projection, task);
        const fresh = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId));
        if (fresh.testIntegrity?.baseline) {
          const baseline = fresh.testIntegrity.baseline;
          const candidateWorkspace = await deliveryReviewWorkspace.create(inputs.taskRevision);
          const candidatePin = await (async () => {
            try {
              const candidateProfile = await inspectFinalVerificationExecutionProfile({ repositoryRoot: candidateWorkspace.path, targetRevision: inputs.taskRevision, execute: deliveryGit });
              return await inspectTestIntegrityPin({ git: deliveryGit, repositoryRoot: candidateWorkspace.path,
                revision: inputs.taskRevision, commands: candidateProfile.commands.tests ?? [] });
            } finally { await deliveryReviewWorkspace.cleanup(); }
          })();
          inputs.testIntegrityReference = { planRevisionId: resolved.ref.revisionId, planDigest: resolved.ref.digest,
            baselinePinDigest: baseline.pinDigest, candidatePinDigest: testIntegrityPinDigest(candidatePin),
            baselineKind: baseline.kind, ...(baseline.kind === "executed_report" ? { baselineExecuted: baseline.executed } : {}), baselineRevision: baseline.pin.revision,
            findings: testIntegrityProfileFindings(baseline.pin, candidatePin) };
        }
        return inputs;
      },
      peekInputs: async ({ task, projection }) => peekDeliverableReviewInputs({ task, projection }),
      // W1 (F6): actual Git trees through the audited verification
      // runner. Read-only rev-parse in the project checkout; any failure
      // yields undefined (conservative reuse miss, never a label).
      resolveTrees: async ({ baselineRevision, taskRevision }) => {
        const treeOf = async (revision: string): Promise<string | undefined> => {
          try {
            const result = await deliveryGit({ cwd: this.options.projectRoot, args: ["rev-parse", `${revision}^{tree}`] });
            if (result.exitCode !== 0) return undefined;
            const tree = result.stdout.trim();
            return /^[a-f0-9]{40}$|^[a-f0-9]{64}$/.test(tree) ? tree : undefined;
          } catch {
            return undefined;
          }
        };
        const [baseTree, headTree] = await Promise.all([treeOf(baselineRevision), treeOf(taskRevision)]);
        if (!baseTree || !headTree) return undefined;
        return { baseTree, headTree };
      },
      // W2 (AR-R28): actual fix-delta diff between two Git trees through
      // the audited verification runner. Read-only diff in the project
      // checkout; file lists arrive NUL-delimited with exact path
      // identity (no quoting, no source prefixes). Any failure yields
      // undefined: the review runtime then records the explicit
      // conservative fallback, never a manufactured label.
      resolveFixDelta: async ({ priorBaseTree, priorHeadTree, headTree }) => {
        const namesOf = async (from: string, to: string): Promise<string[] | undefined> => {
          try {
            const result = await deliveryGit({ cwd: this.options.projectRoot, args: ["diff", "-z", "--name-only", from, to, "--"] });
            if (result.exitCode !== 0) return undefined;
            // No trimming: NUL-delimited entries carry exact identity,
            // including leading or trailing spaces.
            return result.stdout.split("\0").filter((entry) => entry.length > 0);
          } catch {
            return undefined;
          }
        };
        const textOf = async (from: string, to: string): Promise<string | undefined> => {
          try {
            const result = await deliveryGit({ cwd: this.options.projectRoot, args: ["diff", from, to, "--"] });
            if (result.exitCode !== 0) return undefined;
            return result.stdout;
          } catch {
            return undefined;
          }
        };
        const [deltaFiles, deltaText] = await Promise.all([
          namesOf(priorHeadTree, headTree),
          textOf(priorHeadTree, headTree),
        ]);
        if (!deltaFiles || deltaText === undefined || !deltaText.trim()) {
          // An empty fix diff carries no correction hunks: without byte
          // proof of a change there is no delta to review.
          if (deltaFiles && deltaFiles.length === 0 && deltaText !== undefined) {
            const priorReviewed = priorBaseTree ? await namesOf(priorBaseTree, priorHeadTree) : undefined;
            return { deltaFiles: [], deltaText: "", priorReviewed: priorReviewed ?? [] };
          }
          return undefined;
        }
        const priorReviewed = priorBaseTree ? await namesOf(priorBaseTree, priorHeadTree) : undefined;
        return { deltaFiles, deltaText, priorReviewed: priorReviewed ?? [] };
      },
      workspace: {
        create: async (taskRevision) => ({ path: (await deliveryReviewWorkspace.create(taskRevision)).path }),
        cleanup: () => deliveryReviewWorkspace.cleanup(),
      },
      depth: createDeliveryDepthRunner({
        runId: spec.runId,
        git: deliveryGit,
        artifacts: this.artifacts,
        evidenceStore,
        execution: commandExecution,
        reviewWorkspace: deliveryReviewWorkspace,
        probeFileSystem: deliveryProbeFileSystem,
        ambientNodeOptions: deliveryNodeOptions,
      }),
      budgetLedger,
      ledger,
      modelCostEstimators,
      modelCostBases,
      contextManifests,
      recordContextPackText: spec.contextRecording === "full",
      defectClassesFor: () => topDefectClasses(this.liveMemoryStore().defectClasses(spec.projectId)),
      // T6b repair (EP50): the review runtime builds the OA-16
      // track-record snapshot for the T5 change-risk author tier from
      // these per-model outcomes.
      defectRecorder: { projectId: spec.projectId, store: this.liveMemoryStore(), modelOutcomes: (projectId: string, runId?: string) => this.liveMemoryStore().modelReviewOutcomes(projectId, runId) },
    });
    const deliveryReviewDriver: DeliveryReviewDriver = {
      review: async (input) => {
        const result = await nativeDeliverableReview.review(input);
        if (
          (result.status === "reviewed" ||
            (result.status === "suspended" && result.reason === "provider_error")) &&
          result.runtimeId
        ) {
          const candidate = candidates.find((item) => item.runtimeId === result.runtimeId);
          if (candidate) {
            persistProviderHealth(
              schedulerStore,
              spec.runId,
              health.get(candidate.providerId),
              `delivery:${result.runtimeId}`,
            );
          }
        }
        return result;
      },
    };
    const deliveryBoundaryDriver: DeliveryBoundaryDriver = createDeliveryBoundaryDriver({
      runId: spec.runId,
      git: deliveryGit,
      artifacts: this.artifacts,
      evidenceStore,
      execution: commandExecution,
      boundaryWorkspace: deliveryBoundaryWorkspace,
      validationAccounting: { ledger: budgetLedger },
      ambientNodeOptions: deliveryNodeOptions,
      testIntegrity: {
        projection: () => rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)),
        baselineWorkspace: testIntegrityBaselineWorkspace,
        recordBaseline: (taskId, baseline) => {
          schedulerStore.append({ runId: spec.runId, type: "delivery.test_integrity_baseline_recorded", occurredAt: new Date().toISOString(),
            actor: { role: "runner", id: "build-runtime" }, idempotencyKey: "test-integrity-initial-report:v1",
            payload: { taskId, ...baseline } });
        },
      },
      changedFilesFor: async (taskId) => {
        const projection = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId));
        return [...(await durableSubmission(projection, taskId)).changeSet.changedPaths];
      },
    });
    // C3c: kernel-derived trusted run-level requirement ids for the
    // integration trailer. Resolves the CURRENT accepted ready plan plus
    // the matching readyPlanTaskBinding revision/digest and contract id
    // (taskPlanMembership); repair tasks resolve through their recorded
    // parent contract. Missing/stale binding or contract fails closed —
    // an unmapped repair never invents ids, and the trailer never falls
    // back to task-local criterion ids, worker ChangeSet fields, or model
    // summary text.
    const trustedIntegrationRequirementIds = (
      projection: SchedulerProjection,
      taskId: string,
    ): string[] => {
      const ready = readyPlanIdentity(projection);
      const binding = projection.readyPlanTaskBindings?.[taskId];
      if (
        !ready ||
        !binding ||
        binding.revisionId !== ready.revisionId ||
        binding.digest !== ready.digest
      ) {
        throw new Error(
          `Task ${taskId} is not bound to the current ready plan revision; integration refuses a stale binding.`
        );
      }
      const task = projection.tasks[taskId];
      const membership = taskPlanMembership(projection, taskId);
      const contractId = membership.contractId ??
        (task?.kind === "verification_repair" && task
          ? repairParentContractId(projection, task)
          : undefined);
      const revision = projection.planning?.plan?.revisionsById[projection.planning.plan.currentRevisionId];
      const contract = revision?.tasks.find((candidate) => candidate.id === contractId);
      const requirementIds = (contract?.requirementIds ?? []).filter((id) => id.trim().length > 0);
      if (!contract || requirementIds.length === 0) {
        throw new Error(
          `Task ${taskId} has no trusted ready-plan contract requirement ids; unmapped repair never invents ids.`
        );
      }
      return [...requirementIds];
    };
    const integrationDriver: IntegrationRuntimeDriver = {
      integrate: async ({ taskId, changeSetId }) => {
        const projection = rebuildSchedulerProjection(
          schedulerStore.readRun(spec.runId)
        );
        const task = projection.tasks[taskId];
        if (!task) throw new Error(`Unknown integration task ${taskId}.`);
        const sessionId = resolveWorkerSessionId(
          spec.runId,
          taskId,
          task.attempt,
          task.assignedWorkerId ?? standardWorkerId(taskId, task.attempt),
          projection.runtime.workerAssignments[`${taskId}:${task.attempt}`]?.sessionId
        );
        const session = await sessions.load(sessionId);
        if (!session.changeSet || session.changeSet.id !== changeSetId) {
          throw new Error(`Submitted change set ${changeSetId} is unavailable.`);
        }
        const policyOptions = projection.planningPolicyVersion === 1
          ? {
              planningPolicyVersion: 1 as const,
              requirementIds: trustedIntegrationRequirementIds(projection, taskId),
            }
          : undefined;
        const result = await integrationManager.integrate(session.changeSet, policyOptions);
        return result.status === "integrated"
          ? { status: "integrated", integrationRevision: result.integrationRevision }
          : {
              status: "conflict",
              integrationRevision: result.integrationRevision,
              conflictPaths: [...result.conflictPaths],
            };
      },
    };
    // T6b repair (B2): the same ambient source the audited executor uses
    // for children, so the project's own NODE_OPTIONS is kept when the
    // reporter flags are added (mirrors the T6a delivery boundary).
    const ambientNodeOptions = (): string | undefined => {
      const source = this.options.executionHost?.filteredEnvironmentSource() ?? snapshotNativeBuildAmbientEnvironment();
      // Windows environment names are case-insensitive.
      const name = Object.keys(source).find((key) => key.toUpperCase() === "NODE_OPTIONS");
      return name ? source[name] : undefined;
    };
    // T6b repair (R2-B6): new-policy runs record the runner-owned junit
    // report files (OA-17); legacy runs keep P6.5 behavior.
    const policyTempRecorders = (): { tempRecorders?: typeof tempRecorders } =>
      rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).planningPolicyVersion === 1 ? { tempRecorders } : {};
    // C3c/F1: the scheduler-canonical integration revision (the accepted
    // task revision), never the live physical tip: kernel stop snapshots
    // advance the tip without changing the canonical revision, so checks
    // must compare against the canonical value to stay exact.
    const canonicalIntegrationRevision = (): string =>
      rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).integrationRevision ?? "";
    const assertCurrentVerificationGeneration = (input: { generationId: string; targetRevision: string }): void => {
      if (!docsV2) return;
      const projection = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId));
      const generation = projection.finalVerification?.current;
      if (!projection.integrationRevision || projection.integrationRevision !== input.targetRevision ||
          generation?.generationId !== input.generationId || generation.targetRevision !== input.targetRevision) {
        throw new Error("Final verification generation does not match the authoritative canonical revision.");
      }
    };
    const finalVerificationDriver: FinalVerificationCheckDriver = {
      executeCheck: async (input) => {
        // C3c/F1: pin the workspace to the scheduler-authorized generation
        // target. The shared manager resolves the live physical tip, which
        // kernel snapshots advance mid-verification; remaining checks must
        // still execute on the exact canonical revision.
        assertCurrentVerificationGeneration(input);
        const generationWorkspace = docsV2 ? new VerificationWorkspaceManager({
          execute: requireGitRunner(gitContext).lifecycle("verification").run,
          repositoryRoot: integrationManager.path,
          stateDirectory: this.options.stateDirectory,
          runId: spec.runId,
          targetRevision: input.targetRevision,
          ...snapshotVerificationOptions,
        }) : verificationWorkspace;
        const verification = new FinalVerificationRuntime({
          git: requireGitRunner(gitContext).lifecycle("verification").run,
          workspaceManager: generationWorkspace,
          artifacts: this.artifacts,
          evidenceStore,
          runId: input.runId,
          taskId: input.taskId,
          attempt: input.attempt,
          generationId: input.generationId,
          ambientNodeOptions: ambientNodeOptions(),
          ...policyTempRecorders(),
          checkCategory: input.category,
          currentIntegrationRevision: () => { assertCurrentVerificationGeneration(input); return docsV2 ? canonicalIntegrationRevision() : integrationManager.revision; },
          managedProcessService: this.liveManagedProcesses(),
          managedProcessAuthority: { executionGrants, permissionProfile: spec.permissionProfile },
          browserBackend: this.browserBackend,
          validatePortLease: async (lease) => await finalVerificationPorts.validate(
            lease,
            spec.runId,
            input.targetRevision,
          ),
          execution: commandExecution,
        });
        const releaseTier = input.category === "tests" ? input.executionProfile?.tiers?.release : undefined;
        const effectiveProfile = releaseTier?.length
          ? { ...input.executionProfile, commands: { ...input.executionProfile.commands, tests: projectTierCommandsToRuntimeCommands(releaseTier) }, reports: undefined }
          : input.executionProfile;
        const result = await verification.runCategory(
          {
            plan: input.plan,
            executionProfile: effectiveProfile,
            ...(effectiveProfile?.commands
              ? { commands: effectiveProfile.commands }
              : {}),
            ...(input.executionProfile?.runtimeSmoke
              ? { runtimeSmoke: input.executionProfile.runtimeSmoke }
              : {}),
            ...(input.executionProfile?.browser
              ? { browser: input.executionProfile.browser }
              : {}),
            signal: input.signal,
          },
          input.category,
        );
        return {
          workspacePath: result.workspacePath,
          startedAt: result.startedAt,
          finishedAt: result.finishedAt,
          check: result.check,
        };
      },
    };
    // T6b (OA-14): the production failing-test rerun. Only the tests
    // category with directly invoked node --test commands can be narrowed
    // mechanically; anything else reports unsupported with its reason, and
    // the pump charges the cycle instead of claiming an unperformed rerun.
    const flakyIsolation: FlakyIsolationDriver = {
      rerunFailingTests: async (input) => {
        if (input.category !== "tests") {
          return { status: "unsupported", note: `Flaky rerun supports only the tests category, not ${input.category}.` };
        }
        const releaseTier = input.executionProfile?.tiers?.release;
        const commands = releaseTier?.length ? projectTierCommandsToRuntimeCommands(releaseTier) : input.executionProfile.commands?.tests;
        if (!commands || commands.length === 0) {
          return { status: "unsupported", note: "Flaky rerun requires recorded tests commands." };
        }
        const narrowed: FinalVerificationCommand[] = [];
        let testNamePattern: string | undefined;
        for (const command of commands) {
          const filtered = narrowNodeTestCommand(command, input.failingTestIds);
          if (filtered) {
            narrowed.push(filtered);
            continue;
          }
          // T6b repair (R2-B4): the package `run test` command is narrowed
          // through its node --test NODE_OPTIONS (see FinalVerificationRuntime).
          if (isPackageRunTestCommand(command)) {
            narrowed.push(command);
            testNamePattern = flakyRerunPattern(input.failingTestIds);
            continue;
          }
          return { status: "unsupported", note: `Flaky rerun cannot filter ${command.label}: only node --test commands (direct or the package test script) support failing-test selection.` };
        }
        assertCurrentVerificationGeneration(input);
        const rerunVerification = new FinalVerificationRuntime({
          git: requireGitRunner(gitContext).lifecycle("verification").run,
          workspaceManager: docsV2 ? new VerificationWorkspaceManager({
            execute: requireGitRunner(gitContext).lifecycle("verification").run,
            repositoryRoot: integrationManager.path,
            stateDirectory: this.options.stateDirectory,
            runId: spec.runId,
            targetRevision: input.targetRevision,
            ...snapshotVerificationOptions,
          }) : verificationWorkspace,
          artifacts: this.artifacts,
          evidenceStore,
          runId: input.runId,
          taskId: input.taskId,
          attempt: input.attempt,
          generationId: `${input.generationId}:flaky-rerun`,
          ambientNodeOptions: ambientNodeOptions(),
          ...(testNamePattern !== undefined ? { testNamePattern } : {}),
          ...policyTempRecorders(),
          checkCategory: "tests",
          currentIntegrationRevision: () => { assertCurrentVerificationGeneration(input); return docsV2 ? canonicalIntegrationRevision() : integrationManager.revision; },
          managedProcessService: this.liveManagedProcesses(),
          managedProcessAuthority: { executionGrants, permissionProfile: spec.permissionProfile },
          browserBackend: this.browserBackend,
          validatePortLease: async (lease) => await finalVerificationPorts.validate(
            lease,
            spec.runId,
            input.targetRevision,
          ),
          execution: commandExecution,
        });
        const result = await rerunVerification.runCategory(
          {
            plan: input.plan,
            executionProfile: { ...input.executionProfile, commands: { ...input.executionProfile.commands, tests: narrowed } },
            commands: { ...input.executionProfile.commands, tests: narrowed },
            ...(input.signal ? { signal: input.signal } : {}),
          },
          "tests",
        );
        // T6b repair (B2): the owner real-counts verdict (see judgeFlakyRerun).
        // Flaky requires THIS rerun's report to show the named tests executed
        // and passed; anything else is a consistent failure or not performed.
        // (A green exit with no matching tests is not flaky.)
        const rerunReports = result.check.facts.flatMap((fact) => fact.kind === "command" && fact.report ? [fact.report] : []);
        const verdict = judgeFlakyRerun({ checkGreen: result.check.green, reports: rerunReports, failingTestIds: [...input.failingTestIds] });
        if (result.check.green && verdict.flaky) {
          return {
            status: "rerun",
            green: true,
            evidenceIds: [...result.check.evidenceIds],
            note: verdict.note,
          };
        }
        if (result.check.green) {
          return {
            status: "rerun",
            green: false,
            evidenceIds: [...result.check.evidenceIds],
            note: verdict.note,
          };
        }
        return {
          status: "rerun",
          green: false,
          evidenceIds: [...result.check.evidenceIds],
          note: verdict.note,
        };
      },
    };
    const runtime = new BuildRuntime({
      architectId: NATIVE_BUILD_ARCHITECT_ACTOR_ID,
      runId: spec.runId,
      initialObjective: spec.objective,
      runPolicy: spec.runPolicy,
      // T7b: the stable saved-spec clock for post-creation source approval.
      specCreatedAt: spec.createdAt,
      // C2b (CD-5): per-run handoff file options from the spec; recorded
      // durably in `run.policy_configured` by the runtime.
      specCopy: spec.specCopy ?? true,
      handoffFiles: spec.handoffFiles ?? "commit",
      store: schedulerStore,
      workerDriver,
      architectDriver,
      // C3b (AR-R09): the stop-notes one-shot runs on the run's actual
      // Architect runtime (same models, ledger and manifests as turns).
      stopNotes: architectDriver,
      integrationDriver,
      finalVerificationDriver,
      finalVerificationCleanupDriver: {
        cleanup: async (input) => {
          const current = rebuildSchedulerProjection(schedulerStore.readRun(spec.runId))
            .finalVerification?.current;
          const lease = current?.generationId === input.generationId &&
            current.targetRevision === input.targetRevision
            ? current.executionProfile.portLease
            : undefined;
          try {
            return await finalVerificationCleanup.cleanup(input);
          } finally {
            if (lease) {
              await finalVerificationPorts.release(lease, spec.runId, input.targetRevision);
            }
          }
        },
      },
      finalVerificationProfileFor: async (targetRevision) =>
        await finalVerificationProfiles.inspectAndPersist({
          execute: requireGitRunner(gitContext).lifecycle("verification").run,
          repositoryRoot: integrationManager.path,
          targetRevision,
        }),
      discardFinalVerificationProfile: async (profile) => {
        if (profile.portLease) {
          await finalVerificationPorts.release(profile.portLease, spec.runId, profile.targetRevision);
        }
      },
      independentVerifier,
      planCritic: planCriticDriver,
      coverageReview: coverageReviewDriver,
      answerReview: answerReviewDriver,
      deliveryReview: deliveryReviewDriver,
      architectReadLedger: ledger,
      deliveryBoundary: deliveryBoundaryDriver,
      planningHostCapabilities: () => buildCoverageHostCapabilities({
        coverageCandidateRuntimeIds: spec.verifierRuntimeIds,
        recordedAt: new Date().toISOString(),
      }),
      // T7a: the kernel-approved source bytes for planning reads, verified
      // against the manifest digest on every read (drift fails closed).
      planningSourceReader: async (manifest) => {
        const bytes = await this.artifacts.get(manifest.artifactDigest);
        assertManifestMatchesBytes(manifest, bytes);
        return new Uint8Array(bytes);
      },
      ...(spec.planningPolicy !== undefined
        ? { planningPolicy: { version: spec.planningPolicy.version } }
        : {}),
      repairPlanLimit: spec.repairPlanLimit,
      projectId: spec.projectId,
      flakyIsolation,
      cleanupAfterAttempt: async (context) => {
        // T6b repair (N-6): the attempt path scopes the process search to
        // the attempt's sessions; verification phase boundaries keep the
        // run-wide search because no worker attempt is active there.
        const processes = await searchOwnedProcesses(
          this.liveManagedProcesses(),
          spec.runId,
          context.sessionIds === undefined ? undefined : { sessionIds: context.sessionIds },
        );
        // T6b repair (R3 N-6): the disposable verification checkouts were
        // creation-recorded when the build was created (above); the search
        // here only reads records. Retained: git worktrees are removed only
        // by their own manager, which owns workspace + metadata together.
        const cleanupRoots = nativeBuildCleanupRoots(this.options.stateDirectory, spec.runId);
        const tempPaths = await searchRunnerOwnedTempLeftovers({
          records: Object.values(rebuildSchedulerProjection(schedulerStore.readRun(spec.runId)).tempRecords ?? {}),
          ownerRunId: spec.runId,
          ownerProjectId: spec.projectId,
          runnerRoots: cleanupRoots,
          excludedRoots: [this.options.projectRoot],
          cleared: (path) => tempRecorders.cleared(path),
        });
        return { processes, tempPaths };
      },
      reviewOutcomeRecorder: {
        projectId: spec.projectId,
        record: (outcome) => this.liveMemoryStore().recordModelReviewOutcome({ projectId: spec.projectId, ...outcome }),
      },
      maxConcurrency: spec.maxConcurrency,
      workspaceFor: async (task, attempt) => {
        const workspace = await workspaceManager.createTaskWorkspace(task.id, {
          workspaceId: `${task.id}:attempt:${attempt}`,
          baselineRevision: integrationManager.revision,
        });
        // T6b repair (OA-17): task workspaces stay live for the whole run
        // under their own manager lifecycle, so they are recorded retained
        // for owner visibility and are never deletion candidates while
        // workers run. Bookkeeping never breaks workspace creation.
        try {
          tempRecorders.recorded({ path: workspace.path, ownerRunId: spec.runId, kind: "directory", createdAt: new Date().toISOString(), retained: true });
        } catch { /* bookkeeping never breaks workspace creation */ }
        return {
          path: workspace.path,
          workspaceId: workspace.workspaceId,
          baselineRevision: workspace.baselineRevision,
        };
      },
      renewBudgetWindow: (idempotencyKey, occurredAt) => {
        budgetLedger.startWindow({
          scopeId: spec.runId,
          occurredAt,
          idempotencyKey,
        });
      },
      providerRetryDeadlineMs: () => {
        const usedActiveMs = budgetLedger.snapshot(spec.runId).effective.activeMs;
        return runnerProviderRetryDeadlineMs(
          spec.budgetLimits.maxActiveMs,
          usedActiveMs,
          Date.now()
        );
      },
      evidenceStore,
      artifacts: this.artifacts,
      projectDocs: {
        commit: (input) => integrationManager.commitProjectDocuments(input),
        commitHandoffSnapshot: (input) => integrationManager.commitHandoffSnapshot(input),
        readHandoffSnapshotFile: (input) => integrationManager.readHandoffSnapshotFile(input),
        readIntegrationTipFile: (input) => integrationManager.readIntegrationTipFile(input),
        findTrackedFileWithDigest: (input) => integrationManager.findTrackedFileWithDigest(input),
        // C2b repair B1-R: the withdrawn-stop reconciliation lookup and the
        // baseline revision are production-wired (both required on the
        // port, so dropping one is a type error, never a silent skip).
        findHandoffSnapshotCommit: (input) => integrationManager.findHandoffSnapshotCommit(input),
        readIntegrationBaselineRevision: () => integrationManager.readIntegrationBaselineRevision(),
        // C2c (NF-1 residual): the pre-render spec stageability check is
        // production-wired (required on the port, so dropping it is a type
        // error, never a silently wrong `spec:` line).
        canStageSpecPath: (input) => integrationManager.canStageSpecPath(input),
        relateRevision: (input) => integrationManager.relateToDocumentTip(input),
      },
    });
    let closed = false;
    let closing: Promise<void> | undefined;
    return {
      runtime,
      processRecovery,
      finalVerificationCleanup,
      retireInvalidatedFinalVerification: async (generation, currentGeneration) =>
        await retireInvalidatedFinalVerificationGeneration({
          cleanup: finalVerificationCleanup,
          generation,
          currentGeneration,
          releasePortLease: async (lease, targetRevision) =>
            await finalVerificationPorts.release(
              lease,
              spec.runId,
              targetRevision,
            ),
        }),
      usage: () => {
        const budget = budgetLedger.snapshot(spec.runId);
        return {
          ...budget,
          attributedModelReservationCount: Object.values(budget.reservations).filter(
            (reservation) => reservation.kind === "model" && reservation.attribution
          ).length,
          models: projectNativeModelUsage({
            budget,
            runtimes: modelUsageRuntimes,
            providerHealth: health.snapshot(),
          }),
        };
      },
      observability: async (): Promise<BuildObservabilitySnapshot> => {
        const agentSessions = await sessions.listRun(spec.runId);
        const toolCalls = summarizeToolCalls(ledger.listRun(spec.runId));
        const schedulerEvents = schedulerStore.readRun(spec.runId);
        const schedulerProjection = rebuildSchedulerProjection(schedulerEvents);
        const executionEnforcement = await executionIsolation.enforcementState();
        const executionSafety = projectExecutionSafetyObservability({
          permissionProfile: spec.permissionProfile,
          isolation: executionEnforcement,
          activeIsolationLeaseCount: executionIsolation.activeLeases().length,
          grantStates: executionGrants.activeSnapshots().flatMap((grant) =>
            grant.state === "revoked" ? [] : [grant.state]),
          processes: processRecoveryRuntime.list?.() ?? [],
          recovery: processRecovery.records(),
        });
        const finalGeneration = schedulerProjection.finalVerification?.current;
        const diagnostics = finalGeneration
          ? await loadFinalVerificationDiagnostics({
              stateDirectory: this.options.stateDirectory,
              runId: spec.runId,
              expectedRunSegment: safeSegment(spec.runId),
              diagnosticsPath: finalGeneration.cleanup?.diagnosticsPath,
              generationId: finalGeneration.generationId,
              taskId: finalGeneration.taskId,
              targetRevision: finalGeneration.targetRevision,
            })
          : undefined;
        return {
          runId: spec.runId,
          budget: budgetLedger.snapshot(spec.runId),
          toolCallCount: toolCalls.length,
          agents: agentSessions.map((session) => ({
            sessionId: session.sessionId,
            actor: { ...session.actor },
            status: session.status,
            turns: session.checkpoint?.turns ?? 0,
            ...(session.suspensionReason
              ? { suspensionReason: session.suspensionReason }
              : {}),
            ...(session.error ? { error: session.error } : {}),
            ...(session.changeSetId ? { changeSetId: session.changeSetId } : {}),
            lastSequence: session.lastSequence,
          })),
          tools: toolCalls.slice(-1_000),
          evidence: evidenceStore.list({ runId: spec.runId, limit: 1_000 }),
          memories: [...rebuildProjectMemories(
            this.liveMemoryStore().events(spec.projectId)
          ).values()],
          skills: await skillCatalog.discover(),
          processes: (await this.liveManagedProcesses().listRun(spec.runId)).slice(-100).map(
            (process) => ({
              ...process,
              stdout: process.stdout.slice(-8 * 1024),
              stderr: process.stderr.slice(-8 * 1024),
            })
          ),
          providers: Object.values(schedulerProjection.runtime.providerHealth),
          events: schedulerEvents.slice(-1_000),
          git: {
            integrationBranch: integrationManager.integrationBranch,
            integrationRevision: integrationManager.revision,
            commits: await integrationManager.history(50),
          },
          capabilities: {
            extensions: runCapabilities.registry.manifests(),
            languageProviders: runCapabilities.language.providerMetadata(),
            languageRoutes: runCapabilities.language.auditRecords(),
            executionEnforcement,
          },
          executionSafety: { availability: "live", ...executionSafety },
          finalVerification: projectFinalVerificationObservability(
            schedulerProjection,
            diagnostics,
          ),
          independentVerifier:
            projectIndependentVerifierObservability(schedulerProjection),
          contextManifestCount: contextManifests.listRun(spec.runId).length,
          planning: projectPlanningObservability(schedulerProjection),
        };
      },
      contextManifests: () => contextManifests.listRun(spec.runId),
      transcript: async (afterSequence = 0) =>
        await sessions.transcript(spec.runId, afterSequence),
      files: async () => {
        const handoff = runtime.projection().projectHandoff;
        if (
          handoff?.status === "selected" &&
          handoff.appliedToProject &&
          handoff.projectRevision
        ) {
          return await integrationManager.files("project", handoff.projectRevision);
        }
        return await integrationManager.files("integration");
      },
      compact: async () => {
        await sessions.compactRun(spec.runId);
      },
      projectHandoff: async (choice) =>
        choice === "apply_to_project"
          ? await integrationManager.applyToProject()
          : integrationManager.descriptor(false),
      cleanup: async () => {
        if (ownedMcpCleanup && !ownedMcpCleanup.isComplete()) {
          await this.options.runtimeConstructionHooks?.beforeCleanup?.("mcp_manager");
          await ownedMcpCleanup.close();
          constructionResources.completeHandleStage("mcp_manager");
        }
        await cleanupSettledNativeBuild(
          async () => {
            await this.liveManagedProcesses().stopRun(spec.runId);
          },
          [
            () => runCapabilities.close(),
            () => sessions.compactRun(spec.runId),
            () => workspaceManager.cleanup(),
            () => verifierWorkspace.cleanup(),
            () => verifierBaselineWorkspace.cleanup(),
            () => integrationManager.cleanup(),
          ],
          spec.runId
        );
        // Git-dependent workspace cleanup must finish before its host/grants close.
        if (ownedExecutionHostBindingCleanup && !ownedExecutionHostBindingCleanup.isComplete()) {
          await this.options.runtimeConstructionHooks?.beforeCleanup?.("execution_host_binding");
          await ownedExecutionHostBindingCleanup.close();
          constructionResources.completeHandleStage("execution_host_binding");
        }
      },
      close: async () => {
        if (closed) return;
        if (closing) return await closing;
        const attempt = (async (): Promise<void> => {
          await constructionResources.close("handle");
          closed = true;
        })();
        closing = attempt;
        try {
          await attempt;
        } finally {
          if (closing === attempt) closing = undefined;
        }
      },
    };
    } catch (error) {
      const pendingCapabilityCleanup = nativeCapabilityCleanupDisposer(error);
      if (pendingCapabilityCleanup) {
        constructionResources.add(
          "capabilities",
          () => pendingCapabilityCleanup.close(),
          true,
        );
      }
      const primary = nativeBuildConstructionFailure(initializationStage, error);
      try {
        await constructionResources.close("failure");
      } catch (cleanupError) {
        this.incompleteConstructionCleanups.add(constructionResources);
        throw aggregateConstructionFailure(spec.runId, primary, cleanupError);
      }
      throw primary;
    }
  }

  private capabilitiesConfig(): RunnerCapabilitiesConfig {
    return this.options.capabilitiesConfig ?? emptyRunnerCapabilitiesConfig();
  }

  private async closeIncompleteConstructionResources(): Promise<void> {
    const failures: unknown[] = [];
    for (const resources of [...this.incompleteConstructionCleanups]) {
      try {
        await resources.close("failure");
        if (resources.isComplete("failure")) {
          this.incompleteConstructionCleanups.delete(resources);
        }
      } catch (error) {
        failures.push(error);
      }
    }
    if (failures.length > 0) {
      throw new AggregateError(
        failures,
        "Could not finish cleanup from an earlier native Build construction failure.",
      );
    }
  }

  /** Mutable global stores are constructed only for a live runtime. */
  private liveMemoryStore(): SqliteProjectMemoryStore {
    return this.memoryStore ??= new SqliteProjectMemoryStore(
      join(this.options.stateDirectory, "project-memory.sqlite"),
    );
  }

  /** Historical readers must never reconcile or persist managed-process state. */
  private liveManagedProcesses(): ManagedProcessService {
    if (this.options.executionHost) return this.options.executionHost.managedProcesses;
    return this.managedProcesses ??= new ManagedProcessService({
      stateDirectory: join(this.options.stateDirectory, "managed-processes"),
    });
  }

  /**
   * Reopens only durable records for a terminal Build. It deliberately does
   * not load capability code, construct models, or start owned processes.
   */
  async createHistorical(
    spec: NativeBuildSpec,
    terminalState: HistoricalTerminalState,
  ): Promise<NativeBuildRuntimeHandle> {
    if (this.closed) throw new Error("Native Build factory is closed.");
    assertHistoricalTerminalState(terminalState);
    const runRoot = join(this.options.stateDirectory, "builds", safeSegment(spec.runId));
    let evidenceStore: SqliteEvidenceStore | undefined;
    let ledger: SqliteToolLedger | undefined;
    let contextManifestStore: SqliteContextManifestStore | undefined;
    let sessions: SqliteAgentSessionStore | undefined;
    let budgetLedger: SqliteBudgetLedger | undefined;
    let schedulerStore: SqliteSchedulerStore | undefined;
    let historicalMemoryStore: SqliteProjectMemoryStore | undefined;
    const historicalSqliteSnapshots: string[] = [];
    const closedHistoricalStores = new Set<HistoricalCloseable>();
    const removedHistoricalSqliteSnapshots = new Set<string>();
    const closeHistoricalResources = async (): Promise<unknown[]> => {
      const failures: unknown[] = [];
      // Close in reverse acquisition order. Each successful close/removal is
      // remembered so a transient failure can be retried without double-closing
      // resources that were already released.
      const stores: Array<HistoricalCloseable | undefined> = [
        historicalMemoryStore,
        schedulerStore,
        budgetLedger,
        sessions,
        contextManifestStore,
        ledger,
        evidenceStore,
      ];
      for (const store of stores) {
        if (!store || closedHistoricalStores.has(store)) continue;
        try {
          store.close();
          closedHistoricalStores.add(store);
        } catch (error) {
          failures.push(error);
        }
      }
      for (const directory of [...historicalSqliteSnapshots].reverse()) {
        if (removedHistoricalSqliteSnapshots.has(directory)) continue;
        try {
          await rm(directory, { recursive: true, force: true });
          removedHistoricalSqliteSnapshots.add(directory);
        } catch (error) {
          // Leave a failed directory recorded for a later close retry.
          failures.push(error);
        }
      }
      return failures;
    };
    try {
      const evidencePath = join(runRoot, "evidence.sqlite");
      const ledgerPath = join(runRoot, "tools.sqlite");
      const contextManifestPath = join(runRoot, "context-manifests.sqlite");
      const sessionsPath = join(runRoot, "sessions.sqlite");
      const budgetPath = join(runRoot, "budget.sqlite");
      const schedulerPath = join(runRoot, "scheduler.sqlite");
      const memoryPath = join(this.options.stateDirectory, "project-memory.sqlite");
      const managedProcessPath = join(this.options.stateDirectory, "managed-processes");
      const snapshotStorePath = async (source: string): Promise<string> => {
        const snapshot = await materializeHistoricalSqliteSnapshot(source);
        historicalSqliteSnapshots.push(snapshot.directory);
        return snapshot.databasePath;
      };
      if (hasHistoricalStore(evidencePath)) {
        evidenceStore = new SqliteEvidenceStore(await snapshotStorePath(evidencePath), {
          readOnly: true,
        });
      }
      if (hasHistoricalStore(ledgerPath)) {
        ledger = new SqliteToolLedger(await snapshotStorePath(ledgerPath), { readOnly: true });
      }
      if (hasHistoricalStore(contextManifestPath)) {
        contextManifestStore = new SqliteContextManifestStore(
          await snapshotStorePath(contextManifestPath),
          { readOnly: true },
        );
      }
      if (hasHistoricalStore(sessionsPath)) {
        sessions = new SqliteAgentSessionStore(
          await snapshotStorePath(sessionsPath),
          this.artifacts,
          { readOnly: true },
        );
      }
      if (hasHistoricalStore(budgetPath)) {
        budgetLedger = new SqliteBudgetLedger(await snapshotStorePath(budgetPath), {
          limitsFor: () => spec.budgetLimits,
          readOnly: true,
        });
      }
      const historicalSchedulerPath = hasHistoricalStore(schedulerPath)
        ? await snapshotStorePath(schedulerPath)
        : undefined;
      if (hasHistoricalStore(memoryPath)) {
        historicalMemoryStore = new SqliteProjectMemoryStore(await snapshotStorePath(memoryPath), {
          readOnly: true,
        });
      }
      if (historicalSchedulerPath) {
        const ports = new FinalVerificationPortAuthority(this.options.stateDirectory);
        const profiles = new FinalVerificationProfileAuthority({
          stateDirectory: this.options.stateDirectory,
          runId: spec.runId,
          portAuthority: ports,
          ambientEnvironment: this.options.executionHost?.filteredEnvironmentSource() ?? snapshotNativeBuildAmbientEnvironment(),
        });
        const acceptedProfiles = new Set<string>();
        const acceptedCleanupReceipts = new Set<string>();
        const profileKey = (targetRevision: string, profile: Parameters<typeof finalVerificationProfileDigest>[1]) =>
          `${targetRevision}\u0000${finalVerificationProfileDigest(spec.runId, profile)}`;
        const cleanupReceiptKey = (identity: FinalVerificationCleanupReceiptIdentity) =>
          JSON.stringify(identity);
        const openingSchedulerStore = new SqliteSchedulerStore(historicalSchedulerPath, {
          evidenceStore,
          artifacts: this.artifacts,
          validateExecutionProfile: ({ targetRevision, profile }) => {
            profiles.validate(profile, targetRevision);
            acceptedProfiles.add(profileKey(targetRevision, profile));
          },
          validateCleanupReceipt: (identity) => {
            validateOwnedFinalVerificationCleanupReceipt(this.options.stateDirectory, identity);
            acceptedCleanupReceipts.add(cleanupReceiptKey(identity));
          },
          readOnly: true,
        });
        try {
          // Authenticate every terminal event against the live Runner-owned
          // archives once, before freezing the accepted identities below.
          openingSchedulerStore.readRun(spec.runId);
        } finally {
          openingSchedulerStore.close();
        }
        schedulerStore = new SqliteSchedulerStore(historicalSchedulerPath, {
          evidenceStore,
          artifacts: this.artifacts,
          validateExecutionProfile: ({ targetRevision, profile }) => {
            if (!acceptedProfiles.has(profileKey(targetRevision, profile))) {
              throw new Error("Historical final verification profile was not authenticated at handle open.");
            }
          },
          validateCleanupReceipt: (identity) => {
            if (!acceptedCleanupReceipts.has(cleanupReceiptKey(identity))) {
              throw new Error("Historical final verification cleanup receipt was not authenticated at handle open.");
            }
          },
          readOnly: true,
        });
      }
      let integrationManager: IntegrationManager | undefined;
      const historicalIntegrationManager = (): IntegrationManager => {
        integrationManager ??= new IntegrationManager({
          execute: (request) => this.options.executionHost
            ? this.options.executionHost.withGitInspection({ runId: spec.runId, permissionProfile: spec.permissionProfile, capabilityContract: spec.capabilityContract!, capabilitiesConfig: this.capabilitiesConfig() }, (git) => git.run(request))
            : requireGitRunner(this.options.gitForRun?.(spec)).lifecycle("inspection").run(request),
          executeBytes: (request) => this.options.executionHost
            ? this.options.executionHost.withGitInspection({ runId: spec.runId, permissionProfile: spec.permissionProfile, capabilityContract: spec.capabilityContract!, capabilitiesConfig: this.capabilitiesConfig() }, (git) => git.runBytes(request))
            : requireGitRunner(this.options.gitForRun?.(spec)).lifecycle("inspection").runBytes(request),
          repositoryRoot: this.options.projectRoot,
          stateDirectory: this.options.stateDirectory,
          runId: spec.runId,
          baselineRevision: this.options.baselineFor(spec.runId),
          initializationMode: "cleanup-only",
        });
        return integrationManager;
      };
      const readEvents = (afterSequence = 0): SchedulerEvent[] =>
        schedulerStore?.readRun(spec.runId, afterSequence) ?? [];
      const budgetProjection = () =>
        budgetLedger?.snapshot(spec.runId) ?? rebuildBudgetProjection(spec.runId, []);
      const usageProvenance: HistoricalReadProvenance = budgetLedger
        ? "durable"
        : "unavailable";
      const transcriptProvenance = async (): Promise<HistoricalReadProvenance> =>
        sessions
          ? await sessions.historicalTranscriptProvenance(spec.runId)
          : "unavailable";
      const evidenceProvenance = (): HistoricalReadProvenance =>
        evidenceStore?.historicalProvenance() ?? "unavailable";
      const memoryProvenance = (): HistoricalReadProvenance =>
        historicalMemoryStore?.historicalProvenance() ?? "unavailable";
      const processProvenance: HistoricalReadProvenance = hasHistoricalDirectory(managedProcessPath)
        ? "durable"
        : "unavailable";
      const historicalUsage = () => {
        const budget = budgetProjection();
        return {
          ...budget,
          attributedModelReservationCount: Object.values(budget.reservations).filter(
            (reservation) => reservation.kind === "model" && reservation.attribution,
          ).length,
          models: usageProvenance === "durable"
            ? projectNativeModelUsage({
                budget,
                runtimes: historicalModelUsageRuntimes(budget),
                providerHealth: providerHealthFromSchedulerEvents(readEvents()),
              })
            : [],
          historicalProvenance: usageProvenance,
        };
      };
      const historicalSkills = (): {
        skills: SkillMetadata[];
        provenance: HistoricalReadProvenance;
      } => {
        if (!ledger) return { skills: [], provenance: "unavailable" };
        const skills = skillsFromHistoricalToolLedger(ledger.listRun(spec.runId));
        return skills
          ? { skills, provenance: "durable" }
          : { skills: [], provenance: "unavailable" };
      };
      const historicalMemories = (): import("./project-memory.js").ProjectMemoryEntry[] => {
        if (memoryProvenance() === "unavailable") return [];
        return [...rebuildProjectMemories(
          historicalMemoryStore!.events(spec.projectId),
        ).values()].filter((memory) => memory.runId === spec.runId);
      };
      const projection = () => historicalSchedulerProjection(
        spec,
        readEvents(),
        terminalState,
      );
      // SQLite inputs are materialized above, but managed-process records and
      // diagnostic archives are bounded filesystem surfaces. Freeze them at
      // historical-open time so every later audit remains an observation of
      // the terminal state rather than a fresh read of mutable live files.
      const historicalProcesses = processProvenance === "durable"
        ? readHistoricalManagedProcessObservations(managedProcessPath, spec.runId)
        : [];
      const historicalFinalGeneration = projection().finalVerification?.current;
      const historicalFinalVerificationDiagnostics = historicalFinalGeneration
        ? await loadHistoricalFinalVerificationDiagnostics({
            stateDirectory: this.options.stateDirectory,
            runId: spec.runId,
            diagnosticsPath: historicalFinalGeneration.cleanup?.diagnosticsPath,
            generationId: historicalFinalGeneration.generationId,
            taskId: historicalFinalGeneration.taskId,
            targetRevision: historicalFinalGeneration.targetRevision,
          })
        : undefined;
      const readOnlyError = (): never => {
        throw new Error(`Historical Build ${spec.runId} is read-only.`);
      };
      const runtime = {
        id: spec.runId,
        projection,
        events: (afterSequence = 0) => readEvents(afterSequence),
        planningReadiness: () => {
          const current = projection();
          return projectPlanningReadiness({ runId: spec.runId, projection: current, explicitStartAuthorized: current.planning?.readiness === "ready" && explicitStartBlocked(current) === undefined });
        },
        planningExport: () => {
          const current = projection();
          return buildPlanningExportDocument({ runId: spec.runId, projection: current,
            readiness: projectPlanningReadiness({ runId: spec.runId, projection: current, explicitStartAuthorized: current.planning?.readiness === "ready" && explicitStartBlocked(current) === undefined }),
            exportedAt: new Date().toISOString() });
        },
        registerPlanningSource: async () => readOnlyError(),
        amendPlanningSource: async () => readOnlyError(),
        authorizeExplicitPlanStart: async () => readOnlyError(),
        step: async () => readOnlyError(),
        runUntilBlocked: async () => readOnlyError(),
        pause: () => readOnlyError(),
        resume: () => readOnlyError(),
        continue: () => readOnlyError(),
        selectArchitectHandoff: () => readOnlyError(),
        selectVerifierRuntime: () => readOnlyError(),
        extendRepairCycles: () => readOnlyError(),
        submitUserGuidance: () => readOnlyError(),
        submitManagedUserGuidance: () => readOnlyError(),
        completeManagedUserGuidanceInterruption: () => readOnlyError(),
        answerArchitectQuestion: () => readOnlyError(),
        selectProjectHandoff: () => readOnlyError(),
      } as unknown as BuildRuntime;
      let closed = false;
      let closing: Promise<void> | undefined;
      return {
        runtime,
        historical: true,
        usage: historicalUsage,
        observability: async (): Promise<BuildObservabilitySnapshot> => {
          const schedulerEvents = readEvents();
          const transcriptHistoryProvenance = await transcriptProvenance();
          const schedulerProjection = historicalSchedulerProjection(
            spec,
            schedulerEvents,
            terminalState,
          );
          const agentSessions = transcriptHistoryProvenance === "unavailable"
            ? []
            : await sessions!.listRun(spec.runId);
          const toolCalls = ledger ? summarizeToolCalls(ledger.listRun(spec.runId)) : [];
          const skillSnapshot = historicalSkills();
          const integrationRevision = schedulerProjection.projectHandoff?.integrationRevision
            ?? schedulerProjection.integrationRevision;
          return {
            runId: spec.runId,
            budget: historicalUsage(),
            toolCallCount: toolCalls.length,
            agents: agentSessions.map((session) => ({
              sessionId: session.sessionId,
              actor: { ...session.actor },
              status: session.status,
              turns: session.checkpoint?.turns ?? 0,
              ...(session.suspensionReason
                ? { suspensionReason: session.suspensionReason }
                : {}),
              ...(session.error ? { error: session.error } : {}),
              ...(session.changeSetId ? { changeSetId: session.changeSetId } : {}),
              lastSequence: session.lastSequence,
            })),
            tools: toolCalls.slice(-1_000),
            evidence: evidenceProvenance() === "unavailable"
              ? []
              : evidenceStore!.list({ runId: spec.runId, limit: 1_000 }),
            memories: historicalMemories(),
            skills: skillSnapshot.skills,
            processes: processProvenance === "durable"
              ? structuredClone(historicalProcesses)
              : [],
            providers: Object.values(schedulerProjection.runtime.providerHealth),
            events: schedulerEvents.slice(-1_000),
            git: {
              integrationBranch: schedulerProjection.projectHandoff?.integrationBranch ?? "",
              integrationRevision: integrationRevision ?? "",
              commits: integrationRevision
                ? await historicalIntegrationManager().historicalHistory(integrationRevision)
                : [],
            },
            ...(spec.capabilityContract
              ? {
                  capabilities: {
                    extensions: [],
                    languageProviders: [],
                    languageRoutes: [],
                    historicalContract: cloneRunnerCapabilityContract(spec.capabilityContract),
                    executionEnforcement: await readExecutionEnforcementState(join(
                      this.options.stateDirectory, "builds", safeSegment(spec.runId),
                      "execution-isolation", "execution-enforcement-state.json",
                    )),
                  },
                }
              : {}),
            executionSafety: {
              availability: "unavailable",
              reason: "historical_execution_safety_unavailable",
            },
            historical: {
              terminalState,
              provenance: {
                usage: usageProvenance,
                transcript: transcriptHistoryProvenance,
                evidence: evidenceProvenance(),
                memories: memoryProvenance(),
                skills: skillSnapshot.provenance,
                processes: processProvenance,
                capabilities: spec.capabilityContract ? "durable" : "unavailable",
                events: schedulerStore ? "durable" : "unavailable",
                files: integrationRevision ||
                  (schedulerProjection.projectHandoff?.appliedToProject &&
                    schedulerProjection.projectHandoff.projectRevision)
                  ? "durable"
                  : "unavailable",
              },
            },
            finalVerification: projectFinalVerificationObservability(
              schedulerProjection,
              historicalFinalVerificationDiagnostics && structuredClone(historicalFinalVerificationDiagnostics),
            ),
            independentVerifier:
              projectIndependentVerifierObservability(schedulerProjection),
            contextManifestCount: contextManifestStore?.listRun(spec.runId).length ?? 0,
          };
        },
        contextManifests: () => contextManifestStore?.listRun(spec.runId) ?? [],
        transcript: async (afterSequence = 0) => {
          const provenance = await transcriptProvenance();
          const page = provenance === "unavailable"
            ? { turns: [], cursor: afterSequence }
            : await sessions!.transcript(spec.runId, afterSequence);
          return { ...page, historicalProvenance: provenance };
        },
        files: async () => {
          const schedulerProjection = projection();
          const handoff = schedulerProjection.projectHandoff;
          const integrationRevision = handoff?.integrationRevision
            ?? schedulerProjection.integrationRevision;
          if (!integrationRevision && !(handoff?.appliedToProject && handoff.projectRevision)) {
            return {
              source: "integration",
              revision: "",
              appliedToProject: false,
              omittedFileCount: 0,
              files: [],
              historicalProvenance: "unavailable",
            };
          }
          return {
            ...(await historicalIntegrationManager().historicalFiles({
            integrationRevision,
            appliedToProject: handoff?.appliedToProject,
            projectRevision: handoff?.projectRevision,
            })),
            historicalProvenance: "durable",
          };
        },
        compact: () => readOnlyError(),
        projectHandoff: async () => readOnlyError(),
        cleanup: () => readOnlyError(),
        close: async () => {
          if (closed) return;
          if (closing) return await closing;
          const attempt = (async (): Promise<void> => {
            const failures = await closeHistoricalResources();
            if (failures.length > 0) {
              throw new AggregateError(
                failures,
                `Could not close all historical Build ${spec.runId} resources.`,
              );
            }
            closed = true;
          })();
          closing = attempt;
          try {
            await attempt;
          } finally {
            if (closing === attempt) closing = undefined;
          }
        },
      };
    } catch (error) {
      const cleanupFailures = await closeHistoricalResources();
      if (cleanupFailures.length > 0) {
        throw new AggregateError(
          [error, ...cleanupFailures],
          `Could not open historical Build ${spec.runId} and clean up its resources.`,
        );
      }
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.closed) return;
    if (this.closePromise) return await this.closePromise;
    const attempt = (async (): Promise<void> => {
      const failures: unknown[] = [];
      try {
        await this.closeIncompleteConstructionResources();
      } catch (error) {
        failures.push(error);
      }
      if (this.memoryStore) {
        try {
          this.memoryStore.close();
          this.memoryStore = undefined;
        } catch (error) {
          failures.push(error);
        }
      }
      if (!this.providerConfigsClosed && this.options.closeProviderConfigs !== false) {
        try {
          this.options.providerConfigs.close();
          this.providerConfigsClosed = true;
        } catch (error) {
          failures.push(error);
        }
      }
      if (this.managedProcesses) {
        try {
          await this.managedProcesses.close();
          this.managedProcesses = undefined;
        } catch (error) {
          failures.push(error);
        }
      }
      if (!this.browserBackendClosed) {
        try {
          await this.browserBackend.closeAll();
          this.browserBackendClosed = true;
        } catch (error) {
          failures.push(error);
        }
      }
      if (failures.length > 0) {
        throw new AggregateError(failures, "Could not close native Build factory resources.");
      }
      this.closed = true;
    })();
    this.closePromise = attempt;
    try {
      await attempt;
    } finally {
      if (this.closePromise === attempt) this.closePromise = undefined;
    }
  }

  async runArtifactCompaction<T>(operation: () => Promise<T>): Promise<T> {
    return await this.artifactReachability.runQuiescent(operation);
  }

  async prepareArtifactCleanup(): Promise<void> {
    await this.artifactReachability.prepareReachabilityIndex();
  }
}

type NativeBuildResourceCleanupMode = "failure" | "handle";

interface NativeBuildResourceCleanupEntry {
  stage: NativeBuildRuntimeResourceStage;
  cleanup(): void | Promise<void>;
  closeOnHandle: boolean;
  completedOnFailure: boolean;
  completedOnHandle: boolean;
}

/**
 * Keeps live Build construction ownership explicit until the returned handle
 * takes over. Failed cleanup entries remain retryable instead of being hidden
 * behind a prematurely-set closed flag.
 */
class NativeBuildResourceCleanupStack {
  private readonly entries: NativeBuildResourceCleanupEntry[] = [];
  private readonly closing = new Map<NativeBuildResourceCleanupMode, Promise<void>>();

  constructor(private readonly hooks?: NativeBuildRuntimeConstructionHooks) {}

  add(
    stage: NativeBuildRuntimeResourceStage,
    cleanup: () => void | Promise<void>,
    closeOnHandle = false,
  ): void {
    this.entries.push({
      stage,
      cleanup,
      closeOnHandle,
      completedOnFailure: false,
      completedOnHandle: false,
    });
  }

  isComplete(mode: NativeBuildResourceCleanupMode): boolean {
    return this.entries.every((entry) =>
      mode === "failure"
        ? entry.completedOnFailure
        : !entry.closeOnHandle || entry.completedOnHandle,
    );
  }

  completeHandleStage(stage: NativeBuildRuntimeResourceStage): void {
    const matching = this.entries.filter((entry) =>
      entry.stage === stage && entry.closeOnHandle);
    if (matching.length !== 1) {
      throw new Error(`Native Build handle cleanup stage ${stage} is not uniquely owned.`);
    }
    matching[0]!.completedOnHandle = true;
  }

  async close(mode: NativeBuildResourceCleanupMode): Promise<void> {
    const inFlight = this.closing.get(mode);
    if (inFlight) return await inFlight;
    const attempt = this.closeEntries(mode);
    this.closing.set(mode, attempt);
    try {
      await attempt;
    } finally {
      if (this.closing.get(mode) === attempt) this.closing.delete(mode);
    }
  }

  private async closeEntries(mode: NativeBuildResourceCleanupMode): Promise<void> {
    const failures: unknown[] = [];
    for (const entry of [...this.entries].reverse()) {
      if (mode === "handle" && !entry.closeOnHandle) continue;
      if (mode === "failure" ? entry.completedOnFailure : entry.completedOnHandle) continue;
      try {
        await this.hooks?.beforeCleanup?.(entry.stage);
        await entry.cleanup();
        if (mode === "failure") {
          entry.completedOnFailure = true;
        } else {
          entry.completedOnHandle = true;
        }
      } catch (error) {
        failures.push(error);
      }
    }
    if (failures.length > 0) {
      throw new AggregateError(
        failures,
        `Could not close all native Build ${mode} resources.`,
      );
    }
  }
}

interface RetryableNativeBuildCleanup {
  close(): Promise<void>;
  isComplete(): boolean;
}

function retryableNativeBuildCleanup(
  action: () => void | Promise<void>,
): RetryableNativeBuildCleanup {
  let complete = false;
  let closing: Promise<void> | undefined;
  return Object.freeze({
    async close() {
      if (complete) return;
      if (closing) return await closing;
      const attempt = Promise.resolve().then(action);
      closing = attempt;
      try {
        await attempt;
        complete = true;
      } finally {
        if (closing === attempt) closing = undefined;
      }
    },
    isComplete: () => complete,
  });
}

function nativeBuildConstructionFailure(
  stage: NativeBuildRuntimeInitializationStage,
  error: unknown,
): unknown {
  if (error instanceof RunnerCapabilityContractError) return error;
  if (error instanceof NativeBuildRuntimeInitializationError) return error;
  if (stage === "capabilities") {
    return new RunnerCapabilityContractError(
      "capability_preflight_failed",
      `Native Build capability startup failed: ${boundedErrorMessage(error)}.`,
      { cause: error },
    );
  }
  return new NativeBuildRuntimeInitializationError(
    stage,
    `Native Build ${stage} initialization failed: ${boundedErrorMessage(error)}.`,
    { cause: error },
  );
}

function aggregateConstructionFailure(
  runId: string,
  primary: unknown,
  cleanupError: unknown,
): AggregateError {
  const cleanupFailures = cleanupError instanceof AggregateError
    ? [...cleanupError.errors]
    : [cleanupError];
  return new AggregateError(
    [primary, ...cleanupFailures],
    `Native Build ${runId} construction failed and cleanup reported errors.`,
  );
}

export interface RunnerCapabilityPreflightOptions {
  lspTransportFactory?: LspTransportFactory;
  environment?: Readonly<Record<string, string | undefined>>;
  git?: RunGitExecutionContext;
  config: RunnerCapabilitiesConfig;
  projectDirectory: string;
  stateDirectory: string;
  reservedToolNames: readonly string[];
  verifyExtensionIntegrity?: () => Promise<void>;
}

export interface RecoveredRunnerCapabilityPreflightOptions {
  environment?: Readonly<Record<string, string | undefined>>;
  spec: Pick<NativeBuildSpec, "runId" | "capabilityContract">;
  config: RunnerCapabilitiesConfig;
  projectDirectory: string;
  stateDirectory: string;
  reservedToolNames: readonly string[];
}

interface ClosableLanguageProvider {
  close(): Promise<void>;
}

class NativeCapabilityStartupCleanupError extends AggregateError {
  constructor(
    errors: readonly unknown[],
    readonly disposer: NativeCapabilityCleanupOwner,
  ) {
    super(errors, "Runner capability startup failed and cleanup remains incomplete.");
    this.name = "NativeCapabilityStartupCleanupError";
  }
}

class NativeCapabilityCleanupOwner {
  private closePromise?: Promise<void>;
  private closed = false;

  constructor(
    private pendingProviders: ClosableLanguageProvider[],
    private pendingExtensions?: RunnerExtensionCleanupDisposer,
  ) {
    this.pendingProviders = uniqueClosableProviders(pendingProviders);
  }

  async close(): Promise<void> {
    if (this.closed) return;
    if (this.closePromise) return await this.closePromise;
    const attempt = this.closeOwnedResources();
    this.closePromise = attempt;
    try {
      await attempt;
      this.closed = true;
    } catch (error) {
      if (this.closePromise === attempt) this.closePromise = undefined;
      throw error;
    }
  }

  private async closeOwnedResources(): Promise<void> {
    const failures: unknown[] = [];
    const failedProviders: ClosableLanguageProvider[] = [];
    for (const provider of this.pendingProviders) {
      try {
        await provider.close();
      } catch (error) {
        failures.push(error);
        failedProviders.push(provider);
      }
    }
    this.pendingProviders = failedProviders;
    if (this.pendingExtensions) {
      try {
        await this.pendingExtensions.close();
        this.pendingExtensions = undefined;
      } catch (error) {
        failures.push(error);
      }
    }
    if (failures.length > 0) {
      throw new AggregateError(
        failures,
        "One or more partially started Runner capability resources failed to close.",
      );
    }
  }
}

class NativeRunCapabilities {
  private closePromise?: Promise<void>;
  private closed = false;

  constructor(
    readonly registry: CapabilityRegistry,
    readonly language: LanguageProviderRouter,
    private readonly projectDirectory: string,
    private readonly extensions?: LoadedRunnerExtensions,
  ) {}

  async close(): Promise<void> {
    if (this.closed) return;
    if (this.closePromise) return await this.closePromise;
    const attempt = closeCapabilityResources(
      [this.language],
      this.extensions,
    );
    this.closePromise = attempt;
    try {
      await attempt;
      this.closed = true;
    } catch (error) {
      if (this.closePromise === attempt) this.closePromise = undefined;
      throw error;
    }
  }

  async preflight(): Promise<void> {
    await this.language.preflightConfiguredServers(this.projectDirectory);
  }
}

async function createNativeRunCapabilities(
  options: RunnerCapabilityPreflightOptions,
): Promise<NativeRunCapabilities> {
  const config = await attestRunnerCapabilitiesLanguageServers(options.config, {
    commandSearchDirectory: options.projectDirectory,
    environment: options.environment ?? {},
  });
  const builtInLanguage = new TypeScriptIntelligence(
    new RepositoryIntelligence(options.git ? (request) => options.git!.current().run(request) : undefined),
  );
  let extensions: LoadedRunnerExtensions | undefined;
  let registry: CapabilityRegistry | undefined;
  let language: LanguageProviderRouter | undefined;
  try {
    if (config.extensions.length > 0) {
      extensions = await new LocalPluginLoader({
        pluginDirectories: config.extensions,
        projectDirectory: options.projectDirectory,
        stateDirectory: options.stateDirectory,
        reservedToolNames: options.reservedToolNames,
        ...(options.verifyExtensionIntegrity
          ? { verifyExtensionIntegrity: options.verifyExtensionIntegrity }
          : {}),
      }).load();
    }
    registry = extensions?.registry ?? new CapabilityRegistry([], {
      reservedToolNames: options.reservedToolNames,
    });
    language = new LanguageProviderRouter({
      builtInProvider: builtInLanguage,
      extensionProviders: registry.languageProviders(),
      configuredServers: config.languageServers,
      lspTransportFactory: options.lspTransportFactory,
      environment: options.environment ?? {},
    });
    return new NativeRunCapabilities(
      registry,
      language,
      options.projectDirectory,
      extensions,
    );
  } catch (error) {
    const extensionProviders = language
      ? []
      : (registry?.languageProviders().map((registration) => registration.provider) ?? [])
        .reverse();
    const disposer = new NativeCapabilityCleanupOwner(
      language ? [language] : [...extensionProviders, builtInLanguage],
      extensions ?? extensionCleanupDisposer(error),
    );
    const cleanup = await boundedCapabilityCleanup(disposer);
    if (cleanup.incomplete) {
      throw new NativeCapabilityStartupCleanupError(
        [error, ...cleanup.failures],
        disposer,
      );
    }
    if (cleanup.failures.length > 0) {
      throw new AggregateError(
        [error, ...cleanup.failures],
        "Runner capability startup failed and cleanup reported errors.",
      );
    }
    throw error;
  }
}

async function boundedCapabilityCleanup(
  disposer: NativeCapabilityCleanupOwner,
): Promise<{ failures: unknown[]; incomplete: boolean }> {
  const failures: unknown[] = [];
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      await disposer.close();
      return { failures, incomplete: false };
    } catch (error) {
      failures.push(error);
    }
  }
  return { failures, incomplete: true };
}

function extensionCleanupDisposer(
  error: unknown,
): RunnerExtensionCleanupDisposer | undefined {
  return error instanceof RunnerExtensionLoadError ? error.disposer : undefined;
}

function nativeCapabilityCleanupDisposer(
  error: unknown,
): NativeCapabilityCleanupOwner | undefined {
  return error instanceof NativeCapabilityStartupCleanupError
    ? error.disposer
    : undefined;
}

function uniqueClosableProviders(
  providers: readonly ClosableLanguageProvider[],
): ClosableLanguageProvider[] {
  const seen = new Set<ClosableLanguageProvider>();
  return providers.filter((provider) => {
    if (seen.has(provider)) return false;
    seen.add(provider);
    return true;
  });
}

/** Validates and starts configured capabilities before accepting control-plane traffic. */
export async function preflightRunnerCapabilities(
  options: RunnerCapabilityPreflightOptions,
): Promise<void> {
  const capabilities = await createNativeRunCapabilities(options);
  try {
    await capabilities.preflight();
  } catch (error) {
    try {
      await closePreflightCapabilities(capabilities);
    } catch (cleanupError) {
      throw new AggregateError(
        [error, cleanupError],
        "Runner capability preflight failed and cleanup reported errors.",
      );
    }
    throw error;
  }
  await closePreflightCapabilities(capabilities);
}

async function closePreflightCapabilities(
  capabilities: NativeRunCapabilities,
): Promise<void> {
  try {
    await capabilities.close();
  } catch (firstError) {
    try {
      await capabilities.close();
    } catch (retryError) {
      throw new AggregateError(
        [firstError, retryError],
        "Runner capability preflight cleanup failed after a retry.",
      );
    }
    throw firstError;
  }
}

/** Statically validates the capabilities attributable to one recovered Build. */
export async function preflightRecoveredRunnerCapabilities(
  options: RecoveredRunnerCapabilityPreflightOptions,
): Promise<void> {
  await validateRunnerCapabilityContract(options.spec.capabilityContract, options.config, {
    commandSearchDirectory: options.projectDirectory,
    environment: options.environment ?? {},
  });
  const contract = options.spec.capabilityContract;
  if (!contract) {
    throw new RunnerCapabilityContractError(
      "capability_contract_missing",
      "Active Build recovery requires a persisted Runner capability contract.",
    );
  }
  await validateRunnerCapabilityContractSnapshot(contract, options.stateDirectory);
  const contractConfig = runnerCapabilitiesForContract(options.config, contract);
  try {
    await attestRunnerCapabilitiesLanguageServers(contractConfig, {
      commandSearchDirectory: options.projectDirectory,
    environment: options.environment ?? {},
    });
  } catch (error) {
    throw new RunnerCapabilityContractError(
      "capability_preflight_failed",
      `Active Build recovery capability preflight failed: ${boundedErrorMessage(error)}.`,
      { cause: error },
    );
  }
}

async function closeCapabilityResources(
  languageProviders: readonly ClosableLanguageProvider[],
  extensions: LoadedRunnerExtensions | undefined,
): Promise<void> {
  const failures: unknown[] = [];
  for (const provider of languageProviders) {
    try {
      await provider.close();
    } catch (error) {
      failures.push(error);
    }
  }
  if (extensions) {
    try {
      await extensions.close();
    } catch (error) {
      failures.push(error);
    }
  }
  if (failures.length > 0) {
    throw new AggregateError(
      failures,
      "One or more Runner capabilities failed to close.",
    );
  }
}

export async function cleanupSettledNativeBuild(
  stopManagedProcesses: () => Promise<void>,
  operations: readonly (() => Promise<unknown>)[],
  runId = "run"
): Promise<void> {
  await stopManagedProcesses();
  const failures: unknown[] = [];
  for (const operation of operations) {
    try {
      await operation();
    } catch (error) {
      failures.push(error);
    }
  }
  if (failures.length > 0) {
    throw new AggregateError(
      failures,
      `Could not clean settled Build ${runId}.`
    );
  }
}

export function integrationInitializationModeFromEvents(
  events: readonly SchedulerEvent[]
): "active" | "cleanup-only" {
  if (events.length === 0) return "active";
  // Callers obtain this list from SchedulerStore.readRun(), which already
  // replays and validates every event. Do not reinterpret a terminal legacy
  // history against today's stronger completion preconditions.
  return events.some((event) => event.type === "run.completed")
    ? "cleanup-only"
    : "active";
}

export function deriveNativeVerifierRiskInput(input: {
  projection: SchedulerProjection;
  sessions: readonly AgentSessionProjection[];
  schedulerEvents: readonly SchedulerEvent[];
  toolEvents: readonly ToolLedgerEvent[];
  stricterQualification: boolean;
}): BuildRiskAssessmentInput {
  const accepted = acceptedChangeSessions(input.projection, input.sessions);
  const toolEffects = input.toolEvents.filter(
    (event) => event.type === "tool.started" || event.type === "tool.retry_started",
  );
  return {
    architectDeclaration:
      input.projection.finalVerification?.current?.review?.decision
        ?.architectRisk.risk ?? "low",
    stricterQualification: input.stricterQualification,
    kernelFacts: {
      destructiveEffects: toolEffects.some(
        (event) => event.access?.destructive === true,
      ),
      credentialEffects: toolEffects.some(
        (event) => event.access?.credentialChange === true,
      ),
      externalWriteEffects:
        accepted.some((session) =>
          (session.changeSet?.externalEffects.length ?? 0) > 0
        ) ||
        toolEffects.some(
          (event) =>
            event.effect === "external" ||
            event.access?.external === true ||
            event.outsideWorkspace === true,
        ),
      integrationConflict: input.schedulerEvents.some(
        (event) =>
          event.type === "task.transitioned" &&
          event.payload.status === "integration_resolution",
      ),
      changedPaths: [...new Set(accepted.flatMap(
        (session) => session.changeSet?.changedPaths ?? [],
      ))].sort(),
    },
  };
}

export function buildPlanCritiqueRequest(input: {
  runId: string;
  objective: string;
  architectRuntimeId: string;
  projection: SchedulerProjection;
  baselineRevision: string;
  riskReasons: readonly PlanRiskReason[];
  preferredRuntimeId?: string;
  providerRetryDeadlineMs?: number;
  signal?: AbortSignal;
}): NativePlanCritiqueRequest {
  const guidance = [
    ...Object.values(input.projection.userGuidance).map((item) => ({
      id: item.guidanceId,
      kind: "user_guidance" as const,
      version: item.version,
      text: item.text,
    })),
    ...Object.values(input.projection.guidance)
      .filter((item) => item.status === "answered" && item.answer)
      .map((item) => ({
        id: item.requestId,
        kind: "architect_answer" as const,
        version: item.version,
        text: item.answer!,
      })),
    ...Object.values(input.projection.architectQuestions)
      .filter((item) => item.status === "answered" && item.answer)
      .map((item) => ({
        id: item.questionId,
        kind: "architect_answer" as const,
        version: item.version,
        text: item.answer!,
      })),
  ].sort((left, right) => left.id.localeCompare(right.id));
  return {
    runId: input.runId,
    objective: input.objective,
    planRevision: input.projection.planRevision,
    baselineRevision: input.baselineRevision,
    architectRuntimeId: input.architectRuntimeId,
    tasks: Object.values(input.projection.tasks)
      .filter((task) => task.status !== "cancelled" && !isFinalVerificationTask(task)),
    riskReasons: [...input.riskReasons],
    guidance,
    ...(input.preferredRuntimeId ? { preferredRuntimeId: input.preferredRuntimeId } : {}),
    ...(input.providerRetryDeadlineMs !== undefined
      ? { providerRetryDeadlineMs: input.providerRetryDeadlineMs }
      : {}),
    ...(input.signal ? { signal: input.signal } : {}),
  };
}

export function runBaselineRevision(
  schedulerEvents: readonly SchedulerEvent[],
  projection: SchedulerProjection,
): string {
  const first = schedulerEvents.find(
    (event) =>
      event.type === "integration.revision_advanced" &&
      typeof event.payload.previousIntegrationRevision === "string" &&
      event.payload.previousIntegrationRevision.trim().length > 0,
  );
  const baseline = first
    ? (first.payload.previousIntegrationRevision as string)
    : projection.integrationRevision;
  if (!baseline) throw new Error("Run baseline revision is unknown.");
  return baseline;
}

export function buildNativeVerifierInspectionRequest(input: {
  runId: string;
  objective: string;
  architectRuntimeId: string;
  projection: SchedulerProjection;
  sessions: readonly AgentSessionProjection[];
  schedulerEvents: readonly SchedulerEvent[];
  twoPass: boolean;
  risk: BuildRiskAssessmentProjection;
  preferredRuntimeId?: string;
  providerRetryDeadlineMs?: number;
  signal?: AbortSignal;
}): NativeVerifierInspectionRequest {
  const integrationRevision = input.projection.integrationRevision;
  const finalVerification = input.projection.finalVerification?.current;
  if (
    !integrationRevision || !finalVerification ||
    finalVerification.state !== "current" ||
    finalVerification.targetRevision !== integrationRevision ||
    finalVerification.submissionResult?.green !== true ||
    input.risk.state !== "current" ||
    input.risk.targetRevision !== integrationRevision
  ) {
    throw new Error(
      "Native verifier context requires current risk and green final verification for the integration revision.",
    );
  }
  const reviews = Object.values(input.projection.reviewHistory ?? {})
    .flatMap((history) => history)
    .concat(
      Object.entries(input.projection.reviewHistory ?? {}).length === 0
        ? Object.values(input.projection.reviews)
        : [],
    )
    .sort((left, right) =>
      left.taskId.localeCompare(right.taskId) ||
      (left.attempt ?? 0) - (right.attempt ?? 0)
    );
  const guidance = [
    ...Object.values(input.projection.userGuidance).map((item) => ({
      id: item.guidanceId,
      kind: "user_guidance" as const,
      version: item.version,
      text: item.text,
    })),
    ...Object.values(input.projection.guidance)
      .filter((item) => item.status === "answered" && item.answer)
      .map((item) => ({
        id: item.requestId,
        kind: "architect_answer" as const,
        version: item.version,
        text: item.answer!,
      })),
    ...Object.values(input.projection.architectQuestions)
      .filter((item) => item.status === "answered" && item.answer)
      .map((item) => ({
        id: item.questionId,
        kind: "architect_answer" as const,
        version: item.version,
        text: item.answer!,
      })),
  ].sort((left, right) => left.id.localeCompare(right.id));
  const changes = acceptedChangeSessions(input.projection, input.sessions)
    .map((session) => {
      const changeSet = session.changeSet!;
      // The session actor id is the worker assignment id (worker_Task_Attempt),
      // never a provider runtime: resolve the recorded assignment runtime so
      // verifier selection can exclude the author's model. The actor id
      // remains as fallback, which selection still rejects loudly when unknown.
      const assignment = Object.values(input.projection.runtime.workerAssignments).find(
        (candidate) => candidate.sessionId === session.sessionId,
      );
      return {
        taskId: changeSet.taskId,
        attempt: input.projection.tasks[changeSet.taskId]?.attempt ?? 1,
        changeSetId: changeSet.id,
        authorRuntimeId: assignment?.runtimeId ?? session.actor.id,
        baselineRevision: changeSet.baselineRevision,
        taskRevision: changeSet.taskRevision,
        changedPaths: [...changeSet.changedPaths],
        diffArtifactHash: changeSet.diffArtifactHash,
      };
    })
    .sort((left, right) =>
      left.taskId.localeCompare(right.taskId) ||
      left.changeSetId.localeCompare(right.changeSetId)
    );
  return {
    runId: input.runId,
    objective: input.objective,
    targetRevision: integrationRevision,
    architectRuntimeId: input.architectRuntimeId,
    criteria: Object.values(input.projection.tasks)
      .filter(
        (task) =>
          task.status !== "cancelled" &&
          task.kind !== "final_verification",
      )
      .flatMap((task) => (task.acceptanceCriteria ?? []).map((criterion) => ({
        taskId: task.id,
        taskTitle: task.objective,
        criterion: { ...criterion },
      })))
      .sort((left, right) =>
        left.taskId.localeCompare(right.taskId) ||
        left.criterion.id.localeCompare(right.criterion.id)
      ),
    reviews: reviews.map((review) => ({
      taskId: review.taskId,
      attempt: review.attempt ?? input.projection.tasks[review.taskId]?.attempt ?? 1,
      status: review.status,
      ...(review.summary ? { summary: review.summary } : {}),
      evidenceArtifactHashes: [...review.evidenceArtifactHashes],
      ...(review.criterionVerdicts
        ? {
            criterionVerdicts: review.criterionVerdicts.map((verdict) => ({
              ...verdict,
              evidenceIds: [...verdict.evidenceIds],
              ...(verdict.artifactHashes
                ? { artifactHashes: [...verdict.artifactHashes] }
                : {}),
            })),
          }
        : {}),
    })),
    guidance,
    changes,
    finalVerification: {
      generationId: finalVerification.generationId,
      targetRevision: finalVerification.targetRevision,
      green: finalVerification.submissionResult.green,
      checks: finalVerification.submissionResult.checks.map((check) => ({
        ...check,
        evidenceIds: [...check.evidenceIds],
        facts: check.facts.map((fact) => structuredClone(fact)),
        issues: [],
      })),
    },
    riskReasons: input.risk.assessment.reasons.map((reason) => ({
      ...reason,
      evidence: [...reason.evidence],
    })),
    baselineRevision: runBaselineRevision(input.schedulerEvents, input.projection),
    twoPass: input.twoPass,
    ...(input.preferredRuntimeId
      ? { preferredRuntimeId: input.preferredRuntimeId }
      : {}),
    ...(input.providerRetryDeadlineMs !== undefined
      ? { providerRetryDeadlineMs: input.providerRetryDeadlineMs }
      : {}),
    ...(input.signal ? { signal: input.signal } : {}),
  };
}

function acceptedChangeSessions(
  projection: SchedulerProjection,
  sessions: readonly AgentSessionProjection[],
): AgentSessionProjection[] {
  const acceptedIds = new Set(
    Object.values(projection.tasks)
      .filter(
        (task) => task.status === "integrated" && Boolean(task.changeSetId),
      )
      .map((task) => task.changeSetId!),
  );
  return sessions.filter(
    (session) =>
      session.actor.role === "worker" &&
      Boolean(session.changeSet) &&
      acceptedIds.has(session.changeSet!.id) &&
      projection.tasks[session.changeSet!.taskId]?.changeSetId ===
        session.changeSet!.id,
  );
}

function summarizeToolCalls(
  events: ReturnType<SqliteToolLedger["listRun"]>
): BuildToolObservation[] {
  const calls = new Map<string, BuildToolObservation>();
  for (const event of events) {
    if (!event.sessionId || !event.callId || !event.toolName) continue;
    const previous = calls.get(event.key);
    calls.set(event.key, {
      sequence: event.sequence,
      sessionId: event.sessionId,
      callId: event.callId,
      toolName: event.toolName,
      ...(event.extensionId
        ? { extensionId: event.extensionId }
        : previous?.extensionId
          ? { extensionId: previous.extensionId }
          : {}),
      status: event.type === "tool.completed"
        ? "completed"
        : event.type === "tool.retry_started"
          ? "retrying"
          : "started",
      occurredAt: event.occurredAt,
      ...(event.result ? { isError: event.result.isError } : previous?.isError !== undefined
        ? { isError: previous.isError }
        : {}),
      ...(event.result?.error?.code
        ? { errorCode: event.result.error.code }
        : previous?.errorCode
          ? { errorCode: previous.errorCode }
          : {}),
    });
  }
  return [...calls.values()].sort((left, right) => left.sequence - right.sequence);
}

export function defaultSharedSkillRoots(): SharedSkillRoot[] {
  const builtIn = resolve(dirname(fileURLToPath(import.meta.url)), "..", "skills");
  const home = homedir();
  return [
    { path: builtIn, source: "built-in" },
    { path: join(home, ".codex", "skills"), source: "user" },
    { path: join(home, ".claude", "skills"), source: "user" },
    { path: join(home, ".aiboard", "skills"), source: "user" },
  ];
}

export function providerHealthFromSchedulerEvents(
  events: readonly SchedulerEvent[]
): ProviderHealthState[] {
  if (events.length === 0) return [];
  return Object.values(
    rebuildSchedulerProjection(events).runtime.providerHealth
  ).filter(isProviderHealthState);
}

function persistProviderHealth(
  store: SqliteSchedulerStore,
  runId: string,
  state: ProviderHealthState,
  source: string,
): void {
  store.append({
    runId,
    type: "provider.health_changed",
    occurredAt: new Date(state.updatedAt).toISOString(),
    actor: { role: "runner", id: "runtime-router" },
    idempotencyKey: [
      "provider-health",
      source,
      state.providerId,
      state.updatedAt,
      state.consecutiveFailures,
      state.status,
    ].join(":"),
    payload: { state: { ...state } },
  });
}

function selectConfigs(
  configs: readonly RunnerProviderConfig[],
  spec: NativeBuildSpec
): RunnerProviderConfig[] {
  const required = new Set([
    spec.architectRuntimeId,
    ...spec.workerRuntimeIds,
    ...spec.verifierRuntimeIds,
  ]);
  const selected = configs.filter((config) => required.has(config.runtimeId));
  for (const runtimeId of required) {
    if (!selected.some((config) => config.runtimeId === runtimeId)) {
      throw new Error(`Provider runtime ${runtimeId} is not configured.`);
    }
  }
  return selected;
}

export function selectRuntimeCandidates(
  configs: readonly RunnerProviderConfig[],
  spec: NativeBuildSpec
): {
  configs: RunnerProviderConfig[];
  all: AgentRuntimeCandidate[];
  workers: AgentRuntimeCandidate[];
  verifiers: AgentRuntimeCandidate[];
} {
  const selected = selectConfigs(configs, spec);
  const all = selected.map(toCandidate);
  const workerIds = new Set(spec.workerRuntimeIds);
  const verifierIds = new Set(spec.verifierRuntimeIds);
  return {
    configs: selected,
    all,
    workers: all.filter((candidate) => workerIds.has(candidate.runtimeId)),
    verifiers: all.filter((candidate) => verifierIds.has(candidate.runtimeId)),
  };
}

function toCandidate(config: RunnerProviderConfig): AgentRuntimeCandidate {
  return {
    runtimeId: config.runtimeId,
    providerId: config.providerId,
    modelId: config.modelId,
    capabilities: [...config.capabilities],
    priority: config.priority,
  };
}

export function configuredModelUsageRuntime(
  config: RunnerProviderConfig,
  spec: NativeBuildSpec
): NativeModelUsageRuntime {
  const roles = new Set<NativeModelUsageRuntime["roles"][number]>();
  if (config.runtimeId === spec.architectRuntimeId) roles.add("architect");
  if (spec.workerRuntimeIds.includes(config.runtimeId)) roles.add("worker");
  if (spec.verifierRuntimeIds.includes(config.runtimeId)) roles.add("verifier");
  return {
    ...providerUsageConfig(config),
    roles: [...roles],
    selectable:
      roles.has("worker") ||
      config.capabilities.includes("*") ||
      config.capabilities.includes("code"),
  };
}

export function snapshotNativeBuildAmbientEnvironment(
  source: Readonly<Record<string, string | undefined>> = process.env,
): Readonly<Record<string, string>> {
  const filtered = Object.create(null) as Record<string, string>;
  for (const [name, value] of Object.entries(source)) {
    const canonical = name.toUpperCase();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || value === undefined ||
        isSensitiveKey(name) || /(?:TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTHORIZATION|API[_-]?KEY)/i.test(name) ||
        canonical.startsWith("RUNNER_") || canonical.startsWith("AIBOARD_RUNNER_")) continue;
    filtered[name] = value;
  }
  return Object.freeze(filtered);
}

export function createProviderModel(
  config: RunnerProviderConfig,
  artifacts?: ArtifactStore
): AgentModel {
  if (config.transport === "account-runner") {
    if (!config.baseUrl) {
      throw new Error(`Account runtime ${config.runtimeId} requires a baseUrl.`);
    }
    return new AccountRunnerModel({
      baseUrl: config.baseUrl,
      runnerPath: config.providerId,
      runnerToken: config.runnerToken ?? config.secret,
      modelId: config.modelId,
      ...(config.runnerToken ? { providerApiKey: config.secret } : {}),
      ...(config.reasoningEffort ? { reasoningEffort: config.reasoningEffort } : {}),
      ...(config.inputCapabilities
        ? { inputCapabilities: { ...config.inputCapabilities } }
        : {}),
      ...(artifacts
        ? { readArtifact: (hash: string) => artifacts.get(hash) }
        : {}),
    });
  }
  if (config.transport === "anthropic") {
    return new AnthropicModel({
      ...(config.baseUrl ? { baseUrl: config.baseUrl } : {}),
      apiKey: config.secret,
      modelId: config.modelId,
      ...(config.reasoningEffort ? { reasoningEffort: config.reasoningEffort } : {}),
    });
  }
  if (config.transport === "google") {
    return new GoogleModel({
      ...(config.baseUrl ? { baseUrl: config.baseUrl } : {}),
      apiKey: config.secret,
      modelId: config.modelId,
      ...(config.reasoningEffort ? { reasoningEffort: config.reasoningEffort } : {}),
    });
  }
  if (!config.baseUrl) {
    throw new Error(`OpenAI-compatible runtime ${config.runtimeId} requires a baseUrl.`);
  }
  return new OpenAICompatibleModel({
    baseUrl: config.baseUrl,
    apiKey: config.secret,
    modelId: config.modelId,
    providerId: config.providerId,
    ...(config.supportsTools !== undefined ? { supportsTools: config.supportsTools } : {}),
    ...(config.hostedTools ? { hostedTools: config.hostedTools } : {}),
    ...(config.protocol
      ? { protocol: config.protocol }
      : config.providerId === "xai"
        ? { protocol: "responses" as const }
        : {}),
    ...(config.reasoningEffort ? { reasoningEffort: config.reasoningEffort } : {}),
    ...(config.providerId === "openai" ? { promptCaching: true } : {}),
  });
}

export function providerCostEstimator(
  config: RunnerProviderConfig
): ModelCostEstimator | undefined {
  if (
    resolvedProviderBillingBasis(config) !== "api_priced" ||
    config.inputCostMicrosPerMillion === undefined ||
    config.outputCostMicrosPerMillion === undefined
  ) return undefined;
  const inputRate = config.inputCostMicrosPerMillion;
  const outputRate = config.outputCostMicrosPerMillion;
  const cachedRate = config.cachedInputCostMicrosPerMillion ?? inputRate;
  const cacheWriteRate = config.cacheWriteInputCostMicrosPerMillion ?? inputRate;
  return (inputTokens, outputTokens, cachedInputTokens = 0, cacheWriteInputTokens = 0) => {
    const cached = Math.min(inputTokens, cachedInputTokens);
    const cacheWrite = Math.min(inputTokens - cached, cacheWriteInputTokens);
    const uncached = inputTokens - cached - cacheWrite;
    return Math.round((
      uncached * inputRate +
      cached * cachedRate +
      cacheWrite * cacheWriteRate +
      outputTokens * outputRate
    ) / 1_000_000);
  };
}

export function providerModelCostBasis(
  config: RunnerProviderConfig
): ModelCostBasisSnapshot {
  const billingBasis = resolvedProviderBillingBasis(config);
  if (billingBasis === "account_not_metered") {
    return { kind: "account_not_metered", billingBasis };
  }
  if (
    billingBasis !== "api_priced" ||
    config.inputCostMicrosPerMillion === undefined ||
    config.outputCostMicrosPerMillion === undefined
  ) return { kind: "unknown", billingBasis: "unknown" };
  return {
    kind: "api_estimate",
    billingBasis,
    inputCostMicrosPerMillion: config.inputCostMicrosPerMillion,
    outputCostMicrosPerMillion: config.outputCostMicrosPerMillion,
    cachedInputCostMicrosPerMillion:
      config.cachedInputCostMicrosPerMillion ?? config.inputCostMicrosPerMillion,
    cacheWriteInputCostMicrosPerMillion:
      config.cacheWriteInputCostMicrosPerMillion ?? config.inputCostMicrosPerMillion,
  };
}

export function assertEnforceableBuildBudget(
  spec: NativeBuildSpec,
  configs: readonly RunnerProviderConfig[]
): void {
  const message = nativeBuildBudgetEnforceabilityError(
    spec,
    configs.map((config) => ({
      runtimeId: config.runtimeId,
      costBasis:
        resolvedProviderBillingBasis(config) === "account_not_metered"
          ? "account_not_metered"
          : resolvedProviderBillingBasis(config) === "api_priced"
            ? "priced_api"
            : "unknown",
    }))
  );
  if (message) throw new Error(message);
}

function isProviderHealthState(value: unknown): value is ProviderHealthState {
  if (!value || typeof value !== "object") return false;
  const state = value as Partial<ProviderHealthState>;
  return (
    typeof state.providerId === "string" &&
    (state.status === "healthy" || state.status === "cooldown") &&
    typeof state.consecutiveFailures === "number" &&
    typeof state.updatedAt === "number"
  );
}

function safeSegment(value: string): string {
  return runnerRunStateSegment(value);
}

async function loadHistoricalFinalVerificationDiagnostics(input: {
  stateDirectory: string;
  runId: string;
  diagnosticsPath?: string;
  generationId: string;
  taskId: string;
  targetRevision: string;
}) {
  const read = async (expectedRunSegment: string) => await loadFinalVerificationDiagnostics({
    ...input,
    expectedRunSegment,
  });
  // Older historical layouts used the Build run-root segment. Cleanup's
  // production archive uses its own hashed ownership segment; accept either
  // exact Runner-owned root without widening the containment check.
  return await read(safeSegment(input.runId)) ?? await read(
    createHash("sha256").update(input.runId).digest("hex").slice(0, 32),
  );
}

function boundedErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  return message.length <= 512 ? message : `${message.slice(0, 512)}…`;
}

async function loadOrCreateProcessStateKey(path: string): Promise<Uint8Array> {
  try {
    const existing = await readFile(path);
    if (existing.byteLength !== 32) throw new Error("Runner subprocess state key is invalid.");
    return new Uint8Array(existing);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  const bytes = randomBytes(32);
  let handle;
  try {
    handle = await open(path, "wx", 0o600);
    await handle.writeFile(bytes);
    await handle.sync();
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "EEXIST") {
      const existing = await readFile(path);
      if (existing.byteLength !== 32) throw new Error("Runner subprocess state key is invalid.");
      return new Uint8Array(existing);
    }
    throw error;
  } finally {
    await handle?.close();
  }
  return new Uint8Array(bytes);
}

function assertIsolationRecoveryClear(
  results: readonly { providerId: string; blockers: readonly string[] }[],
): void {
  const blockers = results.flatMap((result) =>
    result.blockers.map((blocker) => `${result.providerId}: ${blocker}`));
  if (blockers.length > 0) {
    throw new Error(
      `Configured execution-isolation recovery is blocked: ${blockers.join("; ")}`,
    );
  }
}

/** Derives usage identities solely from settled, attributable budget records. */
function historicalModelUsageRuntimes(
  budget: BudgetProjection,
): NativeModelUsageRuntime[] {
  const runtimes = new Map<string, {
    providerId: string;
    modelId: string;
    roles: Set<NativeModelUsageRuntime["roles"][number]>;
  }>();
  for (const reservation of Object.values(budget.reservations)) {
    if (
      reservation.kind !== "model" ||
      reservation.status !== "settled" ||
      !reservation.actual ||
      !reservation.attribution
    ) continue;
    const attribution = reservation.attribution;
    const existing = runtimes.get(attribution.runtimeId);
    if (
      existing &&
      (existing.providerId !== attribution.providerId ||
        existing.modelId !== attribution.modelId)
    ) {
      throw new Error(
        `Historical model attribution conflicts for ${attribution.runtimeId}.`,
      );
    }
    const runtime = existing ?? {
      providerId: attribution.providerId,
      modelId: attribution.modelId,
      roles: new Set<NativeModelUsageRuntime["roles"][number]>(),
    };
    runtime.roles.add(attribution.role);
    runtimes.set(attribution.runtimeId, runtime);
  }
  return [...runtimes.entries()]
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([runtimeId, runtime]) => ({
      runtimeId,
      providerId: runtime.providerId,
      modelId: runtime.modelId,
      // A terminal reader intentionally does not consult current provider config.
      billingBasis: "unknown" as const,
      transport: "openai-compatible" as const,
      roles: [...runtime.roles],
      selectable: false,
    }));
}

/** Returns the latest durable `list_skills` result for this run, if recorded. */
function skillsFromHistoricalToolLedger(
  events: readonly ToolLedgerEvent[],
): SkillMetadata[] | undefined {
  let latest: SkillMetadata[] | undefined;
  for (const event of events) {
    const result = event.result;
    if (
      event.type !== "tool.completed" ||
      event.toolName !== "list_skills" ||
      !result ||
      result.isError
    ) continue;
    for (const block of result.content) {
      if (block.type !== "json" || !Array.isArray(block.value)) continue;
      latest = block.value.map((value, index) => historicalSkillMetadata(value, index));
    }
  }
  return latest?.map((skill) => ({ ...skill }));
}

function historicalSkillMetadata(value: unknown, index: number): SkillMetadata {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`Historical list_skills result ${index} is malformed.`);
  }
  const skill = value as Record<string, unknown>;
  if (
    typeof skill.id !== "string" ||
    typeof skill.name !== "string" ||
    typeof skill.description !== "string" ||
    typeof skill.relativePath !== "string" ||
    typeof skill.digest !== "string" ||
    !/^[a-f0-9]{64}$/.test(skill.digest) ||
    !Number.isSafeInteger(skill.byteLength) ||
    (skill.byteLength as number) < 0 ||
    (skill.source !== "project" && skill.source !== "built-in" && skill.source !== "user")
  ) {
    throw new Error(`Historical list_skills result ${index} is malformed.`);
  }
  return {
    id: skill.id,
    name: skill.name,
    description: skill.description,
    relativePath: skill.relativePath,
    digest: skill.digest,
    byteLength: skill.byteLength as number,
    source: skill.source as SkillMetadata["source"],
  };
}

/**
 * Node's SQLite read-only connections may still create WAL shared-memory
 * sidecars beside the opened file. Historical reads therefore open a private
 * copy outside Runner state, including WAL-visible committed content.
 */
/**
 * T6b repair (OA-17): backstop search over Runner-private scheduler
 * creation records. Deletes only a path whose record this run wrote itself
 * AND that is still under a runner-owned root and outside the workspace /
 * project tree. Symlinks and junctions are observed with lstat and never
 * followed; anything unproven is retained and reported (probe F).
 */
export async function searchRunnerOwnedTempLeftovers(input: {
  records: readonly TempCreationRecord[];
  ownerRunId: string;
  ownerProjectId: string;
  runnerRoots: readonly string[];
  excludedRoots: readonly string[];
  cleared: (path: string) => void;
}): Promise<LeftoverCleanupRecord[]> {
  const findings: LeftoverCleanupRecord[] = [];
  const expected = { ownerRunId: input.ownerRunId, ownerProjectId: input.ownerProjectId };
  for (const record of filterRecordsForOwner(input.records, expected)) {
    let observation: { exists: boolean; isSymbolicLink: boolean; kindMatches: boolean };
    try {
      const entry = await lstat(record.path);
      observation = { exists: true, isSymbolicLink: entry.isSymbolicLink(), kindMatches: record.kind === "file" ? entry.isFile() : entry.isDirectory() };
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") {
        observation = { exists: false, isSymbolicLink: false, kindMatches: true };
      } else {
        findings.push({ path: record.path, ownership: "proven", action: "retained", reason: `Recorded path could not be inspected (${(error as Error).message}); retained and reported.` });
        continue;
      }
    }
    const decision = decideRecordedTempCleanup(record, expected, input.runnerRoots, observation, input.excludedRoots);
    if (decision.ownership === "proven" && decision.action === "cleaned") {
      if (observation.exists) {
        try {
          await rm(record.path, { recursive: true, force: true });
        } catch (error) {
          findings.push({ path: record.path, ownership: "proven", action: "retained", reason: `Owned leftover could not be removed (${(error as Error).message}); retained and reported.` });
          continue;
        }
      }
      try { input.cleared(record.path); } catch { /* bookkeeping only */ }
    }
    findings.push(decision);
  }
  return findings;
}

/**
 * T6b repair (R2-B6): the exact runner-owned roots the OA-17 temp search
 * may delete under. Each is one disposable workspace this run's factory
 * creates under Runner state (verification, independent verifier,
 * Architect command copy, delivery review/boundary checkouts, verifier
 * baseline). The system temp directory, the Runner state directory, and
 * the run root are never roots: a record pointing anywhere else in them
 * (a user folder, credentials) is retained, never deleted.
 */
export function nativeBuildCleanupRoots(stateDirectory: string, runId: string): string[] {
  // This helper only reads `.path` (pure path math, never git): the owner
  // is explicitly the unavailable runner, so a stray execution fails
  // closed instead of running ownerless.
  const at = (workspaceSuffix?: string, kind?: "independent-verifier") => new VerificationWorkspaceManager({
    execute: unavailableGitRunner,
    repositoryRoot: stateDirectory,
    stateDirectory,
    runId,
    ...(kind ? { kind } : {}),
    ...(workspaceSuffix ? { workspaceSuffix } : {}),
  }).path;
  return [
    at(),
    at(undefined, "independent-verifier"),
    at("architect-commands", "independent-verifier"),
    at("delivery-review", "independent-verifier"),
    at("delivery-boundary", "independent-verifier"),
    at("test-integrity-baseline", "independent-verifier"),
    at("baseline", "independent-verifier"),
  ];
}

async function materializeHistoricalSqliteSnapshot(source: string): Promise<{
  directory: string;
  databasePath: string;
}> {
  const directory = await mkdtemp(join(tmpdir(), "aiboard-historical-sqlite-"));
  // T6b repair (OA-17): historical snapshots are tracked in the in-memory
  // ownership list at the call site and removed by closeHistoricalResources
  // with retry; the creation is validated here and never written to a
  // shared registry, so executed workloads cannot forge ownership.
  recordTempCreation({ path: directory, ownerRunId: "historical-read", ownerProjectId: "runner-state", createdAt: new Date().toISOString(), kind: "directory" });
  const databasePath = join(directory, basename(source));
  try {
    await copyFile(source, databasePath);
    for (const suffix of ["-wal", "-shm"] as const) {
      const sidecar = `${source}${suffix}`;
      if (hasOptionalHistoricalFile(sidecar)) {
        await copyFile(sidecar, `${databasePath}${suffix}`);
      }
    }
    return { directory, databasePath };
  } catch (error) {
    try {
      await rm(directory, { recursive: true, force: true });
    } catch (cleanupError) {
      throw new AggregateError(
        [error, cleanupError],
        `Could not materialize historical SQLite snapshot ${source}.`,
      );
    }
    throw error;
  }
}

interface HistoricalCloseable {
  close(): void;
}

/**
 * Historical readers never bootstrap a database. A terminal Build may predate
 * one of these optional stores, in which case callers receive the equivalent
 * empty projection while the path remains absent.
 */
function hasHistoricalStore(path: string): boolean {
  try {
    const metadata = statSync(path);
    if (metadata.isFile()) return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
  throw new Error(`Historical Runner store ${path} must be a regular file.`);
}

function hasOptionalHistoricalFile(path: string): boolean {
  try {
    const metadata = statSync(path);
    if (metadata.isFile()) return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
  throw new Error(`Historical Runner store sidecar ${path} must be a regular file.`);
}

function hasHistoricalDirectory(path: string): boolean {
  try {
    const metadata = statSync(path);
    if (metadata.isDirectory()) return true;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return false;
    throw error;
  }
  throw new Error(`Historical Runner directory ${path} must be a directory.`);
}

function historicalSchedulerProjection(
  spec: NativeBuildSpec,
  events: readonly SchedulerEvent[],
  terminalState: HistoricalTerminalState,
): SchedulerProjection {
  if (events.length > 0) {
    return { ...rebuildSchedulerProjection(events), status: terminalState };
  }
  return {
    runId: spec.runId,
    initialObjective: spec.objective,
    runPolicy: spec.runPolicy,
    status: terminalState,
    planRevision: 0,
    tasks: {},
    guidance: {},
    userGuidance: {},
    userGuidanceVersion: 0,
    architectQuestions: {},
    architectQuestionVersion: 0,
    reviews: {},
    runtime: { providerHealth: {}, workerAssignments: {}, architect: {} },
    lastSequence: 0,
  };
}

function assertHistoricalTerminalState(value: unknown): asserts value is HistoricalTerminalState {
  if (value !== "completed" && value !== "failed" && value !== "stopped") {
    throw new Error("Historical Build requires an authoritative terminal RunSupervisor state.");
  }
}

/**
 * T6a: the OA-11 probe's file system on the disposable review checkout. The
 * probe applies each mutant there and restores the original bytes; this file
 * is the filesystem-mutation owner for those writes.
 */
function deliveryProbeFileSystem(workspacePath: string): MutationFileSystem {
  return {
    // The probe reads originals by project-relative path.
    readFile: (path) => readFileSync(isAbsolute(path) ? path : join(workspacePath, path), "utf8"),
    writeFile: (path, content) => writeFileSync(path, content, "utf8"),
    createDisposableCopy: () => workspacePath,
    cleanupDisposableCopy: () => undefined,
    join: (root, path) => join(root, path),
  };
}


/** Verify the exact linear kernel snapshot chain against durable, tree-bound receipts. */
export async function validateKernelSnapshotVerificationAdvance(input: {
  targetRevision: string;
  canonicalRevision: string;
  projection: SchedulerProjection;
  integrationManager: IntegrationManager;
  execute: import("./git-repository.js").GitRunner;
}): Promise<void> {
  const { projection, integrationManager, targetRevision, canonicalRevision } = input;
  const refuse = (): never => { throw new Error("Canonical checkout revision changed without exact kernel snapshot authority."); };
  // N6: before the first landing no integration revision is recorded, so the
  // durably recorded creation baseline (delivery.test_integrity_initialized,
  // stamped before verification exists) anchors the requested target instead.
  // Authority comes only from durable records, never from the request.
  const authoritativeRevision = projection.integrationRevision ?? projection.testIntegrity?.initialRevision;
  if (projection.projectDocsPolicyVersion !== 2 || authoritativeRevision === undefined || authoritativeRevision !== targetRevision) refuse();
  if (canonicalRevision === targetRevision) return;
  const ancestor = await input.execute({ cwd: integrationManager.path, args: ["merge-base", "--is-ancestor", targetRevision, canonicalRevision], allowFailure: true });
  if (ancestor.exitCode !== 0) refuse();
  const history = await input.execute({ cwd: integrationManager.path, args: ["log", "--reverse", "--format=%H%x00%P%x00", `${targetRevision}..${canonicalRevision}`] });
  const fields = history.stdout.split("\0");
  let parent = targetRevision;
  let count = 0;
  for (let index = 0; index + 1 < fields.length; index += 2) {
    const commit = fields[index]!.trim();
    if (!commit) continue;
    const parents = fields[index + 1]!.trim();
    const matches = (projection.projectDocs?.snapshots ?? []).filter((record) => record.commit === commit);
    if (matches.length !== 1 || parents !== parent || matches[0]!.parent !== parent) refuse();
    const receipt = matches[0]!;
    let audited = await integrationManager.findHandoffSnapshotCommit({ snapshotKey: `stop-snapshot:${receipt.stopSequence}` });
    if (!audited || audited.commit !== commit) audited = await integrationManager.findHandoffSnapshotCommit({ snapshotKey: `handoff-snapshot:${receipt.stopSequence}` });
    if (!audited || audited.commit !== commit || audited.parent !== parent) refuse();
    const stored = await integrationManager.readHandoffSnapshotFile({ commit, path: "docs/project/STATE.md" });
    if (JSON.stringify([...stored.paths].sort()) !== JSON.stringify([...receipt.paths].sort())) refuse();
    if (receipt.bodyDigest) {
      if (!stored.content || !verifyHandoffSnapshotDigest(stored.content) ||
          !stored.content.split(/\r?\n/)[0]!.endsWith(`body_sha256: ${receipt.bodyDigest}`)) refuse();
    } else if (!receipt.stateSkippedReason) refuse();
    parent = commit;
    count += 1;
  }
  if (count === 0 || parent !== canonicalRevision) refuse();
}
