import {
  buildStepResultForProjection,
  type BuildRuntime,
  type BuildStepResult,
} from "./build-runtime.js";
import type {
  BuildObservabilitySnapshot,
  BuildTranscriptPage,
} from "./build-observability.js";
import type {
  ArchitectQuestionAnswerControlInput,
  BuildControlPlane,
  UserGuidanceControlInput,
} from "./build-runtime-registry.js";
import {
  buildSpecCrew,
  sameBuildCrew,
  validateBuildSpec,
  withBuildCrew,
  type BuildSpecStore,
  type NativeBuildCrew,
  type NativeBuildSpec,
} from "./build-spec.js";
import {
  stableProvisioningRequestsMatch,
  type ApprovedSourceInputV1,
  type ProvisioningPrepareOptions,
} from "./native-planning-provisioner.js";
import type {
  ExplicitStartRequestV1,
  PlanningExportDocument,
  PlanningReadinessSnapshot,
  ValidatedSourceAmendmentRequest,
} from "./planning-controls.js";
export type { ApprovedSourceInputV1 } from "./native-planning-provisioner.js";
import type { NativeBuildUsageProjection } from "./model-usage-projection.js";
import type {
  ProjectHandoffChoice,
  SchedulerActor,
  SchedulerEvent,
  FinalVerificationGenerationProjection,
  SchedulerProjection,
} from "./scheduler-store.js";
import { assertProjectHandoffSelectionAccepted, handoffSnapshotAtCurrentStop } from "./scheduler-store.js";
import type {
  IntegrationFileSnapshot,
  ProjectHandoffResult,
} from "./integration-manager.js";
import type { FinalVerificationCleanupController } from "./final-verification-cleanup.js";
import type { ProcessRecoveryCoordinator, RecoveryAuditRecord } from "./process-recovery.js";

export interface NativeBuildRuntimeHandle {
  runtime: BuildRuntime;
  /** A durable terminal projection with no mutable runtime authority. */
  historical?: true;
  usage(): NativeBuildUsageProjection;
  observability(): Promise<BuildObservabilitySnapshot>;
  /** Recorded context packs shown to models; empty when the handle has no store. */
  contextManifests?(): import("./context-manifest-store.js").ContextManifest[];
  /** Runner steps in progress outside model turns; empty on historical handles. */
  activity?(): import("./run-activity.js").RunActivity[];
  transcript(afterSequence?: number): Promise<BuildTranscriptPage>;
  files(): Promise<IntegrationFileSnapshot>;
  compact(): void | Promise<void>;
  /** After compact(): whether an artifact still waits on a reachability proof. Absent means assume yes. */
  hasPendingArtifactCleanup?(): boolean;
  projectHandoff(choice: ProjectHandoffChoice): Promise<ProjectHandoffResult>;
  /** Exceptional process recovery exists only on live handles, never historical readers. */
  processRecovery?: ProcessRecoveryCoordinator;
  /** Constructed cleanup primitive; lifecycle wiring is owned by the P2.6 manager packet. */
  finalVerificationCleanup?: FinalVerificationCleanupController;
  retireInvalidatedFinalVerification?(
    generation: FinalVerificationGenerationProjection,
    currentGeneration?: FinalVerificationGenerationProjection,
  ): Promise<void>;
  cleanup(): void | Promise<void>;
  close(): void | Promise<void>;
}

/** Authoritative lifecycle states that may be projected by a terminal reader. */
export type HistoricalTerminalState = "completed" | "failed" | "stopped";

export type NativeBuildRecoveryFailureStage =
  | "spec_validation"
  | "runtime_construction"
  | "quiescence"
  | "settled_cleanup";

export interface NativeBuildRecoveryFailure {
  readonly runId: string;
  readonly stage: NativeBuildRecoveryFailureStage;
  readonly error: unknown;
}

export interface NativeBuildRecoveryReport {
  readonly failures: readonly NativeBuildRecoveryFailure[];
}

export interface NativeBuildManagerOptions {
  specs: BuildSpecStore;
  createRuntime(spec: NativeBuildSpec): Promise<NativeBuildRuntimeHandle>;
  /** Stamps runner-owned durable identity before a new Build spec is persisted. */
  prepareSpec?(
    spec: NativeBuildSpec,
    options?: ProvisioningPrepareOptions,
  ): Promise<NativeBuildSpec>;
  /** Rejects a stored spec before recovery can construct its runtime or model clients. */
  validateRecoveredSpec?(spec: NativeBuildSpec): Promise<void>;
  /** Rejects a crew-changed spec whose runtimes the runner cannot construct (no provider config). */
  validateCrewSpec?(spec: NativeBuildSpec): void | Promise<void>;
  /** Allows callers with an authoritative lifecycle store to omit settled runs from recovery. */
  shouldRecoverSpec?(spec: NativeBuildSpec): boolean | Promise<boolean>;
  /** Opens storage-backed terminal projections without constructing a live runtime. */
  createHistoricalRuntime?(
    spec: NativeBuildSpec,
    terminalState: HistoricalTerminalState,
  ): Promise<NativeBuildRuntimeHandle>;
  /**
   * The RunSupervisor-derived terminal state. Historical Build reads must not
   * infer completion from an incomplete or absent scheduler log.
   */
  terminalStateForHistoricalSpec?(
    spec: NativeBuildSpec,
  ): HistoricalTerminalState | undefined | Promise<HistoricalTerminalState | undefined>;
  /** Records a durable recovery validation failure without starting the rejected Build. */
  onRecoverySpecError?(runId: string, error: unknown): void;
  shouldAutoRun?(runId: string): boolean;
  onPumpResult?(runId: string, result: BuildStepResult): void;
  onBuildFailed?(runId: string, reason: string): void;
  onPumpError?(runId: string, error: unknown): void;
  runArtifactCompaction?(operation: () => Promise<void>): Promise<void>;
  prepareArtifactCleanup?(): Promise<void>;
}

type NativeBuildHandleShutdownPhase =
  | "status_pending"
  | "settled_cleanup_pending"
  | "ready_for_teardown"
  | "teardown_started";

interface NativeBuildHandleShutdownState {
  phase: NativeBuildHandleShutdownPhase;
}

function readExistingBuildSpec(specs: BuildSpecStore, runId: string): NativeBuildSpec | undefined {
  try {
    return specs.get(runId);
  } catch (error) {
    if (error instanceof Error && error.message === `Unknown Build spec ${runId}.`) {
      return undefined;
    }
    throw error;
  }
}

export class NativeBuildManager implements BuildControlPlane {
  private readonly handles = new Map<string, NativeBuildRuntimeHandle>();
  private readonly handleShutdown = new Map<string, NativeBuildHandleShutdownState>();
  private readonly pumps = new Map<string, Promise<void>>();
  private readonly settledRuns = new Set<string>();
  private operationQueue = Promise.resolve();
  private activityGateClosed = false;
  private activeRuntimeOperations = 0;
  private readonly activityWaiters: Array<{
    resolve(release: () => void): void;
    reject(error: Error): void;
  }> = [];
  private readonly activityIdleWaiters: Array<() => void> = [];
  private liveCompaction: Promise<void> | undefined;
  private closePromise: Promise<void> | undefined;
  private closing = false;
  private closed = false;
  private specsClosed = false;

  constructor(private readonly options: NativeBuildManagerOptions) {}

  async recover(): Promise<NativeBuildRecoveryReport> {
    const active: string[] = [];
    const settled: Array<[string, NativeBuildRuntimeHandle]> = [];
    const quiesceFailed = new Set<string>();
    const failures: NativeBuildRecoveryFailure[] = [];
    await this.serialized(async () => {
      for (const spec of this.options.specs.list()) {
        let shouldRecover = true;
        try {
          shouldRecover = !this.options.shouldRecoverSpec || await this.options.shouldRecoverSpec(spec);
        } catch (error) {
          failures.push({ runId: spec.runId, stage: "spec_validation", error });
          this.options.onRecoverySpecError?.(spec.runId, error);
          this.options.onPumpError?.(spec.runId, error);
          continue;
        }
        if (!shouldRecover) {
          try {
            await this.ensureHistoricalRuntime(spec);
          } catch (error) {
            this.options.onPumpError?.(spec.runId, error);
          }
          continue;
        }
        try {
          await this.options.validateRecoveredSpec?.(spec);
        } catch (error) {
          failures.push({ runId: spec.runId, stage: "spec_validation", error });
          this.options.onRecoverySpecError?.(spec.runId, error);
          this.options.onPumpError?.(spec.runId, error);
          continue;
        }
        let handle: NativeBuildRuntimeHandle;
        try {
          handle = await this.ensureRuntime(spec);
        } catch (error) {
          failures.push({ runId: spec.runId, stage: "runtime_construction", error });
          this.options.onRecoverySpecError?.(spec.runId, error);
          this.options.onPumpError?.(spec.runId, error);
          continue;
        }
        try {
          const projection = handle.runtime.projection();
          const pendingInterruptions = Object.values(projection.userGuidance ?? {})
            .filter((guidance) => guidance.interruptionStatus !== "completed")
            .sort((left, right) => left.version - right.version);
          const orphanedInvalidations = (projection.finalVerification?.history ?? [])
            .filter((generation) =>
              generation.invalidatedByGuidanceId &&
              !projection.userGuidance?.[generation.invalidatedByGuidanceId]
            );
          if (pendingInterruptions.length === 0 && orphanedInvalidations.length === 0) {
            await handle.finalVerificationCleanup?.quiesceRun();
          } else {
            for (const guidance of pendingInterruptions) {
              const interrupted = (projection.finalVerification?.history ?? [])
                .filter((generation) =>
                  generation.invalidatedByGuidanceId === guidance.guidanceId
                );
              if (interrupted.length > 0 && handle.retireInvalidatedFinalVerification) {
                for (const generation of interrupted) {
                  await handle.retireInvalidatedFinalVerification(
                    generation,
                    projection.finalVerification?.current,
                  );
                }
              } else {
                await handle.finalVerificationCleanup?.quiesceRun();
              }
              handle.runtime.completeManagedUserGuidanceInterruption(
                guidance.guidanceId,
                guidance.version,
              );
            }
            for (const generation of orphanedInvalidations) {
              await handle.retireInvalidatedFinalVerification?.(
                generation,
                projection.finalVerification?.current,
              );
            }
          }
        } catch (error) {
          quiesceFailed.add(spec.runId);
          failures.push({ runId: spec.runId, stage: "quiescence", error });
          this.options.onPumpError?.(spec.runId, error);
        }
        const status = handle.runtime.projection().status;
        if (status === "failed" && !quiesceFailed.has(spec.runId)) {
          this.options.onBuildFailed?.(
            spec.runId,
            handle.runtime.projection().failureReason ?? "context_recording_aborted",
          );
          continue;
        }
        if (status === "completed" && !quiesceFailed.has(spec.runId)) {
          settled.push([spec.runId, handle]);
        }
        if (!quiesceFailed.has(spec.runId) && this.options.shouldAutoRun?.(spec.runId)) active.push(spec.runId);
      }
    });
    const compactAndCleanup = async () => {
      await this.compactEligibleRuns();
      if (this.options.prepareArtifactCleanup && this.eligibleRunsAwaitArtifactCleanup()) {
        try {
          await this.options.prepareArtifactCleanup();
          await this.compactEligibleRuns();
        } catch (error) {
          this.options.onPumpError?.("startup-artifact-reachability", error);
        }
      }
      for (const [runId, handle] of settled) {
        try {
          await this.cleanupSettledRun(runId, handle);
        } catch (error) {
          failures.push({ runId, stage: "settled_cleanup", error });
          this.options.onPumpError?.(runId, error);
        }
      }
    };
    if (this.options.runArtifactCompaction) {
      await this.options.runArtifactCompaction(compactAndCleanup);
    } else {
      await compactAndCleanup();
    }
    // Readiness is global: no recovered run may resume effects until every blocking startup owner has reconciled.
    if (failures.length === 0) {
      for (const runId of active) {
        if (this.require(runId).runtime.projection().status === "completed") {
          this.options.onPumpResult?.(runId, {
            status: "completed",
            action: "recovered_settled_build",
          });
        } else {
          this.activate(runId);
        }
      }
    }
    return { failures: Object.freeze([...failures]) };
  }

  async create(
    spec: NativeBuildSpec,
    options?: ProvisioningPrepareOptions,
  ): Promise<SchedulerProjection> {
    return await this.serialized(async () => {
      validateBuildSpec(spec);
      const existing = readExistingBuildSpec(this.options.specs, spec.runId);
      if (existing) {
        if (
          !stableProvisioningRequestsMatch(existing, spec, options?.approvedSourceInput)
        ) {
          throw new Error(`Build spec idempotency conflict for ${spec.runId}.`);
        }
        const handle = await this.ensureRuntime(existing);
        return handle.runtime.projection();
      }
      if (options?.approvedSourceInput !== undefined) {
        if (spec.planningPolicy?.version !== 1) {
          throw new Error(
            "An approved source requires explicit planningPolicy version 1 opt-in; refusing to change the run default."
          );
        }
        if (spec.approvedSource !== undefined) {
          throw new Error(
            "Specify either raw approved-source bytes or a prepared approvedSource manifest, not both."
          );
        }
        if (!this.options.prepareSpec) {
          throw new Error("Approved-source provisioning requires a spec preparation hook.");
        }
      }
      const prepared = this.options.prepareSpec
        ? await this.options.prepareSpec(spec, options)
        : spec;
      const saved = this.options.specs.save(prepared);
      const handle = await this.ensureRuntime(saved);
      return handle.runtime.projection();
    });
  }

  listSpecs(projectId?: string): NativeBuildSpec[] {
    return this.options.specs
      .list()
      .filter((spec) => projectId === undefined || spec.projectId === projectId);
  }

  projection(runId: string): SchedulerProjection {
    return this.require(runId).runtime.projection();
  }

  usage(runId: string): NativeBuildUsageProjection {
    return this.require(runId).usage();
  }

  async observability(runId: string): Promise<BuildObservabilitySnapshot> {
    await this.retireSettledRuntime(runId);
    return await this.withRuntimeActivity(async () => await this.require(runId).observability());
  }

  contextManifests(runId: string): import("./context-manifest-store.js").ContextManifest[] {
    return this.require(runId).contextManifests?.() ?? [];
  }

  activity(runId: string): import("./run-activity.js").RunActivity[] {
    return this.require(runId).activity?.() ?? [];
  }

  async transcript(runId: string, afterSequence = 0): Promise<BuildTranscriptPage> {
    await this.retireSettledRuntime(runId);
    return await this.withRuntimeActivity(async () => await this.require(runId).transcript(afterSequence));
  }

  async files(runId: string): Promise<IntegrationFileSnapshot> {
    await this.retireSettledRuntime(runId);
    return await this.withRuntimeActivity(async () => await this.require(runId).files());
  }

  events(runId: string, afterSequence = 0): SchedulerEvent[] {
    return this.require(runId).runtime.events(afterSequence);
  }

  processRecoveryRecords(runId: string): Readonly<Record<string, RecoveryAuditRecord>> {
    const handle = this.require(runId);
    return handle.processRecovery?.records() ?? handle.runtime.projection().processRecovery ?? {};
  }

  async generateProcessRecovery(runId: string, invocationId: string, proposalId: string): Promise<RecoveryAuditRecord> {
    return await this.withRuntimeActivity(() => this.requireRecovery(runId).generate(invocationId, proposalId));
  }

  async decideProcessRecovery(runId: string, proposalId: string, fingerprint: string, decision: "approve" | "reject"): Promise<RecoveryAuditRecord> {
    return await this.withRuntimeActivity(() => this.requireRecovery(runId).decide(proposalId, fingerprint, decision));
  }

  async executeProcessRecovery(runId: string, proposalId: string, fingerprint: string): Promise<RecoveryAuditRecord> {
    return await this.withRuntimeActivity(() => this.requireRecovery(runId).execute(proposalId, fingerprint));
  }

  async step(runId: string): Promise<BuildStepResult> {
    const handle = this.requireMutable(runId);
    return await this.executeWithFinalization(
      runId,
      handle,
      () => handle.runtime.step()
    );
  }

  async runUntilBlocked(runId: string, maxSteps?: number): Promise<BuildStepResult> {
    const handle = this.requireMutable(runId);
    return await this.executeWithFinalization(
      runId,
      handle,
      () => handle.runtime.runUntilBlocked(maxSteps)
    );
  }

  private readonly activatedRuns = new Set<string>();

  activate(runId: string): void {
    this.assertOpen();
    this.activatedRuns.add(runId);
    const handle = this.requireMutable(runId);
    if (this.pumps.has(runId)) return;
    const projection = handle.runtime.projection();
    const unresolvedContextRecording = projection.status === "paused" &&
      projection.pauseReason?.reason === "context_recording_failed";
    if (
      projection.status !== "running" &&
      !unresolvedContextRecording &&
      projection.projectHandoff?.status !== "requested" &&
      !(projection.status === "completed" && !this.settledRuns.has(runId))
    ) return;
    const pump = this.pump(runId, handle).finally(() => {
      this.pumps.delete(runId);
    });
    this.pumps.set(runId, pump);
    void pump.catch(() => undefined);
  }

  async submitUserGuidance(
    runId: string,
    input: UserGuidanceControlInput
  ): Promise<SchedulerProjection> {
    this.requireMutable(runId);
    const result = await this.withRuntimeActivity(async () =>
      this.serialized(async () => {
        const handle = this.requireMutable(runId);
        const submitted = typeof handle.runtime.submitManagedUserGuidance === "function"
          ? handle.runtime.submitManagedUserGuidance(input)
          : handle.runtime.submitUserGuidance(input);
        const guidance = submitted.userGuidance?.[input.guidanceId];
        if (guidance?.interruptionStatus === "completed") {
          return { projection: submitted, shouldWake: false };
        }
        const interrupted = submitted.status === "completed"
          ? undefined
          : [...(submitted.finalVerification?.history ?? [])]
              .reverse()
              .find((generation) =>
                generation.invalidatedByGuidanceId === input.guidanceId
              );
        if (interrupted && handle.retireInvalidatedFinalVerification) {
          await handle.retireInvalidatedFinalVerification(
            interrupted,
            submitted.finalVerification?.current,
          );
        } else {
          await handle.finalVerificationCleanup?.quiesceRun();
        }
        const projection = typeof handle.runtime.completeManagedUserGuidanceInterruption === "function"
          ? handle.runtime.completeManagedUserGuidanceInterruption(
              input.guidanceId,
              input.version,
            )
          : submitted;
        return { projection, shouldWake: true };
      })
    );
    if (result.shouldWake) this.wake(runId);
    return result.projection;
  }

  async answerArchitectQuestion(
    runId: string,
    input: ArchitectQuestionAnswerControlInput
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.answerArchitectQuestion(input)
    );
    this.wake(runId);
    return projection;
  }

  async awaitIdle(runId?: string): Promise<void> {
    if (runId) {
      const pump = this.pumps.get(runId);
      if (pump) await pump;
      return;
    }
    await Promise.all([...this.pumps.values()]);
  }

  async pause(
    runId: string,
    reason: string,
    idempotencyKey: string
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    return await this.withRuntimeActivity(async () => {
      // C3a repair cycle 2 (R2-1a): record the owner pause/cancel,
      // then quiesce FIRST -- quiesceRun() stops the run's running
      // command and browser, which is what ends an in-flight step.
      // The snapshot call never waits for a step (the runtime returns
      // at once while one is in flight; the step boundary takes the
      // snapshot), so the pause never blocks on a long command or
      // model call, on docs-v1 runs included. The call stays
      // optional for older test doubles; it never throws.
      handle.runtime.pause(reason, idempotencyKey);
      await handle.finalVerificationCleanup?.quiesceRun();
      await handle.runtime.commitStopSnapshotIfStopped?.();
      return handle.runtime.projection();
    });
  }

  async resume(runId: string, idempotencyKey: string): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    return await this.withRuntimeActivity(async () =>
      handle.runtime.resume(idempotencyKey)
    );
  }

  async continue(runId: string, idempotencyKey: string): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    if (!this.options.specs.get(runId).benchmark) {
      throw new Error("Non-renewing continuation is restricted to benchmark Builds.");
    }
    return await this.withRuntimeActivity(async () =>
      handle.runtime.continue(idempotencyKey)
    );
  }

  /**
   * The owner's new role models for a paused run. The change is recorded on the run, the stored
   * spec is rewritten, and the run's runtimes are rebuilt from it exactly as a runner restart would;
   * the next resume continues with the new crew. Before this the crew was fixed at creation, and
   * changing models in the session settings silently did nothing for the running Build.
   */
  async changeCrew(runId: string, crew: NativeBuildCrew, idempotencyKey: string): Promise<SchedulerProjection> {
    return await this.serialized(async () => {
      const handle = this.requireMutable(runId);
      const spec = this.options.specs.get(runId);
      if (sameBuildCrew(buildSpecCrew(spec), crew)) return handle.runtime.projection();
      if (!this.options.specs.replace) throw new Error("This runner cannot change a Build's models.");
      const next = withBuildCrew(spec, crew);
      await this.options.validateCrewSpec?.(next);
      if (this.pumps.has(runId) || handle.runtime.projection().status !== "paused") {
        throw new Error("Pause the Build and let its current step stop before changing its models.");
      }
      await this.withRuntimeActivity(async () => {
        handle.runtime.recordCrewChange(crew, idempotencyKey);
      });
      this.options.specs.replace(next);
      const rebuilt = await this.rebuildRuntime(runId, handle, next, "The new models are saved");
      return rebuilt.runtime.projection();
    });
  }

  /**
   * The owner saved new credentials for these runtimes' providers. Runtimes read provider configs
   * once, at construction, so every paused Build that uses one is rebuilt on the new config, and a
   * cooldown its provider earned under the old credential ends. A running Build keeps its session;
   * a credential failure pauses it, and the owner's fix then lands here.
   */
  async providerCredentialsChanged(changes: readonly { runtimeId: string; providerId: string }[]): Promise<string[]> {
    if (changes.length === 0) return [];
    return await this.serialized(async () => {
      const refreshed: string[] = [];
      for (const [runId, handle] of [...this.handles.entries()]) {
        if (handle.historical || this.pumps.has(runId)) continue;
        if (handle.runtime.projection().status !== "paused") continue;
        const spec = this.options.specs.get(runId);
        const used = new Set([
          spec.architectRuntimeId, ...spec.workerRuntimeIds, ...spec.verifierRuntimeIds, ...(spec.retiredRuntimeIds ?? []),
        ]);
        const providerIds = [...new Set(changes.filter((change) => used.has(change.runtimeId)).map((change) => change.providerId))];
        if (providerIds.length === 0) continue;
        await this.withRuntimeActivity(async () => {
          handle.runtime.clearProviderCooldowns(providerIds, `provider-credentials:${Date.now()}`);
        });
        await this.rebuildRuntime(runId, handle, spec, "The new credentials are saved");
        refreshed.push(runId);
      }
      return refreshed;
    });
  }

  private async rebuildRuntime(
    runId: string,
    handle: NativeBuildRuntimeHandle,
    spec: NativeBuildSpec,
    saved: string,
  ): Promise<NativeBuildRuntimeHandle> {
    this.handles.delete(runId);
    this.handleShutdown.delete(runId);
    try {
      await handle.close();
    } catch (error) {
      // Keep the half-closed handle registered so runner shutdown retries its teardown; the
      // durable records make the restarted runner build the run's runtimes the new way.
      this.handles.set(runId, handle);
      throw new Error(
        `${saved}, but the Build's previous session did not shut down cleanly. Restart the runner to apply them.`,
        { cause: error },
      );
    }
    return await this.ensureRuntime(spec);
  }

  async selectArchitectHandoff(
    runId: string,
    runtimeId: string,
    idempotencyKey: string,
    requiredSequence?: number
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    return await this.withRuntimeActivity(async () =>
      handle.runtime.selectArchitectHandoff(runtimeId, idempotencyKey, requiredSequence)
    );
  }

  async selectVerifierRuntime(
    runId: string,
    runtimeId: string,
    idempotencyKey: string,
    requiredSequence?: number,
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.selectVerifierRuntime(runtimeId, idempotencyKey, requiredSequence)
    );
    this.wake(runId);
    return projection;
  }

  /**
   * T7b: bounded owner approval of the specification bytes for a source-free
   * run. The saved spec is never rewritten; the kernel-derived manifest is
   * recorded through the authoritative user event only.
   */
  async registerPlanningSource(
    runId: string,
    input: { approvedSource: ApprovedSourceInputV1; idempotencyKey: string },
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.registerPlanningSource(input)
    );
    // Semantic planning controls do not start a never-activated supervisor pump.
    if (this.activatedRuns.has(runId)) this.wake(runId);
    return projection;
  }

  /**
   * T7b: bounded owner amendment of the approved source. The predecessor
   * must be the exact current manifest; the saved initial source is never
   * rewritten; bytes land content-addressed before the user event.
   */
  async amendPlanningSource(
    runId: string,
    request: ValidatedSourceAmendmentRequest,
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.amendPlanningSource(request)
    );
    // Semantic planning controls do not start a never-activated supervisor pump.
    if (this.activatedRuns.has(runId)) this.wake(runId);
    return projection;
  }

  /**
   * T7b: semantic current-plan execution authorization. The named identities
   * must equal the current ready identity; stale identities, drift, and
   * unauthorized callers are refused before any worker or runtime effect.
   */
  async authorizeExplicitPlanStart(
    runId: string,
    request: ExplicitStartRequestV1,
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.authorizeExplicitPlanStart(request)
    );
    // Semantic planning controls do not start a never-activated supervisor pump.
    if (this.activatedRuns.has(runId)) this.wake(runId);
    return projection;
  }

  /**
   * T7b: canonical plan-readiness snapshot. Read-only: works on historical
   * terminals, appends nothing, dispatches nothing.
   */
  async setAnswerReview(runId: string, optedIn: boolean, idempotencyKey: string): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(() => handle.runtime.setAnswerReview(optedIn, idempotencyKey));
    if (this.activatedRuns.has(runId)) this.wake(runId);
    return projection;
  }

  planningReadiness(runId: string): PlanningReadinessSnapshot {
    return this.require(runId).runtime.planningReadiness();
  }

  planningSchedule(runId: string): import("./planning-view-contracts.js").NativePlanningSchedule | undefined {
    const handle = this.require(runId);
    return handle.historical ? undefined : handle.runtime.planningSchedule();
  }

  /**
   * T7b: on-demand planning export through the existing C1 renderer.
   * Read-only: works on historical terminals, appends nothing, dispatches
   * nothing, writes no project file.
   */
  planningExport(runId: string): PlanningExportDocument {
    return this.require(runId).runtime.planningExport();
  }

  async extendRepairIssueBudget(runId: string, issueId: string, additionalCycles: number, idempotencyKey: string): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.extendRepairIssueBudget(issueId, additionalCycles, idempotencyKey)
    );
    this.wake(runId);
    return projection;
  }

  async clearRepairExternalBlocker(runId: string, issueId: string, idempotencyKey: string): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.clearRepairExternalBlocker(issueId, idempotencyKey)
    );
    this.wake(runId);
    return projection;
  }

  async extendRepairCycles(
    runId: string,
    additionalRepairPlans: number,
    idempotencyKey: string,
  ): Promise<SchedulerProjection> {
    const handle = this.requireMutable(runId);
    const projection = await this.withRuntimeActivity(async () =>
      handle.runtime.extendRepairCycles(additionalRepairPlans, idempotencyKey)
    );
    this.wake(runId);
    return projection;
  }

  async selectProjectHandoff(
    runId: string,
    choice: ProjectHandoffChoice,
    idempotencyKey: string
  ): Promise<SchedulerProjection> {
    this.requireMutable(runId);
    return await this.selectProjectHandoffAs(
      runId,
      choice,
      idempotencyKey,
      { role: "user", id: "local-user" }
    );
  }

  private async selectProjectHandoffAs(
    runId: string,
    choice: ProjectHandoffChoice,
    idempotencyKey: string,
    actor: SchedulerActor
  ): Promise<SchedulerProjection> {
    this.requireMutable(runId);
    const releaseActivity = await this.acquireRuntimeActivity();
    const compaction = this.requestLiveCompaction();
    let selected: SchedulerProjection;
    try {
      selected = await this.selectProjectHandoffInsideActivity(
        runId,
        choice,
        idempotencyKey,
        actor
      );
    } finally {
      releaseActivity();
    }
    await compaction;
    return selected;
  }

  private async selectProjectHandoffInsideActivity(
    runId: string,
    choice: ProjectHandoffChoice,
    idempotencyKey: string,
    actor: SchedulerActor
  ): Promise<SchedulerProjection> {
    return await this.serialized(async () => {
      // This path already owns a runtime-activity lease. It must finish an
      // in-flight automatic handoff when close begins, while still refusing
      // historical handles without reopening public mutation authority.
      const handle = this.requireMutableWithinActivity(runId);
      const projection = handle.runtime.projection();
      if (projection.projectHandoff?.status === "selected") {
        if (projection.projectHandoff.choice !== choice) {
          throw new Error(
            `Final project handoff already selected ${projection.projectHandoff.choice}.`
          );
        }
        await this.tryCleanupSettledRun(runId, handle);
        return projection;
      }
      if (projection.projectHandoff?.status !== "requested") {
        throw new Error("Final project handoff is not awaiting user selection.");
      }
      // C2b (N1): the manager pre-check IS the kernel acceptance -- the one
      // shared predicate, called here BEFORE the handle can mutate the
      // project and by the reducer when the selection is recorded. The
      // revision is the one the selection will carry: the current-stop
      // snapshot head when a snapshot was committed, else the canonical
      // integration revision. A snapshot that does not continue the chain
      // (probe G) is refused here, so the project is never mutated first
      // and refused after.
      assertProjectHandoffSelectionAccepted(
        projection,
        handoffSnapshotAtCurrentStop(projection)?.head ?? projection.integrationRevision,
      );
      const result = await handle.projectHandoff(choice);
      const selected = handle.runtime.selectProjectHandoff(
        choice,
        result,
        idempotencyKey,
        actor
      );
      await this.tryCleanupSettledRun(runId, handle);
      return selected;
    });
  }

  async close(): Promise<void> {
    if (this.closePromise) return await this.closePromise;
    this.closing = true;
    this.activityGateClosed = true;
    this.rejectActivityWaiters();
    const attempt = this.closeAfterPumps();
    this.closePromise = attempt;
    try {
      await attempt;
    } catch (error) {
      if (this.closePromise === attempt) this.closePromise = undefined;
      throw error;
    }
  }

  private async closeAfterPumps(): Promise<void> {
    await this.awaitIdle();
    if (this.liveCompaction) await this.liveCompaction;
    await this.waitForRuntimeActivityIdle();
    this.closed = true;
    await this.serialized(async () => {
      const failures: unknown[] = [];
      for (const [runId, handle] of [...this.handles.entries()]) {
        if (await this.closeHandle(runId, handle, failures)) {
          this.handles.delete(runId);
          this.handleShutdown.delete(runId);
        }
      }
      if (!this.specsClosed) {
        try {
          this.options.specs.close();
          this.specsClosed = true;
        } catch (error) {
          failures.push(error);
        }
      }
      if (failures.length > 0) {
        throw new AggregateError(failures, "Could not close native Build resources.");
      }
    });
  }

  private async closeHandle(
    runId: string,
    handle: NativeBuildRuntimeHandle,
    failures: unknown[],
  ): Promise<boolean> {
    const shutdown = this.handleShutdown.get(runId) ?? { phase: "status_pending" };
    this.handleShutdown.set(runId, shutdown);
    if (shutdown.phase === "status_pending") {
      try {
        shutdown.phase = !handle.historical && handle.runtime.projection().status === "completed"
          ? "settled_cleanup_pending"
          : "ready_for_teardown";
      } catch (error) {
        failures.push(error);
        shutdown.phase = "ready_for_teardown";
      }
    }
    if (shutdown.phase === "settled_cleanup_pending") {
      try {
        await this.cleanupSettledRun(runId, handle);
        shutdown.phase = "ready_for_teardown";
      } catch (error) {
        failures.push(error);
        return false;
      }
    }
    if (shutdown.phase === "ready_for_teardown") {
      shutdown.phase = "teardown_started";
    }
    try {
      await handle.close();
      return true;
    } catch (error) {
      failures.push(error);
      return false;
    }
  }

  private async ensureRuntime(spec: NativeBuildSpec): Promise<NativeBuildRuntimeHandle> {
    this.assertOpen();
    const existing = this.handles.get(spec.runId);
    if (existing) return existing;
    const handle = await this.options.createRuntime(spec);
    if (handle.runtime.id !== spec.runId) {
      await handle.close();
      throw new Error(`Build runtime identity mismatch for ${spec.runId}.`);
    }
    this.handles.set(spec.runId, handle);
    return handle;
  }

  private async ensureHistoricalRuntime(
    spec: NativeBuildSpec,
  ): Promise<NativeBuildRuntimeHandle | undefined> {
    const existing = this.handles.get(spec.runId);
    if (existing) return existing;
    if (!this.options.createHistoricalRuntime) return undefined;
    const terminalState = await this.options.terminalStateForHistoricalSpec?.(spec);
    if (!isHistoricalTerminalState(terminalState)) {
      throw new Error(
        `Historical Build ${spec.runId} requires an authoritative terminal RunSupervisor state.`,
      );
    }
    const handle = await this.options.createHistoricalRuntime(spec, terminalState);
    if (handle.runtime.id !== spec.runId) {
      await handle.close();
      throw new Error(`Build runtime identity mismatch for ${spec.runId}.`);
    }
    this.handles.set(spec.runId, handle);
    return handle;
  }

  private async pump(
    runId: string,
    handle: NativeBuildRuntimeHandle
  ): Promise<void> {
    if (handle.historical) throw historicalReadOnlyError(runId);
    let releaseActivity: (() => void) | undefined;
    try {
      releaseActivity = await this.acquireRuntimeActivity();
    } catch (error) {
      if (this.closing) return;
      throw error;
    }
    let compaction: Promise<void> | undefined;
    try {
      let result = await handle.runtime.runUntilBlocked();
      for (;;) {
        if (
          result.status === "paused" &&
          result.action === "context_recording_failed"
        ) {
          const decision = await handle.runtime.resolveContextRecordingFailure();
          const projection = handle.runtime.projection();
          if (decision === "aborted" || projection.status === "failed") {
            this.options.onBuildFailed?.(
              runId,
              projection.failureReason ?? "context_recording_aborted",
            );
            result = { status: "failed", action: "context_recording_aborted" };
            break;
          }
          if (decision === "resumed" && projection.status === "running") {
            await eventLoopYield();
            result = await handle.runtime.runUntilBlocked();
            continue;
          }
          if (
            projection.status !== "paused" ||
            projection.pauseReason?.reason !== "context_recording_failed"
          ) {
            result = buildStepResultForProjection(projection);
          }
          break;
        }
        if (
          result.status === "progressed" &&
          handle.runtime.projection().status === "running"
        ) {
          await eventLoopYield();
          result = await handle.runtime.runUntilBlocked();
          continue;
        }
        break;
      }
      if (result.status === "idle") {
        const projection = handle.runtime.projection();
        if (projection.status === "running") {
          handle.runtime.pause(
            "no_mechanical_progress",
            `autonomous-idle:${projection.lastSequence}`
          );
          await handle.finalVerificationCleanup?.quiesceRun();
        }
        result = { status: "paused", action: "no_mechanical_progress" };
        // C3a repair cycle 1 (B-1): snapshot the pump's own pause. No
        // step is in flight (runUntilBlocked returned); never throws.
        await handle.runtime.commitStopSnapshotIfStopped?.();
      }
      if (
        result.status === "blocked" &&
        result.action !== "user_guidance_interruption_pending"
      ) {
        await handle.finalVerificationCleanup?.quiesceRun();
      }
      const finalized = await this.finalizeExecutionInsideActivity(
        runId,
        handle,
        result
      );
      result = finalized.result;
      compaction = finalized.compaction;
      // C3a repair cycle 1 (B-1): snapshot any stop the steps left
      // behind -- the recording-abort failure resolves in the pump, not
      // in a step. Runs after finalization; never throws.
      await handle.runtime.commitStopSnapshotIfStopped?.();
      this.options.onPumpResult?.(runId, result);
    } catch (error) {
      const projection = handle.runtime.projection();
      if (projection.status === "running") {
        // The bare reason left the owner (and the UI) with no idea what failed (tunnel run).
        handle.runtime.pause(
          "autonomous_pump_error",
          `autonomous-error:${projection.lastSequence}`,
          pumpErrorDetail(error)
        );
      }
      let reported = error;
      try { await handle.finalVerificationCleanup?.quiesceRun(); }
      catch (quiesceError) {
        reported = new AggregateError([error, quiesceError], `Build ${runId} failed and could not quiesce owned resources.`);
      }
      // C3a repair cycle 1 (B-1): snapshot the pump-error pause (or the
      // step stop, when the pause never recorded). Never throws.
      await handle.runtime.commitStopSnapshotIfStopped?.();
      this.options.onPumpError?.(runId, reported);
      this.options.onPumpResult?.(runId, {
        status: "paused",
        action: "autonomous_pump_error",
      });
    } finally {
      releaseActivity();
      if (compaction) await compaction;
    }
  }

  private wake(runId: string): void {
    const active = this.pumps.get(runId);
    if (!active) {
      this.activate(runId);
      return;
    }
    void active.finally(() => this.activate(runId)).catch(() => undefined);
  }

  private async executeWithFinalization(
    runId: string,
    handle: NativeBuildRuntimeHandle,
    execute: () => Promise<BuildStepResult>
  ): Promise<BuildStepResult> {
    const releaseActivity = await this.acquireRuntimeActivity();
    let result!: BuildStepResult;
    let compaction: Promise<void> | undefined;
    try {
      const finalized = await this.finalizeExecutionInsideActivity(
        runId,
        handle,
        await execute()
      );
      if (finalized.result.status === "paused" || finalized.result.status === "blocked") {
        await handle.finalVerificationCleanup?.quiesceRun();
      }
      result = finalized.result;
      compaction = finalized.compaction;
    } catch (error) {
      try { await handle.finalVerificationCleanup?.quiesceRun(); }
      catch (quiesceError) {
        throw new AggregateError(
          [error, quiesceError],
          `Build ${runId} failed and could not quiesce owned resources.`,
        );
      }
      throw error;
    } finally {
      releaseActivity();
      if (compaction) await compaction;
    }
    return result;
  }

  private async finalizeExecutionInsideActivity(
    runId: string,
    handle: NativeBuildRuntimeHandle,
    result: BuildStepResult
  ): Promise<{ result: BuildStepResult; compaction?: Promise<void> }> {
    const projection = handle.runtime.projection();
    if (
      projection.projectHandoff?.status === "requested" &&
      (projection.runPolicy === "finish" || projection.runPolicy === "budgeted") &&
      // A build completed with known defects waits for the owner instead of applying itself.
      !projection.projectHandoff.knownDefects?.length
    ) {
      if (this.settledRuns.has(runId)) {
        return {
          result: {
            status: "completed",
            action: "automatic_project_handoff_applied",
          },
        };
      }
      const compaction = this.requestLiveCompaction();
      try {
        await this.selectProjectHandoffInsideActivity(
          runId,
          "apply_to_project",
          "automatic-project-handoff",
          { role: "runner", id: "native-build-manager" }
        );
        return {
          result: {
            status: "completed",
            action: "automatic_project_handoff_applied",
          },
          compaction,
        };
      } catch (error) {
        this.options.onPumpError?.(runId, error);
        return {
          result: {
            status: "paused",
            action: "automatic_project_handoff_failed",
          },
          compaction,
        };
      }
    }
    if (projection.status === "completed") {
      if (this.settledRuns.has(runId)) return { result };
      const compaction = this.requestLiveCompaction();
      try {
        await this.cleanupSettledRun(runId, handle);
      } catch (error) {
        this.options.onPumpError?.(runId, error);
      }
      return { result: { status: "completed", action: result.action }, compaction };
    }
    return { result };
  }

  private requestLiveCompaction(): Promise<void> {
    if (!this.options.runArtifactCompaction || !this.options.prepareArtifactCleanup) {
      return Promise.resolve();
    }
    if (this.liveCompaction) return this.liveCompaction;

    // Close synchronously while the settling caller still holds its lease.
    // It can queue tombstones, release itself, and only then can this scan run.
    this.activityGateClosed = true;
    const slot: { generation?: Promise<void> } = {};
    const generation = (async () => {
      await this.waitForRuntimeActivityIdle();
      try {
        await this.options.runArtifactCompaction!(async () => {
          await this.compactEligibleRuns();
          if (!this.eligibleRunsAwaitArtifactCleanup()) return;
          await this.options.prepareArtifactCleanup!();
          await this.compactEligibleRuns();
        });
      } catch (error) {
        this.options.onPumpError?.("live-artifact-reachability", error);
      } finally {
        if (this.liveCompaction === slot.generation) this.liveCompaction = undefined;
        this.openRuntimeActivityGate();
      }
    })();
    slot.generation = generation;
    this.liveCompaction = generation;
    return generation;
  }

  private async withRuntimeActivity<T>(operation: () => Promise<T>): Promise<T> {
    const release = await this.acquireRuntimeActivity();
    try {
      return await operation();
    } finally {
      release();
    }
  }

  private acquireRuntimeActivity(): Promise<() => void> {
    this.assertOpen();
    if (!this.activityGateClosed) {
      this.activeRuntimeOperations += 1;
      return Promise.resolve(this.runtimeActivityRelease());
    }
    return new Promise((resolve, reject) => {
      this.activityWaiters.push({ resolve, reject });
    });
  }

  private runtimeActivityRelease(): () => void {
    let released = false;
    return () => {
      if (released) return;
      released = true;
      this.activeRuntimeOperations -= 1;
      if (this.activeRuntimeOperations === 0) {
        for (const resolve of this.activityIdleWaiters.splice(0)) resolve();
      }
    };
  }

  private waitForRuntimeActivityIdle(): Promise<void> {
    if (this.activeRuntimeOperations === 0) return Promise.resolve();
    return new Promise((resolve) => {
      this.activityIdleWaiters.push(resolve);
    });
  }

  private openRuntimeActivityGate(): void {
    if (this.closing) {
      this.activityGateClosed = true;
      this.rejectActivityWaiters();
      return;
    }
    this.activityGateClosed = false;
    for (const { resolve } of this.activityWaiters.splice(0)) {
      this.activeRuntimeOperations += 1;
      resolve(this.runtimeActivityRelease());
    }
  }

  private rejectActivityWaiters(): void {
    const error = new Error("Native Build manager is closing.");
    for (const { reject } of this.activityWaiters.splice(0)) reject(error);
  }

  private async cleanupSettledRun(
    runId: string,
    handle: NativeBuildRuntimeHandle
  ): Promise<void> {
    if (this.settledRuns.has(runId)) return;
    await handle.cleanup();
    this.settledRuns.add(runId);
  }

  private async compactRuns(
    runs: Array<[string, NativeBuildRuntimeHandle]>
  ): Promise<void> {
    for (const [runId, handle] of runs) {
      try {
        await handle.compact();
      } catch (error) {
        this.options.onPumpError?.(runId, error);
      }
    }
  }

  private async compactEligibleRuns(): Promise<void> {
    await this.compactRuns(this.compactionEligibleRuns());
  }

  private compactionEligibleRuns(): Array<[string, NativeBuildRuntimeHandle]> {
    return [...this.handles.entries()].filter(
      ([, handle]) => !handle.historical && handle.runtime.projection().status !== "running"
    );
  }

  /**
   * The reachability index walks the whole state directory and every reachable artifact: about 70s
   * of a 110s tunnel-run startup, rebuilt on every start though no artifact was waiting on it. Build
   * it only when compaction left one.
   */
  private eligibleRunsAwaitArtifactCleanup(): boolean {
    return this.compactionEligibleRuns().some(([runId, handle]) => {
      try {
        return handle.hasPendingArtifactCleanup?.() ?? true;
      } catch (error) {
        this.options.onPumpError?.(runId, error);
        return true;
      }
    });
  }

  /**
   * Settling a live run closes its stores and execution host, but the handle stayed registered:
   * observability then failed with "database is not open" and files with "ExecutionHost run binding
   * is closed", so the UI could not load a finished Build until the runner restarted (tunnel run).
   * Once the supervisor records the run as terminal, reads go through the historical reader a
   * restart would open, and the closed live handle is released.
   */
  private async retireSettledRuntime(runId: string): Promise<void> {
    const retirable = (handle: NativeBuildRuntimeHandle | undefined): handle is NativeBuildRuntimeHandle =>
      handle !== undefined && !handle.historical && this.settledRuns.has(runId) && !this.pumps.has(runId);
    if (!retirable(this.handles.get(runId)) || !this.options.createHistoricalRuntime) return;
    await this.serialized(async () => {
      const live = this.handles.get(runId);
      if (this.closing || !retirable(live)) return;
      const terminalState = await this.options.terminalStateForHistoricalSpec?.(
        this.options.specs.get(runId),
      );
      if (!isHistoricalTerminalState(terminalState)) return;
      const historical = await this.options.createHistoricalRuntime!(
        this.options.specs.get(runId),
        terminalState,
      );
      if (historical.runtime.id !== runId) {
        await historical.close();
        throw new Error(`Build runtime identity mismatch for ${runId}.`);
      }
      this.handles.set(runId, historical);
      try {
        await live.close();
      } catch (error) {
        this.options.onPumpError?.(runId, error);
      }
    });
  }

  private async tryCleanupSettledRun(
    runId: string,
    handle: NativeBuildRuntimeHandle
  ): Promise<void> {
    try {
      await this.cleanupSettledRun(runId, handle);
    } catch (error) {
      this.options.onPumpError?.(runId, error);
    }
  }

  private require(runId: string): NativeBuildRuntimeHandle {
    this.assertOpen();
    const handle = this.handles.get(runId);
    if (!handle) throw new Error(`Unknown build runtime ${runId}.`);
    return handle;
  }

  private requireRecovery(runId: string): ProcessRecoveryCoordinator {
    const handle = this.requireMutable(runId);
    if (!handle.processRecovery) throw new Error(`Exceptional recovery unavailable for build ${runId}.`);
    return handle.processRecovery;
  }

  private requireMutable(runId: string): NativeBuildRuntimeHandle {
    const handle = this.require(runId);
    if (handle.historical) throw historicalReadOnlyError(runId);
    return handle;
  }

  private requireMutableWithinActivity(runId: string): NativeBuildRuntimeHandle {
    const handle = this.handles.get(runId);
    if (!handle) throw new Error(`Unknown build runtime ${runId}.`);
    if (handle.historical) throw historicalReadOnlyError(runId);
    return handle;
  }

  private assertOpen(): void {
    if (this.closed || this.closing) throw new Error("Native Build manager is closed.");
  }

  private async serialized<T>(operation: () => Promise<T>): Promise<T> {
    const previous = this.operationQueue;
    let release!: () => void;
    this.operationQueue = new Promise<void>((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await operation();
    } finally {
      release();
    }
  }
}

function historicalReadOnlyError(runId: string): Error {
  return new Error(`Historical Build ${runId} is read-only.`);
}

function isHistoricalTerminalState(value: unknown): value is HistoricalTerminalState {
  return value === "completed" || value === "failed" || value === "stopped";
}

function eventLoopYield(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

/** One line naming what failed, kept short enough to show in a pause banner. */
export function pumpErrorDetail(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const line = message.split(/\r?\n/, 1)[0]!.trim() || "unknown error";
  return line.length > 400 ? `${line.slice(0, 399)}…` : line;
}
