import { languageInvocation } from "./language-intelligence.js";
import { createHash } from "node:crypto";
import { fencedWrite, fencedPatch, fencedMove, fencedDelete, filesystemMutationFailure,
  FilesystemMutationError, isFilesystemMutation } from "./filesystem-mutation-fence.js";
import { lstat, readFile, readdir } from "node:fs/promises";
import { relative, resolve, sep } from "node:path";

import type { ArtifactStore } from "./artifact-store.js";
import type {
  NativeTool,
  ToolExecutionContext,
  ToolExecutionOutput,
  ValidationResult,
} from "./agent-contracts.js";
import type { LanguageIntelligenceProvider } from "./language-intelligence.js";
import type {
  RepositoryEntry,
  RepositoryIntelligence,
} from "./repository-intelligence.js";

export interface FilesystemToolsOptions {
  artifacts?: ArtifactStore;
  repository?: RepositoryIntelligence;
  diagnostics?: Pick<LanguageIntelligenceProvider, "diagnostics">;
  maxReadBytes?: number;
  maxEntries?: number;
  maxSearchMatches?: number;
  hiddenPaths?: readonly string[];
  protectedPaths?: readonly string[];
}

type Input = Record<string, unknown>;
const MAX_READ_LINES = 500;
const MAX_READ_RANGE_BYTES = 6 * 1024;
const MAX_PATCH_EDITS = 50;

export function createFilesystemTools(
  options: FilesystemToolsOptions = {}
): NativeTool<unknown>[] {
  const maxReadBytes = options.maxReadBytes ?? 1024 * 1024;
  const maxEntries = options.maxEntries ?? 5_000;
  const maxSearchMatches = options.maxSearchMatches ?? 500;
  let mutationQueue = Promise.resolve();
  const mutate = async <T>(operation: () => Promise<T>): Promise<T> => {
    const previous = mutationQueue;
    let release!: () => void;
    mutationQueue = new Promise<void>((resolveQueue) => {
      release = resolveQueue;
    });
    await previous;
    try {
      return await operation();
    } finally {
      release();
    }
  };

  const tools: NativeTool<Input>[] = [
    {
      definition: definition(
        "fs.read",
        `Read a file with revision metadata. For large text files, request a targeted 1-based inclusive line range with startLine and endLine. Each ranged read is limited to ${MAX_READ_LINES} lines and ${MAX_READ_RANGE_BYTES} bytes; oversized multi-line ranges return the largest bounded prefix plus nextStartLine instead of failing.`,
        true,
        "none"
      ),
      validate: validateRead,
      assessAccess: (input) => pathAccess(input, "read"),
      execute: async (input, context) => {
        const path = toolPath(context, input.path as string);
        if (matchesPolicyPath(context, path, options.hiddenPaths)) {
          return hiddenPathError(context, path);
        }
        const bytes = await readFile(path);
        const hash = sha256(bytes);
        const baseMetadata = {
          path: displayPath(context, path),
          sha256: hash,
          byteLength: bytes.byteLength,
        };
        if (input.startLine !== undefined && isUtf8Text(bytes)) {
          const source = decodeText(bytes);
          const starts = lineStarts(source);
          const startLine = input.startLine as number;
          const requestedEndLine = input.endLine as number;
          if (startLine > starts.length) {
            return error(
              "invalid_line_range",
              `startLine ${startLine} exceeds the file's ${starts.length} lines.`
            );
          }
          let endLine = Math.min(requestedEndLine, starts.length);
          const startOffset = starts[startLine - 1];
          let endOffset = endLine < starts.length ? starts[endLine] : source.length;
          let selected = source.slice(startOffset, endOffset);
          let selectedBytes = Buffer.byteLength(selected);
          if (selectedBytes > MAX_READ_RANGE_BYTES) {
            const firstLineEndOffset = startLine < starts.length
              ? starts[startLine]
              : source.length;
            const firstLineBytes = Buffer.byteLength(
              source.slice(startOffset, firstLineEndOffset)
            );
            if (firstLineBytes > MAX_READ_RANGE_BYTES) {
              return error(
                "line_range_too_large",
                `Line ${startLine} contains ${firstLineBytes} bytes and cannot fit within the ${MAX_READ_RANGE_BYTES}-byte range limit; it is not possible to narrow the range further for this single line.`
              );
            }

            let low = startLine;
            let high = endLine;
            let bestEndLine = startLine;
            while (low <= high) {
              const candidate = Math.floor((low + high) / 2);
              const candidateEndOffset = candidate < starts.length
                ? starts[candidate]
                : source.length;
              const candidateBytes = Buffer.byteLength(
                source.slice(startOffset, candidateEndOffset)
              );
              if (candidateBytes <= MAX_READ_RANGE_BYTES) {
                bestEndLine = candidate;
                low = candidate + 1;
              } else {
                high = candidate - 1;
              }
            }
            endLine = bestEndLine;
            endOffset = endLine < starts.length ? starts[endLine] : source.length;
            selected = source.slice(startOffset, endOffset);
            selectedBytes = Buffer.byteLength(selected);
          }
          const rangeWasClipped = endLine < Math.min(requestedEndLine, starts.length);
          return {
            content: [
              json({
                ...baseMetadata,
                totalLines: starts.length,
                startLine,
                endLine,
                truncated: startLine > 1 || endLine < starts.length,
                ...(rangeWasClipped
                  ? {
                      requestedEndLine,
                      nextStartLine: endLine + 1,
                      rangeByteLength: selectedBytes,
                    }
                  : {}),
              }),
              { type: "text", text: selected },
            ],
            isError: false,
          };
        }
        const metadata = json(baseMetadata);
        if (bytes.byteLength > maxReadBytes || !isUtf8Text(bytes)) {
          if (!options.artifacts) {
            return error("artifact_store_required", "Binary or large file requires artifact storage.");
          }
          const artifact = await options.artifacts.put(
            bytes,
            isUtf8Text(bytes) ? "text/plain" : "application/octet-stream",
            displayPath(context, path)
          );
          return {
            content: [
              metadata,
              {
                type: "artifact",
                hash: artifact.hash,
                mediaType: artifact.mediaType,
                label: artifact.label,
              },
            ],
            isError: false,
          };
        }
        return {
          content: [metadata, { type: "text", text: decodeText(bytes) }],
          isError: false,
        };
      },
    },
    {
      definition: definition("fs.stat", "Inspect file metadata", true, "none"),
      validate: objectWithString("path"),
      assessAccess: (input) => pathAccess(input, "read"),
      execute: async (input, context) => {
        const path = toolPath(context, input.path as string);
        if (matchesPolicyPath(context, path, options.hiddenPaths)) {
          return hiddenPathError(context, path);
        }
        const details = await lstat(path);
        return {
          content: [
            json({
              path: displayPath(context, path),
              type: details.isFile()
                ? "file"
                : details.isDirectory()
                  ? "directory"
                  : details.isSymbolicLink()
                    ? "symlink"
                    : "other",
              byteLength: details.size,
              modifiedAt: details.mtime.toISOString(),
            }),
          ],
          isError: false,
        };
      },
    },
    {
      definition: definition("fs.list", "List workspace files", true, "none"),
      validate: objectWithString("path"),
      assessAccess: (input) => pathAccess(input, "read"),
      execute: async (input, context) => {
        const root = toolPath(context, input.path as string);
        const depth = integer(input.maxDepth, 1, 0, 20);
        const entries: Array<{ path: string; type: string }> = [];
        if (options.repository && context.workspacePath) {
          const snapshot = await options.repository.snapshot(
            context.workspacePath,
            { maxEntries: Math.min(20_000, maxEntries) },
            context.signal,
          );
          entries.push(...repositoryListEntries(
            snapshot.entries,
            context.workspacePath,
            root,
            depth,
            maxEntries,
          ));
        } else {
          await walk(root, depth, async (path, type) => {
            if (entries.length >= maxEntries) return false;
            entries.push({ path: displayPath(context, path), type });
            return true;
          }, context.signal);
        }
        const visibleEntries = entries.filter(
          (entry) => !matchesNormalizedPolicyPath(entry.path, options.hiddenPaths)
        );
        visibleEntries.sort((left, right) => left.path.localeCompare(right.path));
        return { content: [json({ entries: visibleEntries, truncated: entries.length >= maxEntries })], isError: false };
      },
    },
    {
      definition: definition("fs.search", "Search text files", true, "none"),
      validate: objectWithStrings("path", "pattern"),
      assessAccess: (input) => pathAccess(input, "read"),
      execute: async (input, context) => {
        const root = toolPath(context, input.path as string);
        const limit = integer(
          input.maxMatches,
          Math.min(100, maxSearchMatches),
          1,
          maxSearchMatches
        );
        let expression: RegExp;
        try {
          const source = input.regex === true
            ? (input.pattern as string)
            : escapeRegExp(input.pattern as string);
          expression = new RegExp(source, input.caseSensitive === true ? "g" : "gi");
        } catch (cause) {
          return error("invalid_pattern", cause instanceof Error ? cause.message : "Invalid pattern.");
        }
        const matches: Array<{ path: string; line: number; column: number; text: string }> = [];
        const searchFile = async (path: string): Promise<boolean> => {
          if (matches.length >= limit) return false;
          if (matchesPolicyPath(context, path, options.hiddenPaths)) return true;
          const bytes = await readFile(path);
          if (!isUtf8Text(bytes)) return true;
          const lines = decodeText(bytes).split(/\r?\n/);
          for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
            expression.lastIndex = 0;
            let match: RegExpExecArray | null;
            while ((match = expression.exec(lines[lineIndex])) !== null) {
              matches.push({
                path: displayPath(context, path),
                line: lineIndex + 1,
                column: match.index + 1,
                text: lines[lineIndex],
              });
              if (matches.length >= limit) break;
              if (match[0].length === 0) expression.lastIndex += 1;
            }
            if (matches.length >= limit) break;
          }
          return matches.length < limit;
        };
        const rootDetails = await lstat(root);
        if (rootDetails.isFile()) {
          await searchFile(root);
        } else if (rootDetails.isDirectory()) {
          if (options.repository && context.workspacePath) {
            const snapshot = await options.repository.snapshot(
              context.workspacePath,
              {
                includeIgnored: input.includeIgnored === true,
                maxEntries: 20_000,
              },
              context.signal,
            );
            for (const entry of snapshot.entries) {
              if (matches.length >= limit) break;
              if (!entryIsSearchable(entry, input)) continue;
              const path = resolve(context.workspacePath, entry.path);
              if (!isWithin(root, path)) continue;
              await searchFile(path);
            }
          } else {
            await walk(root, 50, async (path, type) =>
              type === "file" ? await searchFile(path) : matches.length < limit,
            context.signal);
          }
        } else {
          return error("invalid_search_path", "Search path must be a file or directory.");
        }
        return {
          content: [json({ matches, truncated: matches.length >= limit })],
          isError: false,
        };
      },
    },
    {
      definition: definition("fs.write", "Atomically create a new text file only if absent, or replace existing text using the SHA-256 from a prior read/inspection. Replacement without expectedSha256 is refused.", false, "workspace"),
      validate: objectWithStrings("path", "content"),
      assessAccess: (input) => pathAccess(input, "write"),
      execute: async (input, context) =>
        await mutate(async () => {
          const path = toolPath(context, input.path as string);
          if (matchesPolicyPath(context, path, options.protectedPaths)) {
            return protectedPathError(context, path);
          }
          const bytes = fencedWrite(context, path, Buffer.from(input.content as string),
            input.expectedSha256, input.createDirectories === true);
          return await successRevision(context, path, bytes, options.diagnostics);
        }),
    },
    {
      definition: definition(
        "fs.patch",
        "Apply one or many exact replacements atomically to one file. Multiline edits tolerate LF/CRLF differences and preserve the file's newline style. Prefer the edits array when changing multiple regions; issue only one fs.patch per file per model turn. Every edit is validated before the file is written.",
        false,
        "workspace",
      ),
      validate: validatePatch,
      assessAccess: (input) => pathAccess(input, "write"),
      execute: async (input, context) =>
        await mutate(async () => {
          const path = toolPath(context, input.path as string);
          if (matchesPolicyPath(context, path, options.protectedPaths)) {
            return protectedPathError(context, path);
          }
          const next = fencedPatch(context, path, input.expectedSha256, (bytes) => {
            const original = decodeText(bytes);
            let nextText = original;
            const edits = patchEdits(input);
            for (const [index, edit] of edits.entries()) {
              const newline = preferredNewline(nextText);
              const exactCount = occurrences(nextText, edit.search);
              const adaptedSearch = newline
                ? normalizeNewlines(edit.search, newline)
                : edit.search;
              const search = exactCount === 0 && adaptedSearch !== edit.search
                ? adaptedSearch
                : edit.search;
              const count = exactCount === 0
                ? occurrences(nextText, search)
                : exactCount;
              if (count !== 1) {
                throw new FilesystemMutationError(
                  "ambiguous_patch",
                  `Edit ${index + 1}: expected one match, found ${count}. No changes were written.`,
                );
              }
              const replacement = newline
                ? normalizeNewlines(edit.replace, newline)
                : edit.replace;
              nextText = nextText.replace(search, replacement);
            }
            return Buffer.from(nextText);
          });
          return await successRevision(context, path, next, options.diagnostics);
        }),
    },
    {
      definition: definition("fs.move", "Move a file or directory", false, "workspace"),
      validate: objectWithStrings("source", "destination"),
      assessAccess: (input) => ({
        capability: "filesystem.move",
        paths: [
          { path: input.source as string, access: "delete" },
          { path: input.destination as string, access: "write" },
        ],
      }),
      execute: async (input, context) =>
        await mutate(async () => {
          const source = toolPath(context, input.source as string);
          const destination = toolPath(context, input.destination as string);
          if (matchesPolicyPath(context, source, options.protectedPaths)) {
            return protectedPathError(context, source);
          }
          if (matchesPolicyPath(context, destination, options.protectedPaths)) {
            return protectedPathError(context, destination);
          }
          fencedMove(context, source, destination, input.createDirectories === true);
          return {
            content: [json({ source: displayPath(context, source), destination: displayPath(context, destination) })],
            isError: false,
          };
        }),
    },
    {
      definition: definition("fs.delete", "Delete a file or explicitly recursive directory", false, "workspace"),
      validate: objectWithString("path"),
      assessAccess: (input) => ({
        capability: "filesystem.delete",
        destructive: true,
        paths: [{ path: input.path as string, access: "delete" }],
      }),
      execute: async (input, context) =>
        await mutate(async () => {
          const path = toolPath(context, input.path as string);
          if (matchesPolicyPath(context, path, options.protectedPaths)) {
            return protectedPathError(context, path);
          }
          fencedDelete(context, path, input.recursive === true);
          return { content: [json({ path: displayPath(context, path), deleted: true })], isError: false };
        }),
    },
  ];
  return tools.map((tool) => !isFilesystemMutation(tool.definition.name) ? tool : {
    ...tool,
    execute: async (input: Input, context: ToolExecutionContext) => {
      try { return await tool.execute(input, context); }
      catch (error) {
        const refusal = filesystemMutationFailure(error, context.workspacePath ?? "");
        if (refusal) return refusal;
        throw error;
      }
    },
  }) as NativeTool<unknown>[];
}

function definition(
  name: string,
  description: string,
  readOnly: boolean,
  effect: "none" | "workspace"
) {
  return { name, description, inputSchema: filesystemSchema(name), readOnly, effect } as const;
}

function filesystemSchema(name: string): Record<string, unknown> {
  const path = { type: "string", minLength: 1 };
  const sha = { type: "string", pattern: "^[a-f0-9]{64}$" };
  switch (name) {
    case "fs.read":
      return objectSchema(
        {
          path,
          startLine: { type: "integer", minimum: 1 },
          endLine: { type: "integer", minimum: 1 },
        },
        ["path"]
      );
    case "fs.stat":
      return objectSchema({ path }, ["path"]);
    case "fs.list":
      return objectSchema(
        { path, maxDepth: { type: "integer", minimum: 0, maximum: 20 } },
        ["path"]
      );
    case "fs.search":
      return objectSchema(
        {
          path,
          pattern: { type: "string" },
          regex: { type: "boolean" },
          caseSensitive: { type: "boolean" },
          includeGenerated: { type: "boolean" },
          includeVendored: { type: "boolean" },
          includeIgnored: { type: "boolean" },
          includeBinary: { type: "boolean" },
          maxMatches: { type: "integer", minimum: 1 },
        },
        ["path", "pattern"]
      );
    case "fs.write":
      return objectSchema(
        {
          path,
          content: { type: "string" },
          expectedSha256: sha,
          createDirectories: { type: "boolean" },
        },
        ["path", "content"]
      );
    case "fs.patch":
      return objectSchema(
        {
          path,
          search: { type: "string", minLength: 1 },
          replace: { type: "string" },
          edits: {
            type: "array",
            minItems: 1,
            maxItems: MAX_PATCH_EDITS,
            items: objectSchema(
              {
                search: { type: "string", minLength: 1 },
                replace: { type: "string" },
              },
              ["search", "replace"],
            ),
          },
          expectedSha256: sha,
        },
        ["path", "expectedSha256"],
      );
    case "fs.move":
      return objectSchema(
        {
          source: path,
          destination: path,
          createDirectories: { type: "boolean" },
        },
        ["source", "destination"]
      );
    case "fs.delete":
      return objectSchema(
        { path, recursive: { type: "boolean" } },
        ["path"]
      );
    default:
      throw new Error(`Unknown filesystem tool ${name}.`);
  }
}

function repositoryListEntries(
  repositoryEntries: RepositoryEntry[],
  workspaceRoot: string,
  requestedRoot: string,
  maxDepth: number,
  maxEntries: number,
): Array<{ path: string; type: string }> {
  const paths = new Map<string, string>();
  for (const entry of repositoryEntries) {
    const absolutePath = resolve(workspaceRoot, entry.path);
    if (!isWithin(requestedRoot, absolutePath)) continue;
    const relation = relative(requestedRoot, absolutePath);
    const segments = relation.split(sep).filter(Boolean);
    if (segments.length === 0) continue;
    const maximumSegments = Math.min(segments.length, maxDepth + 1);
    for (let count = 1; count <= maximumSegments; count += 1) {
      const path = resolve(requestedRoot, ...segments.slice(0, count));
      const type = count === segments.length ? "file" : "directory";
      paths.set(path, type);
      if (paths.size >= maxEntries) break;
    }
    if (paths.size >= maxEntries) break;
  }
  return [...paths.entries()].map(([path, type]) => ({
    path: normalizeDisplayPath(workspaceRoot, path),
    type,
  }));
}

function entryIsSearchable(entry: RepositoryEntry, input: Input): boolean {
  if (entry.gitState === "ignored" && input.includeIgnored !== true) return false;
  if (entry.kind === "generated" && input.includeGenerated !== true) return false;
  if (entry.kind === "vendored" && input.includeVendored !== true) return false;
  if (entry.kind === "binary" && input.includeBinary !== true) return false;
  return true;
}

function isWithin(root: string, path: string): boolean {
  const relation = relative(root, path);
  return relation === "" || (relation !== ".." && !relation.startsWith(`..${sep}`));
}

function normalizeDisplayPath(root: string, path: string): string {
  const value = relative(root, path);
  return (value || ".").split(sep).join("/");
}

function objectSchema(
  properties: Record<string, unknown>,
  required: string[]
): Record<string, unknown> {
  return { type: "object", properties, required, additionalProperties: false };
}

function objectWithString(key: string) {
  return (input: unknown): ValidationResult<Input> =>
    isObject(input) && typeof input[key] === "string"
      ? { ok: true, value: input }
      : { ok: false, issues: [`${key} must be a string`] };
}

function validateRead(input: unknown): ValidationResult<Input> {
  if (!isObject(input) || typeof input.path !== "string") {
    return { ok: false, issues: ["path must be a string"] };
  }
  const hasStart = input.startLine !== undefined;
  const hasEnd = input.endLine !== undefined;
  if (hasStart !== hasEnd) {
    return {
      ok: false,
      issues: ["startLine and endLine must be provided together"],
    };
  }
  if (!hasStart) return { ok: true, value: input };
  if (
    !Number.isSafeInteger(input.startLine) ||
    !Number.isSafeInteger(input.endLine) ||
    (input.startLine as number) < 1 ||
    (input.endLine as number) < (input.startLine as number)
  ) {
    return {
      ok: false,
      issues: ["startLine and endLine must form a positive ascending range"],
    };
  }
  if ((input.endLine as number) - (input.startLine as number) + 1 > MAX_READ_LINES) {
    return {
      ok: false,
      issues: [`line ranges may contain at most ${MAX_READ_LINES} lines`],
    };
  }
  return { ok: true, value: input };
}

function validatePatch(input: unknown): ValidationResult<Input> {
  if (
    !isObject(input) ||
    typeof input.path !== "string"
  ) {
    return {
      ok: false,
      issues: ["path must be a string"],
    };
  }
  const hasLegacy = input.search !== undefined || input.replace !== undefined;
  const hasEdits = input.edits !== undefined;
  if (hasLegacy === hasEdits) {
    return {
      ok: false,
      issues: ["provide either search and replace, or edits, but not both"],
    };
  }
  if (hasLegacy) {
    return typeof input.search === "string" &&
      input.search.length > 0 &&
      typeof input.replace === "string"
      ? { ok: true, value: input }
      : {
          ok: false,
          issues: ["search must be a non-empty string and replace must be a string"],
        };
  }
  if (
    !Array.isArray(input.edits) ||
    input.edits.length === 0 ||
    input.edits.length > MAX_PATCH_EDITS
  ) {
    return {
      ok: false,
      issues: [`edits must contain between 1 and ${MAX_PATCH_EDITS} replacements`],
    };
  }
  for (const [index, edit] of input.edits.entries()) {
    if (
      !isObject(edit) ||
      typeof edit.search !== "string" ||
      edit.search.length === 0 ||
      typeof edit.replace !== "string"
    ) {
      return {
        ok: false,
        issues: [
          `edits[${index}] must contain a non-empty search string and a replace string`,
        ],
      };
    }
  }
  return { ok: true, value: input };
}

function patchEdits(input: Input): Array<{ search: string; replace: string }> {
  if (Array.isArray(input.edits)) {
    return input.edits.map((edit) => ({
      search: (edit as Input).search as string,
      replace: (edit as Input).replace as string,
    }));
  }
  return [{
    search: input.search as string,
    replace: input.replace as string,
  }];
}

function objectWithStrings(...keys: string[]) {
  return (input: unknown): ValidationResult<Input> =>
    isObject(input) && keys.every((key) => typeof input[key] === "string")
      ? { ok: true, value: input }
      : { ok: false, issues: keys.map((key) => `${key} must be a string`) };
}

function isObject(input: unknown): input is Input {
  return typeof input === "object" && input !== null && !Array.isArray(input);
}

function lineStarts(source: string): number[] {
  const starts = [0];
  const newline = /\r\n|\r|\n/g;
  while (newline.exec(source) !== null) starts.push(newline.lastIndex);
  return starts;
}

function pathAccess(input: Input, access: "read" | "write") {
  return {
    capability: `filesystem.${access}`,
    paths: [{ path: input.path as string, access }],
  };
}

function toolPath(context: ToolExecutionContext, path: string): string {
  if (!context.workspacePath) throw new Error("Filesystem tool requires a workspace.");
  return resolve(context.workspacePath, path);
}

function displayPath(context: ToolExecutionContext, path: string): string {
  const value = context.workspacePath ? relative(context.workspacePath, path) : path;
  return (value || ".").split(sep).join("/");
}

function normalizePolicyPath(path: string): string {
  return path.replaceAll("\\", "/").replace(/^\.\//, "").replace(/\/$/, "");
}

function matchesNormalizedPolicyPath(
  path: string,
  policyPaths: readonly string[] | undefined,
): boolean {
  const candidate = normalizePolicyPath(path);
  return (policyPaths ?? []).some((policyPath) => {
    const protectedPath = normalizePolicyPath(policyPath);
    if (!protectedPath.includes("/")) {
      return candidate.split("/").includes(protectedPath);
    }
    return candidate === protectedPath || candidate.startsWith(`${protectedPath}/`);
  });
}

function matchesPolicyPath(
  context: ToolExecutionContext,
  path: string,
  policyPaths: readonly string[] | undefined,
): boolean {
  return matchesNormalizedPolicyPath(displayPath(context, path), policyPaths);
}

function hiddenPathError(
  context: ToolExecutionContext,
  path: string,
): ToolExecutionOutput {
  return error(
    "benchmark_hidden_path",
    `benchmark_hidden_path: ${displayPath(context, path)} is unavailable to benchmark agents.`,
  );
}

function protectedPathError(
  context: ToolExecutionContext,
  path: string,
): ToolExecutionOutput {
  return error(
    "benchmark_protected_path",
    `benchmark_protected_path: ${displayPath(context, path)} cannot be modified by benchmark agents.`,
  );
}

async function walk(
  root: string,
  maxDepth: number,
  visit: (path: string, type: string) => Promise<boolean>,
  signal?: AbortSignal,
  depth = 0
): Promise<void> {
  if (signal?.aborted) throw new Error("Search cancelled.");
  const entries = await readdir(root, { withFileTypes: true });
  entries.sort((left, right) => left.name.localeCompare(right.name));
  for (const entry of entries) {
    if (entry.name === ".git" || entry.name === "node_modules") continue;
    const path = resolve(root, entry.name);
    const type = entry.isDirectory() ? "directory" : entry.isFile() ? "file" : entry.isSymbolicLink() ? "symlink" : "other";
    if (!(await visit(path, type))) return;
    if (entry.isDirectory() && depth < maxDepth) {
      await walk(path, maxDepth, visit, signal, depth + 1);
    }
  }
}

function isUtf8Text(bytes: Buffer): boolean {
  if (bytes.includes(0)) return false;
  try {
    new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    return true;
  } catch {
    return false;
  }
}

function decodeText(bytes: Buffer): string {
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}

function sha256(bytes: Buffer): string {
  return createHash("sha256").update(bytes).digest("hex");
}

function json(value: unknown) {
  return { type: "json" as const, value };
}

function error(code: string, message: string): ToolExecutionOutput {
  return { content: [{ type: "text", text: message }], isError: true, error: { code, message } };
}

async function successRevision(
  context: ToolExecutionContext,
  path: string,
  bytes: Buffer,
  diagnostics?: Pick<LanguageIntelligenceProvider, "diagnostics">,
): Promise<ToolExecutionOutput> {
  const metadata: Record<string, unknown> = {
    path: displayPath(context, path),
    sha256: sha256(bytes),
    byteLength: bytes.byteLength,
  };
  if (diagnostics && context.workspacePath) {
    try {
      const result = await diagnostics.diagnostics({
        root: context.workspacePath,
        path: displayPath(context, path),
      }, context.signal, languageInvocation(context));
      if (result.status === "unsupported_language") {
        metadata.diagnosticsSkipped = "unsupported_language";
      } else {
        metadata.diagnostics = {
          ...(result.projectConfig ? { projectConfig: result.projectConfig } : {}),
          results: result.results,
          truncated: result.truncated,
        };
      }
    } catch {
      metadata.diagnosticsUnavailable = "code_intelligence_failed";
    }
  }
  return {
    content: [json(metadata)],
    isError: false,
  };
}

function occurrences(value: string, search: string): number {
  let count = 0;
  let cursor = 0;
  while ((cursor = value.indexOf(search, cursor)) >= 0) {
    count += 1;
    cursor += search.length;
  }
  return count;
}

function preferredNewline(value: string): "\r\n" | "\n" | "\r" | null {
  if (value.includes("\r\n")) return "\r\n";
  if (value.includes("\n")) return "\n";
  if (value.includes("\r")) return "\r";
  return null;
}

function normalizeNewlines(value: string, newline: "\r\n" | "\n" | "\r"): string {
  return value.replace(/\r\n|\r|\n/g, newline);
}

function integer(
  value: unknown,
  fallback: number,
  minimum: number,
  maximum: number
): number {
  return Number.isInteger(value)
    ? Math.min(maximum, Math.max(minimum, value as number))
    : fallback;
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
