import type { RunGitExecutionContext } from "./git-run-context.js";
import { lstat, realpath } from "node:fs/promises";
import { authorizeFilesystemMutation, captureFilesystemMutation, filesystemMutationFailure,
  isFilesystemMutation, filesystemMutationWorkspace } from "./filesystem-mutation-fence.js";
import { basename, dirname, isAbsolute, relative, resolve } from "node:path";

import type { ArtifactStore } from "./artifact-store.js";
import {
  BudgetExceededError,
  type BudgetLedger,
} from "./budget-ledger.js";
import type {
  NativeTool,
  ToolAccessRequest,
  ToolCallBlock,
  ToolDefinition,
  ToolExecutionContext,
  ToolExecutionOutput,
  ToolResult,
} from "./agent-contracts.js";
import type { PermissionProfile } from "./contracts.js";
import {
  createExecutionGrantAuthority,
  type ExecutionGrantAuthority,
  type OpaqueExecutionGrant,
} from "./execution-grants.js";
import { PROTECTED_RUNNER_LIFECYCLE_TOOL_NAMES } from "./runner-extension.js";
import {
  ToolRegistry,
  type AgentToolRuntime,
} from "./tool-registry.js";
import {
  toolInvocationFingerprint,
  toolInvocationKey,
  type ToolInvocationLedger,
} from "./tool-ledger.js";

export interface ToolApprovalRequest {
  runId: string;
  sessionId: string;
  callId: string;
  toolName: string;
  extensionId?: string;
  actor: ToolExecutionContext["actor"];
  permissionProfile: PermissionProfile;
  access: ToolAccessRequest;
  outsideWorkspace: boolean;
  occurredAt: string;
}

export interface ToolAuditRecord {
  callId: string;
  toolName: string;
  extensionId?: string;
  runId: string;
  sessionId: string;
  actor: ToolExecutionContext["actor"];
  startedAt: string;
  finishedAt: string;
  decision: "allowed" | "approved" | "denied" | "rejected";
  capability?: string;
  outsideWorkspace: boolean;
  isError: boolean;
  errorCode?: string;
}

export interface ToolBrokerOptions {
  git?: RunGitExecutionContext;
  permissionProfile: PermissionProfile;
  workspacePath: string;
  approve?: (request: ToolApprovalRequest) => Promise<boolean>;
  artifacts?: ArtifactStore;
  maxInlineOutputBytes?: number;
  toolTimeoutMs?: number;
  clock?: () => string;
  ledger?: ToolInvocationLedger;
  budget?: BudgetLedger;
  budgetScopeId?: string;
  executionGrants?: ExecutionGrantAuthority;
}

interface InvocationCacheEntry {
  fingerprint: string;
  result: Promise<ToolResult>;
}

interface InvocationDecision {
  decision: ToolAuditRecord["decision"];
  capability?: string;
  outsideWorkspace: boolean;
}

class ToolTimeoutError extends Error {}

export class ToolBroker implements AgentToolRuntime {
  private readonly git?: RunGitExecutionContext;
  private readonly registry = new ToolRegistry();
  private readonly permissionProfile: PermissionProfile;
  private readonly workspacePath: string;
  private readonly approve?: ToolBrokerOptions["approve"];
  private readonly artifacts?: ArtifactStore;
  private readonly maxInlineOutputBytes: number;
  private readonly toolTimeoutMs: number;
  private readonly clock: () => string;
  private readonly ledger?: ToolInvocationLedger;
  private readonly budget?: BudgetLedger;
  private readonly budgetScopeId?: string;
  private readonly executionGrants: ExecutionGrantAuthority;
  private readonly invocationCache = new Map<string, InvocationCacheEntry>();
  private readonly audit: ToolAuditRecord[] = [];
  private readonly decisions = new Map<string, InvocationDecision>();
  private readonly extensionIds = new Map<string, string>();

  constructor(options: ToolBrokerOptions) {
    this.git = options.git;
    this.permissionProfile = options.permissionProfile;
    this.workspacePath = resolve(options.workspacePath);
    this.approve = options.approve;
    this.artifacts = options.artifacts;
    this.maxInlineOutputBytes = options.maxInlineOutputBytes ?? 8 * 1024;
    this.toolTimeoutMs = options.toolTimeoutMs ?? 120_000;
    this.clock = options.clock ?? (() => new Date().toISOString());
    this.ledger = options.ledger;
    this.budget = options.budget;
    this.budgetScopeId = options.budgetScopeId;
    this.executionGrants = options.executionGrants ?? createExecutionGrantAuthority();
    if (Boolean(this.budget) !== Boolean(this.budgetScopeId)) {
      throw new Error("Tool budget and budgetScopeId must be configured together.");
    }
    if (!Number.isSafeInteger(this.maxInlineOutputBytes) || this.maxInlineOutputBytes < 1) {
      throw new Error("maxInlineOutputBytes must be a positive integer.");
    }
    if (!Number.isSafeInteger(this.toolTimeoutMs) || this.toolTimeoutMs < 1) {
      throw new Error("toolTimeoutMs must be a positive integer.");
    }
  }

  register<TInput>(tool: NativeTool<TInput>): void {
    this.registerAttributed(tool);
  }

  registerExtensionTool<TInput>(extensionId: string, tool: NativeTool<TInput>): void {
    if (!/^[a-z][a-z0-9.-]{0,63}$/.test(extensionId)) {
      throw new Error(`Extension id ${extensionId} is invalid.`);
    }
    if (tool.definition.lifecycle === true) {
      throw new Error(`Extension ${extensionId} cannot register a lifecycle tool.`);
    }
    if (
      (PROTECTED_RUNNER_LIFECYCLE_TOOL_NAMES as readonly string[]).includes(
        tool.definition.name,
      )
    ) {
      throw new Error(
        `Extension ${extensionId} cannot register protected lifecycle tool ${tool.definition.name}.`,
      );
    }
    this.registerAttributed(tool, extensionId);
  }

  private registerAttributed<TInput>(
    tool: NativeTool<TInput>,
    extensionId?: string,
  ): void {
    this.registry.register({
      definition: tool.definition,
      validate: tool.validate,
      execute: async (input, context) => {
        try { return await this.executeAuthorized(tool, input as TInput, context, extensionId); }
        catch (error) {
          const refusal = isFilesystemMutation(tool.definition.name) && filesystemMutationFailure(error, this.workspacePath);
          if (refusal) return refusal;
          throw error;
        }
      },
    });
    if (extensionId) this.extensionIds.set(tool.definition.name, extensionId);
  }

  definitions(): ToolDefinition[] {
    return this.registry.definitions();
  }

  isLifecycleTool(name: string): boolean {
    return this.registry.isLifecycleTool(name);
  }

  isReadOnlyTool(name: string): boolean {
    return this.registry.isReadOnlyTool(name);
  }

  assertUniqueCallIds(
    calls: readonly ToolCallBlock[],
    seenCallIds: ReadonlySet<string>
  ): void {
    this.registry.assertUniqueCallIds(calls, seenCallIds);
  }

  async invoke(
    call: ToolCallBlock,
    context: ToolExecutionContext
  ): Promise<ToolResult> {
    const key = toolInvocationKey(context, call.callId);
    const fingerprint = toolInvocationFingerprint(call);
    const existing = this.invocationCache.get(key);
    if (existing) {
      if (existing.fingerprint !== fingerprint) {
        return failure(call, "idempotency_conflict", "Call ID was reused with different input.");
      }
      return await existing.result;
    }
    const result = this.invokeAudited(call, context).then((value) => {
      return value;
    });
    this.invocationCache.set(key, { fingerprint, result });
    return await result;
  }

  auditRecords(): readonly ToolAuditRecord[] {
    return this.audit.map((record) => Object.freeze({ ...record }));
  }

  private async invokeAudited(
    call: ToolCallBlock,
    context: ToolExecutionContext
  ): Promise<ToolResult> {
    const startedAt = this.clock();
    const result = await this.registry.invoke(call, context);
    const decision = this.decisions.get(call.callId) ?? {
      decision: "rejected" as const,
      outsideWorkspace: false,
    };
    const extensionId = this.extensionIds.get(call.name);
    this.decisions.delete(call.callId);
    this.audit.push(
      Object.freeze({
        callId: call.callId,
        toolName: call.name,
        ...(extensionId ? { extensionId } : {}),
        runId: context.runId,
        sessionId: context.sessionId,
        actor: Object.freeze({ ...context.actor }),
        startedAt,
        finishedAt: this.clock(),
        decision: decision.decision,
        ...(decision.capability ? { capability: decision.capability } : {}),
        outsideWorkspace: decision.outsideWorkspace,
        isError: result.isError,
        ...(result.error ? { errorCode: result.error.code } : {}),
      })
    );
    return result;
  }

  private async executeAuthorized<TInput>(
    tool: NativeTool<TInput>,
    input: TInput,
    context: ToolExecutionContext,
    extensionId?: string,
  ): Promise<ToolExecutionOutput> {
    const workspacePath = isFilesystemMutation(tool.definition.name) ? filesystemMutationWorkspace(this.workspacePath) : this.workspacePath;
    const toolContext = { ...context, workspacePath };
    const callId = context.callId ?? "unknown";
    const access = tool.assessAccess?.(input, toolContext) ?? {
      capability: tool.definition.effect,
    };
    // Capture identities before any approval/grant await can allow substitution.
    const mutationCapture = isFilesystemMutation(tool.definition.name)
      ? captureFilesystemMutation(workspacePath, tool.definition.name, access.paths ?? [])
      : undefined;
    const outsideWorkspace = await this.hasOutsidePath(access);
    const requiresApproval =
      this.permissionProfile !== "full" &&
      (outsideWorkspace ||
        tool.definition.effect === "external" ||
        access.external === true ||
        access.destructive === true ||
        access.network === true ||
        access.credentialChange === true ||
        (this.permissionProfile === "guarded" && tool.definition.effect !== "none"));

    if (requiresApproval) {
      if (!this.approve) {
        this.decisions.set(callId, {
          decision: "denied",
          capability: access.capability,
          outsideWorkspace,
        });
        return outputFailure(
          "approval_required",
          `Tool ${tool.definition.name} requires user approval.`
        );
      }
      const approved = await this.approve({
        runId: context.runId,
        sessionId: context.sessionId,
        callId,
        toolName: tool.definition.name,
        ...(extensionId ? { extensionId } : {}),
        actor: context.actor,
        permissionProfile: this.permissionProfile,
        access,
        outsideWorkspace,
        occurredAt: this.clock(),
      });
      if (!approved) {
        this.decisions.set(callId, {
          decision: "denied",
          capability: access.capability,
          outsideWorkspace,
        });
        return outputFailure("permission_denied", "User denied the tool call.");
      }
      this.decisions.set(callId, {
        decision: "approved",
        capability: access.capability,
        outsideWorkspace,
      });
    } else {
      this.decisions.set(callId, {
        decision: "allowed",
        capability: access.capability,
        outsideWorkspace,
      });
    }

    if (context.signal?.aborted) {
      return outputFailure("tool_cancelled", "Tool call was cancelled.");
    }
    const ledgerKey = toolInvocationKey(context, callId);
    const ledgerFingerprint = toolInvocationFingerprint({
      type: "tool_call",
      callId,
      name: extensionId
        ? `extension:${extensionId}:${tool.definition.name}`
        : tool.definition.name,
      arguments: input,
    });
    const budgetReservationId = `tool:${context.sessionId}:${callId}`;
    if (this.budget && this.budgetScopeId) {
      try {
        this.budget.reserve({
          scopeId: this.budgetScopeId,
          reservationId: budgetReservationId,
          kind: "tool",
          estimate: {},
          occurredAt: this.clock(),
          idempotencyKey: `reserve:${budgetReservationId}`,
        });
      } catch (error) {
        if (error instanceof BudgetExceededError) {
          return outputFailure(
            "budget_exhausted",
            `Tool-call budget ${error.dimension} reached its limit ${error.limit}.`
          );
        }
        throw error;
      }
    }
    const ledgerDecision = this.ledger?.begin({
      key: ledgerKey,
      fingerprint: ledgerFingerprint,
      callId,
      toolName: tool.definition.name,
      ...(extensionId ? { extensionId } : {}),
      runId: context.runId,
      sessionId: context.sessionId,
      replaySafe: tool.definition.readOnly === true && tool.definition.effect === "none",
      effect: tool.definition.effect,
      access,
      outsideWorkspace,
      occurredAt: this.clock(),
    });
    if (ledgerDecision?.state === "completed") {
      const { callId: _callId, toolName: _toolName, ...output } = ledgerDecision.result;
      return output;
    }
    if (ledgerDecision?.state === "conflict") {
      return outputFailure("idempotency_conflict", "Call ID was reused with different input.");
    }
    if (ledgerDecision?.state === "in_doubt") {
      return outputFailure(
        "reconciliation_required",
        "A prior side-effecting tool attempt has no durable completion record."
      );
    }
    const timeoutController = new AbortController();
    const signal = context.signal
      ? AbortSignal.any([context.signal, timeoutController.signal])
      : timeoutController.signal;
    let timeout: NodeJS.Timeout | undefined;
    let executionGrant: OpaqueExecutionGrant | undefined;
    let grantDisposition: "completed" | "cancelled" | "timed_out" = "completed";
    try {
      executionGrant = await this.executionGrants.issue({
        runId: context.runId,
        sessionId: context.sessionId,
        actor: context.actor,
        toolName: tool.definition.name,
        callId,
        // Tool approval policy may be read-only/guarded (e.g. verifier), while
        // execution retains the actual owner-selected run isolation profile.
        permissionProfile: this.git?.permissionProfile ?? this.permissionProfile,
        workspacePath,
        access: (access.paths !== undefined
          ? access.paths.map((entry) => ({
              path: entry.path,
              mode: entry.access === "read" ? "read" as const : "write" as const,
            }))
          : [{
              path: this.workspacePath,
              mode: tool.definition.effect === "none" ? "read" as const : "write" as const,
            }]),
        externalApproved:
          outsideWorkspace &&
          (this.permissionProfile === "full" ||
            this.decisions.get(callId)?.decision === "approved"),
        destructiveApproved:
          access.destructive === true &&
          (this.permissionProfile === "full" ||
            this.decisions.get(callId)?.decision === "approved"),
        networkApproved:
          access.network === true &&
          (this.permissionProfile === "full" ||
            this.decisions.get(callId)?.decision === "approved"),
        signal,
      });
      const filesystemMutation = mutationCapture ? authorizeFilesystemMutation(mutationCapture, {
        authority: this.executionGrants, grant: executionGrant,
        binding: { runId: context.runId, sessionId: context.sessionId, actor: context.actor,
          toolName: tool.definition.name, callId, permissionProfile: this.git?.permissionProfile ?? this.permissionProfile },
        signal,
      }) : undefined;
      const invocationContext = { ...toolContext, signal, executionGrant, filesystemMutation };
      const execution = this.git
        ? this.git.withCall(invocationContext, () => tool.execute(input, invocationContext))
        : tool.execute(input, invocationContext);
      const timeoutResult = new Promise<never>((_resolve, reject) => {
        timeout = setTimeout(() => {
          timeoutController.abort();
          reject(new ToolTimeoutError());
        }, this.toolTimeoutMs);
      });
      const output = await this.boundOutput(
        tool.definition.name,
        await Promise.race([execution, timeoutResult]),
        extensionId,
      );
      this.completeLedger(ledgerKey, ledgerFingerprint, callId, tool.definition.name, output);
      this.settleToolBudget(budgetReservationId);
      return output;
    } catch (error) {
      if (error instanceof ToolTimeoutError) {
        grantDisposition = "timed_out";
        const output = outputFailure(
          "tool_timeout",
          `Tool ${tool.definition.name} exceeded ${this.toolTimeoutMs} ms.`
        );
        this.completeLedger(ledgerKey, ledgerFingerprint, callId, tool.definition.name, output);
        this.settleToolBudget(budgetReservationId);
        return output;
      }
      if (signal.aborted) {
        grantDisposition = "cancelled";
        const output = outputFailure("tool_cancelled", "Tool call was cancelled.");
        this.completeLedger(ledgerKey, ledgerFingerprint, callId, tool.definition.name, output);
        this.settleToolBudget(budgetReservationId);
        return output;
      }
      this.settleToolBudget(budgetReservationId);
      const refusal = isFilesystemMutation(tool.definition.name) && filesystemMutationFailure(error, this.workspacePath);
      if (refusal) {
        this.completeLedger(ledgerKey, ledgerFingerprint, callId, tool.definition.name, refusal);
        return refusal;
      }
      throw error;
    } finally {
      if (timeout) clearTimeout(timeout);
      if (executionGrant) await this.executionGrants.revoke(executionGrant, grantDisposition);
    }
  }

  private settleToolBudget(reservationId: string): void {
    if (!this.budget || !this.budgetScopeId) return;
    this.budget.settle({
      scopeId: this.budgetScopeId,
      reservationId,
      actual: {},
      occurredAt: this.clock(),
      idempotencyKey: `settle:${reservationId}`,
    });
  }

  private completeLedger(
    key: string,
    fingerprint: string,
    callId: string,
    toolName: string,
    output: ToolExecutionOutput
  ): void {
    this.ledger?.complete(
      key,
      fingerprint,
      { callId, toolName, ...output },
      this.clock()
    );
  }

  private async hasOutsidePath(access: ToolAccessRequest): Promise<boolean> {
    if (!access.paths?.length) return false;
    const workspace = await realpath(this.workspacePath);
    for (const requested of access.paths) {
      const target = isAbsolute(requested.path)
        ? resolve(requested.path)
        : resolve(this.workspacePath, requested.path);
      const canonical = await canonicalTarget(target);
      const traversal = relative(workspace, canonical);
      if (traversal === "" || (!traversal.startsWith("..") && !isAbsolute(traversal))) {
        continue;
      }
      return true;
    }
    return false;
  }

  private async boundOutput(
    toolName: string,
    output: ToolExecutionOutput,
    extensionId?: string,
  ): Promise<ToolExecutionOutput> {
    let changed = false;
    const content: ToolExecutionOutput["content"] = [];
    for (const block of output.content) {
      if (block.type !== "text" && block.type !== "json") {
        content.push(block);
        continue;
      }
      const serialized = block.type === "text"
        ? block.text
        : (JSON.stringify(block.value) ?? "null");
      if (Buffer.byteLength(serialized) <= this.maxInlineOutputBytes) {
        content.push(block);
        continue;
      }
      changed = true;
      const structured = block.type === "json";
      const artifact = this.artifacts
        ? await this.artifacts.put(
            Buffer.from(serialized),
            structured ? "application/json" : "text/plain",
            `${extensionId ? `extension ${extensionId}: ` : ""}${toolName}${
              structured ? " structured" : ""
            } output`
          )
        : undefined;
      content.push({
        type: "text",
        text: artifact
          ? `${structured ? "Structured output" : "Output"} exceeded ${this.maxInlineOutputBytes} inline bytes and was stored as an artifact.\n\n${previewText(serialized, this.maxInlineOutputBytes)}`
          : previewText(serialized, this.maxInlineOutputBytes),
      });
      if (artifact) {
        content.push({
          type: "artifact",
          hash: artifact.hash,
          mediaType: artifact.mediaType,
          label: artifact.label,
        });
      }
    }
    return changed ? { ...output, content } : output;
  }
}

function previewText(text: string, maximumBytes: number): string {
  const bytes = Buffer.from(text);
  if (bytes.byteLength <= maximumBytes) return text;
  const headLength = Math.ceil(maximumBytes * 0.75);
  const tailLength = maximumBytes - headLength;
  const head = bytes.subarray(0, headLength).toString("utf8");
  const tail = bytes.subarray(bytes.byteLength - tailLength).toString("utf8");
  return `${head}\n\n… ${bytes.byteLength - maximumBytes} bytes omitted …\n\n${tail}`;
}

async function canonicalTarget(target: string): Promise<string> {
  let current = target;
  const missing: string[] = [];
  while (true) {
    try {
      await lstat(current);
      return resolve(await realpath(current), ...missing);
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      if (code !== "ENOENT") throw error;
      const parent = dirname(current);
      if (parent === current) throw error;
      missing.unshift(basename(current));
      current = parent;
    }
  }
}

function outputFailure(code: string, message: string): ToolExecutionOutput {
  return {
    content: [{ type: "text", text: message }],
    isError: true,
    error: { code, message },
  };
}

function failure(call: ToolCallBlock, code: string, message: string): ToolResult {
  return {
    callId: call.callId,
    toolName: call.name,
    ...outputFailure(code, message),
  };
}
