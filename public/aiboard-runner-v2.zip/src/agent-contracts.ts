import type { OpaqueExecutionGrant } from "./execution-grants.js";
import type { FilesystemMutationPermit } from "./filesystem-mutation-fence.js";

export type AgentRole = "architect" | "worker" | "subagent" | "verifier";

export interface AgentActor {
  role: AgentRole;
  id: string;
}

export interface TextBlock {
  type: "text";
  text: string;
}

export interface ArtifactBlock {
  type: "artifact";
  hash: string;
  mediaType: string;
  label?: string;
}

export interface JsonBlock {
  type: "json";
  value: unknown;
}

export interface ToolCallBlock {
  type: "tool_call";
  callId: string;
  name: string;
  arguments: unknown;
}

export type AssistantBlock = TextBlock | ToolCallBlock;
export type ToolContentBlock = TextBlock | ArtifactBlock | JsonBlock;

export interface AgentMessage {
  id: string;
  role: "system" | "user" | "assistant" | "tool";
  content: string | AssistantBlock[] | ToolResult;
}

export type ModelStopReason =
  | "tool_calls"
  | "end_turn"
  | "max_tokens"
  | "cancelled";

export interface ModelTurn {
  blocks: AssistantBlock[];
  stopReason: ModelStopReason;
  providerRequestId?: string;
  usage?: {
    inputTokens?: number;
    inputTokenSource?: "reported" | "estimated";
    cachedInputTokens?: number;
    cacheWriteInputTokens?: number;
    outputTokens?: number;
  };
}

export type AgentToolChoice =
  | "auto"
  | "none"
  | "required"
  | { type: "function"; name: string };

export type AgentHostedToolType =
  | "web_search"
  | "web_fetch"
  | "shell"
  | "apply_patch"
  | "datetime"
  | "image_generation"
  | "advisor"
  | "subagent"
  | "fusion"
  | "tool_search";

export interface AgentHostedToolDefinition {
  type: AgentHostedToolType;
  parameters?: Readonly<Record<string, unknown>>;
}

export interface AgentModelRequest {
  sessionId: string;
  messages: readonly AgentMessage[];
  tools: readonly ToolDefinition[];
  toolChoice?: AgentToolChoice;
  hostedTools?: readonly AgentHostedToolDefinition[];
  signal?: AbortSignal;
}

export interface AgentModel {
  complete(request: AgentModelRequest): Promise<ModelTurn>;
}

export type JsonSchema = Readonly<Record<string, unknown>>;
export type ToolEffect = "none" | "workspace" | "external";

export interface ToolDefinition {
  name: string;
  description: string;
  inputSchema: JsonSchema;
  readOnly: boolean;
  effect: ToolEffect;
  lifecycle?: boolean;
  /** Internal tools can remain executable while being omitted from model schemas. */
  modelVisible?: boolean;
  strict?: boolean;
  /** OpenRouter Responses extension used with the hosted Tool Search tool. */
  deferLoading?: boolean;
}

export type AgentLifecycleSignal =
  | { type: "submit_task"; changeSetId: string }
  | {
      type: "verifier_verdict_submitted";
      reviewId: string;
      satisfied: boolean;
    }
  | {
      type: "verifier_expectations_recorded";
      reviewId: string;
    }
  | {
      type: "plan_critique_submitted";
      critiqueId: string;
      blockingFindingCount: number;
    }
  | { type: "ask_architect"; requestId: string; blocking: boolean }
  | { type: "request_replan"; requestId: string }
  | { type: "return_subagent"; summary: string; artifactHashes: string[] }
  | {
      type: "architect_action";
      action:
        | "plan_created"
        | "plan_reconciled"
        | "task_revised"
        | "guidance_answered"
        | "review_decided"
        | "integration_requested"
        | "acceptance_contract_upgraded"
        | "final_verification_planned"
        | "final_verification_review_decided"
        | "verification_repairs_planned"
        | "delivery_boundary_failure_resolved"
        | "test_integrity_reason_recorded"
        | "user_guidance_acknowledged"
        | "user_question_requested"
        | "plan_critique_resolved"
        | "context_recording_resolved"
        | "run_completed";
      referenceId?: string;
    };

export type ValidationResult<T> =
  | { ok: true; value: T }
  | { ok: false; issues: string[] };

export interface ToolExecutionContext {
  runId: string;
  sessionId: string;
  actor: AgentActor;
  workspacePath?: string;
  signal?: AbortSignal;
  callId?: string;
  toolName?: string;
  /** Runner-created after authorization. Model input can never populate this field. */
  executionGrant?: OpaqueExecutionGrant;
  /** Single-use last-mile ticket, backed by that same original Broker grant. */
  filesystemMutation?: FilesystemMutationPermit;
}

export type ToolPathAccessMode = "read" | "write" | "delete";

export interface ToolPathAccess {
  path: string;
  access: ToolPathAccessMode;
}

export interface ToolAccessRequest {
  capability: string;
  paths?: ToolPathAccess[];
  external?: boolean;
  destructive?: boolean;
  network?: boolean;
  credentialChange?: boolean;
}

export interface ToolExecutionOutput {
  content: ToolContentBlock[];
  isError: boolean;
  error?: ToolError;
  lifecycle?: AgentLifecycleSignal;
}

export interface NativeTool<TInput = unknown> {
  definition: ToolDefinition;
  validate(input: unknown): ValidationResult<TInput>;
  assessAccess?(
    input: TInput,
    context: ToolExecutionContext
  ): ToolAccessRequest;
  execute(
    input: TInput,
    context: ToolExecutionContext
  ): Promise<ToolExecutionOutput>;
}

export interface ToolError {
  code: string;
  message: string;
  issues?: string[];
}

export interface ToolResult extends ToolExecutionOutput {
  callId: string;
  toolName: string;
}
