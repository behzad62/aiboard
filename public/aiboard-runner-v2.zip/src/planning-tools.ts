import type {
  NativeTool,
  ToolExecutionContext,
  ToolExecutionOutput,
  ValidationResult,
} from "./agent-contracts.js";
import type { ArtifactStore } from "./artifact-store.js";
import {
  buildExecutionPlanRevision,
  normalizePlanSubmission,
  validateExecutionPlanRevision,
  validateRequirementLedger,
  type ExecutionPlanPhase,
  type PlanSubmissionActuals,
  type PlanSubmissionRevision,
  type SourceRequirement,
  type SourceSectionDisposition,
} from "./planning-contracts.js";
import {
  assertOpenArchitectQuestionAllowsEvent,
  assertPendingUserGuidanceAllowsEvent,
  rebuildSchedulerProjection,
  type NewSchedulerEvent,
  type SchedulerProjection,
  type SchedulerStore,
} from "./scheduler-store.js";
import {
  computeArtifactDigest,
  type ApprovedSourceManifest,
} from "./source-manifest.js";
import { createRequestCoverageReviewTool } from "./planning-review.js";
import { PHASE_SCHEMA, PLAN_REVISION_SCHEMA, REQUIREMENT_SCHEMA, TASK_CONTRACT_SCHEMA } from "./planning-tool-schemas.js";
import { lifecycleEventResult } from "./lifecycle-receipt.js";

/**
 * Architect lifecycle tools for evidence-gated planning (Runner V2 P6.6, T3a).
 *
 * These tools drive T2's planning events for a NEW-POLICY run
 * (planningPolicyVersion 1): bounded section-by-section source reads,
 * skeleton-ledger persistence before task generation, plan draft/revise,
 * and coverage review requests. C4 derives the resume index from the
 * durable read index and plan/review state instead of recording planning
 * checkpoints. Every tool validates with T1's validators and
 * appends through T2's events — there is no second authority. The scheduler
 * reducer re-validates everything; tool-side checks only produce clearer
 * errors earlier.
 *
 * Coverage review, the reviewer runtime, and the plan_ready transition live in
 * `planning-review.ts` (T3b): `planning.plan_ready` requires a bound coverage
 * review with durably recorded obligations, and the request tool below is the
 * Architect's step that starts that review.
 */

export const MAX_PLANNING_SOURCE_SECTION_BYTES = 64 * 1024;

/** Stable lifecycle-surface names, in the sorted order the surface asserts. */
export const PLANNING_TOOL_NAMES = Object.freeze([
  "draft_planning_plan",
  "patch_planning_plan",
  "persist_planning_ledger",
  "read_current_plan_revision",
  "read_planning_source_section",
  "request_coverage_review",
  "revise_planning_plan",
]);

/** Supplies the original approved-source bytes for a manifest. */
export type PlanningSourceReader = (
  manifest: ApprovedSourceManifest,
) => Promise<Uint8Array>;

export interface PlanningToolsOptions {
  store: SchedulerStore;
  artifacts?: ArtifactStore;
  readSource?: PlanningSourceReader;
  clock?: () => string;
  /**
   * T9 repair cycle 1 (N5): when true, the turn is on the answer path and
   * only the durable read tool is registered — every plan-progressing
   * planning tool always refuses there.
   */
  answerPath?: boolean;
}

interface ReadSourceSectionInput {
  manifestId?: string;
  sectionId?: string;
}

interface PersistLedgerInput {
  id: string;
  requirements: readonly SourceRequirement[];
  phases: readonly ExecutionPlanPhase[];
  nonNormativeSections?: readonly SourceSectionDisposition[];
}

interface DraftPlanInput {
  revision: PlanSubmissionRevision;
}

interface RevisePlanInput {
  revision: PlanSubmissionRevision;
  expectedRevisionId?: string;
  expectedDigest?: string;
}

export function createPlanningTools(
  options: PlanningToolsOptions,
): NativeTool<unknown>[] {
  const clock = options.clock ?? (() => new Date().toISOString());
  const readSource = options.readSource ??
    (options.artifacts ? artifactSourceReader(options.artifacts) : undefined);
  // T3b (N2): every full verified read appends a durable
  // `planning.source_section_read` event bound to the manifest revision and
  // section digest. Checkpoint coverage and readiness read the durable
  // projection — there is no in-memory receipt set anymore.
  // T9 repair cycle 1 (N5): answer turns keep only the durable read.
  if (options.answerPath === true) {
    return [readSourceSectionTool(options.store, readSource, clock)];
  }
  return [
    readSourceSectionTool(options.store, readSource, clock),
    readCurrentPlanTool(options.store),
    persistLedgerTool(options.store, clock),
    draftPlanTool(options.store, clock),
    revisePlanTool(options.store, clock),
    patchPlanTool(options.store, revisePlanTool(options.store, clock)),
    createRequestCoverageReviewTool({ store: options.store, clock }),
  ];
}

/** Kernel-stamped envelope fields a revision submission omits (the kernel re-stamps them). */
const KERNEL_STAMPED_REVISION_FIELDS = [
  "digest",
  "runId",
  "sourceManifestId",
  "sourceManifestDigest",
  "workflowPolicyVersion",
  "createdAt",
  "coverageReviewId",
  "repairBudgetLineageId",
] as const;

/**
 * Read-only: the current plan revision in the exact shape draft/revise accept. Without it an Architect
 * revising a large plan had to rebuild the nested contract object from memory or from runner source
 * (P7: mimo spent many turns reading planning-contracts.ts to learn the input shape).
 */
function readCurrentPlanTool(store: SchedulerStore): NativeTool<Record<string, never>> {
  return {
    definition: {
      name: "read_current_plan_revision",
      description:
        "Read the current execution plan revision in the exact shape draft_planning_plan and " +
        "revise_planning_plan accept (kernel-stamped envelope fields removed). To revise, copy it, " +
        "change only what must change, give it a new revisionId, and pass it as revise_planning_plan's revision.",
      inputSchema: { type: "object", properties: {}, additionalProperties: false },
      readOnly: true,
      effect: "none",
      // Planning surface tools are kernel lifecycle tools (like read_planning_source_section); this one
      // only reads and never ends the action.
      lifecycle: true,
      batchable: true,
    },
    validate: (input) => validateObject(input, () => ({}), "This tool takes no input."),
    execute: async (_input, context) => {
      const denied = architectOnly(context);
      if (denied) return denied;
      const projection = rebuildSchedulerProjection(store.readRun(context.runId));
      const plan = projection.planning?.plan;
      if (!plan) {
        return errorOutput("no_plan_revision", "No plan revision exists yet; draft one with draft_planning_plan.");
      }
      const current = plan.revisionsById[plan.currentRevisionId] as unknown as Record<string, unknown>;
      const revision = Object.fromEntries(
        Object.entries(current).filter(([key]) => !(KERNEL_STAMPED_REVISION_FIELDS as readonly string[]).includes(key)),
      );
      return {
        content: [{
          type: "json",
          value: {
            currentRevisionId: plan.currentRevisionId,
            currentDigest: plan.currentDigest,
            readiness: projection.planning?.readiness,
            revision,
          },
        }],
        isError: false,
      };
    },
  };
}

function artifactSourceReader(artifacts: ArtifactStore): PlanningSourceReader {
  return async (manifest) => artifacts.get(manifest.artifactDigest);
}

function readSourceSectionTool(
  store: SchedulerStore,
  readSource: PlanningSourceReader | undefined,
  clock: () => string,
): NativeTool<ReadSourceSectionInput> {
  return lifecycleTool({
    name: "read_planning_source_section",
    batchable: true,
    description:
      "Read one approved-source section in full over the manifest's complete section inventory, " +
      "or list the inventory when sectionId is omitted. Bounded: a section larger than the byte " +
      "cap is refused, never truncated. A full verified read appends a durable read record that " +
      "the derived resume index counts as covered; the inventory listing exposes the full derived index.",
    schema: {
      type: "object",
      properties: {
        manifestId: { type: "string", minLength: 1 },
        sectionId: { type: "string", minLength: 1 },
      },
      required: [],
      additionalProperties: false,
    },
    validate: (input) =>
      validateObject(input, (value) => {
        if (
          value.manifestId !== undefined && !nonEmpty(value.manifestId)
        ) return null;
        if (
          value.sectionId !== undefined && !nonEmpty(value.sectionId)
        ) return null;
        return {
          ...(value.manifestId !== undefined ? { manifestId: value.manifestId } : {}),
          ...(value.sectionId !== undefined ? { sectionId: value.sectionId } : {}),
        };
      }, "manifestId and sectionId must be non-empty strings when provided."),
    execute: async (input, context) => {
      const denied = architectOnly(context);
      if (denied) return denied;
      const projection = rebuildSchedulerProjection(store.readRun(context.runId));
      if (projection.planningPolicyVersion !== 1 || !projection.planning) {
        return errorOutput(
          "planning_not_configured",
          "Source reads require a new-policy run with a registered approved source.",
        );
      }
      const planning = projection.planning;
      const manifest = planning.source.manifestsById[planning.source.currentManifestId];
      if (input.manifestId !== undefined && input.manifestId !== manifest.manifestId) {
        return errorOutput(
          "stale_manifest",
          `Source read cites manifest ${input.manifestId}, but the current manifest is ${manifest.manifestId}.`,
        );
      }
      // Inventory listing: the complete trusted section inventory plus the
      // derived resume index (covered and remaining sections, completed
      // contracts, outstanding work, next action), with no content. The
      // Architect reads every section.
      if (input.sectionId === undefined) {
        return {
          content: [{
            type: "json",
            value: {
              manifestId: manifest.manifestId,
              sourceId: manifest.sourceId,
              artifactDigest: manifest.artifactDigest,
              byteLength: manifest.byteLength,
              sections: manifest.sections.map((section) => ({
                id: section.id,
                ...(section.title !== undefined ? { title: section.title } : {}),
                startByte: section.startByte,
                endByte: section.endByte,
                digest: section.digest,
              })),
              coveredSourceSectionIds: [...planning.resume.coveredSourceSectionIds],
              remainingSourceSectionIds: [...planning.resume.remainingSourceSectionIds],
              ...(planning.resume.nextSourceSectionId !== undefined
                ? { nextSourceSectionId: planning.resume.nextSourceSectionId }
                : {}),
              completedPlanningContractIds: [...planning.resume.completedPlanningContractIds],
              outstandingWork: [...planning.resume.outstandingWork],
              nextAction: planning.resume.nextAction,
            },
          }],
          isError: false,
        };
      }
      const section = manifest.sections.find((candidate) => candidate.id === input.sectionId);
      if (!section) {
        return errorOutput(
          "unknown_manifest_section",
          `Source section ${input.sectionId} is not in the current manifest's complete section inventory.`,
        );
      }
      const spanBytes = section.endByte - section.startByte;
      if (spanBytes > MAX_PLANNING_SOURCE_SECTION_BYTES) {
        return errorOutput(
          "source_section_too_large",
          `Source section ${section.id} spans ${spanBytes} bytes, over the ${MAX_PLANNING_SOURCE_SECTION_BYTES}-byte bound; it cannot be read and never counts as covered.`,
        );
      }
      if (!readSource) {
        return errorOutput(
          "source_bytes_unavailable",
          "Approved-source bytes are not provisioned for this run; the section cannot be read and never counts as covered.",
        );
      }
      let bytes: Uint8Array;
      try {
        bytes = await readSource(manifest);
      } catch (error) {
        return errorOutput(
          "source_bytes_unavailable",
          error instanceof Error ? error.message : String(error),
        );
      }
      if (bytes.length !== manifest.byteLength) {
        return errorOutput(
          "source_bytes_drift",
          `Supplied source bytes have length ${bytes.length}, not the manifest's recorded ${manifest.byteLength} (source drift); nothing is counted as covered.`,
        );
      }
      if (computeArtifactDigest(bytes) !== manifest.artifactDigest) {
        return errorOutput(
          "source_bytes_drift",
          "Supplied source bytes do not match the manifest's recorded artifact digest (source drift); nothing is counted as covered.",
        );
      }
      const slice = bytes.subarray(section.startByte, section.endByte);
      if (slice.length !== spanBytes) {
        return errorOutput(
          "source_section_truncated",
          `Source section ${section.id} could only be read partially (${slice.length} of ${spanBytes} bytes); a truncated section never counts as covered.`,
        );
      }
      if (computeArtifactDigest(slice) !== section.digest) {
        return errorOutput(
          "source_bytes_drift",
          `Source section ${section.id} does not match its recorded digest (source drift); it never counts as covered.`,
        );
      }
      // T3b (N2): the full verified read is durable. Re-reading the same
      // section at the same revision is an idempotent no-op.
      try {
        assertPendingUserGuidanceAllowsEvent(projection, {
          type: "planning.source_section_read",
          actor: { role: "architect", id: context.actor.id },
          payload: {},
        });
        assertOpenArchitectQuestionAllowsEvent(projection, {
          type: "planning.source_section_read",
          actor: { role: "architect", id: context.actor.id },
          payload: {},
        });
        store.append({
          runId: context.runId,
          type: "planning.source_section_read",
          occurredAt: clock(),
          actor: { role: "architect", id: context.actor.id },
          idempotencyKey: `planning-sourceread:${manifest.manifestId}:${section.id}`,
          payload: {
            manifestId: manifest.manifestId,
            manifestDigest: manifest.artifactDigest,
            sectionId: section.id,
            sectionDigest: section.digest,
            readAt: clock(),
          },
        });
      } catch (error) {
        return errorOutput(
          "mechanical_transition_rejected",
          error instanceof Error ? error.message : String(error),
        );
      }
      return {
        content: [{
          type: "json",
          value: {
            manifestId: manifest.manifestId,
            sectionId: section.id,
            startByte: section.startByte,
            endByte: section.endByte,
            byteLength: slice.length,
            digest: section.digest,
            text: Buffer.from(slice).toString("utf8"),
          },
        }],
        isError: false,
      };
    },
  });
}

function persistLedgerTool(
  store: SchedulerStore,
  clock: () => string,
): NativeTool<PersistLedgerInput> {
  return lifecycleTool({
    name: "persist_planning_ledger",
    description:
      "Persist the requirement-ledger skeleton (requirements plus phases) before task generation. " +
      "Every manifest section must be referenced or carry an authorized non-normative disposition.",
    schema: {
      type: "object",
      properties: {
        id: { type: "string", minLength: 1 },
        requirements: { type: "array", minItems: 1, items: REQUIREMENT_SCHEMA },
        phases: { type: "array", minItems: 1, items: PHASE_SCHEMA },
        nonNormativeSections: { type: "array" },
      },
      required: ["id", "requirements", "phases"],
      additionalProperties: false,
    },
    validate: (input) =>
      validateObject(input, (value) => {
        if (!nonEmpty(value.id)) return null;
        if (!Array.isArray(value.requirements) || value.requirements.length === 0) return null;
        if (!Array.isArray(value.phases) || value.phases.length === 0) return null;
        if (value.nonNormativeSections !== undefined && !Array.isArray(value.nonNormativeSections)) {
          return null;
        }
        return {
          id: value.id,
          requirements: value.requirements as readonly SourceRequirement[],
          phases: value.phases as readonly ExecutionPlanPhase[],
          ...(value.nonNormativeSections !== undefined
            ? { nonNormativeSections: value.nonNormativeSections as readonly SourceSectionDisposition[] }
            : {}),
        };
      }, "id, requirements, and phases are required."),
    execute: async (input, context) => {
      const denied = architectOnly(context);
      if (denied) return denied;
      const projection = rebuildSchedulerProjection(store.readRun(context.runId));
      if (projection.planningPolicyVersion !== 1 || !projection.planning) {
        return errorOutput(
          "planning_not_configured",
          "The requirement ledger requires a new-policy run with a registered approved source.",
        );
      }
      const triage = triageBuildRequired(projection);
      if (triage) return triage;
      const planning = projection.planning;
      if (planning.ledger) {
        return errorOutput(
          "ledger_already_persisted",
          "The initial planning ledger is already persisted.",
        );
      }
      const manifest = planning.source.manifestsById[planning.source.currentManifestId];
      const validation = validateRequirementLedger(
        input.requirements,
        manifest,
        input.phases.map((phase) => (phase as ExecutionPlanPhase).id),
        input.nonNormativeSections ?? [],
        amendmentHistoryOf(planning),
      );
      if (!validation.valid) {
        return errorOutput(
          "invalid_requirement_ledger",
          `Requirement ledger is invalid: ${validation.issues.map((issue) => issue.message).join(" ")}`,
          validation.issues.map((issue) => issue.message),
        );
      }
      return appendEvent(store, {
        runId: context.runId,
        type: "planning.ledger_persisted",
        occurredAt: clock(),
        actor: { role: "architect", id: context.actor.id },
        idempotencyKey: `planning-ledger:${input.id}`,
        payload: {
          id: input.id,
          requirements: structuredClone(input.requirements),
          phases: structuredClone(input.phases),
          nonNormativeSections: structuredClone(input.nonNormativeSections ?? []),
        },
      }, {
        type: "architect_action",
        action: "plan_created",
        referenceId: input.id,
      });
    },
  });
}

// C4 (AR-R13): record_planning_checkpoint is removed from the new-policy surface. The resume index is derived from the durable read index and plan/review state; old checkpoint events still reduce and replay. No replacement bookkeeping tool.
function draftPlanTool(
  store: SchedulerStore,
  clock: () => string,
): NativeTool<DraftPlanInput> {
  return lifecycleTool({
    name: "draft_planning_plan",
    description:
      "Draft the execution plan revision (requirements, phases, complete task contracts, bounded " +
      "investigations) after the requirement ledger is persisted. Envelope fields (run, manifest id and digest, " +
      "policy version, createdAt, coverage review and repair lineage ids), each task's requiredBase and " +
      "decision/disposition timestamps are " +
      "kernel-stamped: omit them or supply the exact " +
      "actual values; one-sided requirement/task/phase links are derived, conflicting sides refused.",
    schema: {
      type: "object",
      properties: {
        revision: PLAN_REVISION_SCHEMA,
      },
      required: ["revision"],
      additionalProperties: false,
    },
    validate: (input) =>
      validateObject(input, (value) => {
        if (!isRecord(value.revision) || !nonEmpty(value.revision.revisionId)) return null;
        return { revision: value.revision as PlanSubmissionRevision };
      }, "revision with a revisionId is required."),
    execute: async (input, context) => {
      const denied = architectOnly(context);
      if (denied) return denied;
      const projection = rebuildSchedulerProjection(store.readRun(context.runId));
      if (projection.planningPolicyVersion !== 1 || !projection.planning) {
        return errorOutput(
          "planning_not_configured",
          "Plan drafts require a new-policy run with a registered approved source.",
        );
      }
      const triage = triageBuildRequired(projection);
      if (triage) return triage;
      const planning = projection.planning;
      if (!planning.ledger) {
        return errorOutput(
          "ledger_required",
          "The requirement ledger must be persisted before the plan is drafted.",
        );
      }
      if (planning.plan) {
        return errorOutput(
          "plan_already_drafted",
          "An initial planning revision already exists; use revise_planning_plan.",
        );
      }
      const manifest = planning.source.manifestsById[planning.source.currentManifestId];
      // C5 (AR-R15): normalize and stamp the kernel envelope BEFORE the
      // digest is calculated, so the digest binds the stamped submission.
      // Historical revisions, replay and canonical serialization are
      // untouched — only this new-submission boundary normalizes.
      const normalized = normalizePlanSubmission(
        input.revision,
        submissionActuals(projection, manifest, context.runId, clock),
      );
      if (!normalized.ok) {
        return errorOutput(
          normalized.failure.code,
          `Plan revision is refused: ${normalized.failure.message}`,
          [normalized.failure.message],
        );
      }
      const revision = buildExecutionPlanRevision(normalized.revision);
      const validation = validateExecutionPlanRevision(
        revision,
        manifest,
        amendmentHistoryOf(planning),
      );
      if (!validation.valid) {
        return errorOutput(
          "invalid_plan_revision",
          `Plan revision is invalid: ${validation.issues.map((issue) => issue.message).join(" ")}`,
          validation.issues.map((issue) => issue.message),
        );
      }
      return appendEvent(store, {
        runId: context.runId,
        type: "planning.plan_drafted",
        occurredAt: clock(),
        actor: { role: "architect", id: context.actor.id },
        idempotencyKey: `planning-plan:${revision.revisionId}`,
        payload: {
          revision: structuredClone(revision),
        },
      }, {
        type: "architect_action",
        action: "plan_created",
        referenceId: revision.revisionId,
      });
    },
  });
}

function revisePlanTool(
  store: SchedulerStore,
  clock: () => string,
): NativeTool<RevisePlanInput> {
  return lifecycleTool({
    name: "revise_planning_plan",
    description:
      "Revise the execution plan revision (start from read_current_plan_revision's output, change only " +
      "what must change, and give it a new revisionId) against the exact current revision identity " +
      "(expectedRevisionId plus expectedDigest, kernel-stamped from the durable plan when omitted; " +
      "a supplied stale base is refused). Envelope fields, requiredBase and decision timestamps are " +
      "kernel-stamped like a draft; one-sided links are derived, conflicting sides refused.",
    schema: {
      type: "object",
      properties: {
        revision: PLAN_REVISION_SCHEMA,
        expectedRevisionId: { type: "string", minLength: 1 },
        expectedDigest: { type: "string", minLength: 1 },
      },
      required: ["revision"],
      additionalProperties: false,
    },
    validate: (input) =>
      validateObject(input, (value) => {
        if (!isRecord(value.revision) || !nonEmpty(value.revision.revisionId)) return null;
        // Omitted expected identity stamps the durable current revision;
        // a supplied null, blank or malformed value is refused, never stamped.
        if (value.expectedRevisionId !== undefined && !nonEmpty(value.expectedRevisionId)) return null;
        if (value.expectedDigest !== undefined && !nonEmpty(value.expectedDigest)) return null;
        return {
          revision: value.revision as PlanSubmissionRevision,
          ...(value.expectedRevisionId === undefined
            ? {}
            : { expectedRevisionId: value.expectedRevisionId as string }),
          ...(value.expectedDigest === undefined
            ? {}
            : { expectedDigest: value.expectedDigest as string }),
        };
      }, "revision is required; expectedRevisionId and expectedDigest are kernel-stamped when omitted but refused when blank or malformed."),
    execute: async (input, context) => {
      const denied = architectOnly(context);
      if (denied) return denied;
      const projection = rebuildSchedulerProjection(store.readRun(context.runId));
      if (projection.planningPolicyVersion !== 1 || !projection.planning) {
        return errorOutput(
          "planning_not_configured",
          "Plan revisions require a new-policy run with a registered approved source.",
        );
      }
      const triage = triageBuildRequired(projection);
      if (triage) return triage;
      const planning = projection.planning;
      if (!planning.ledger) {
        return errorOutput(
          "ledger_required",
          "The requirement ledger must be persisted before the plan is revised.",
        );
      }
      if (!planning.plan) {
        return errorOutput(
          "plan_not_drafted",
          "No initial planning revision exists; use draft_planning_plan first.",
        );
      }
      // C5 (AR-R15): an omitted expected identity stamps the durable
      // current revision; a supplied stale base is refused. The event
      // payload carries the actual resolved identity, never undefined.
      const resolvedExpectedRevisionId = input.expectedRevisionId ?? planning.plan.currentRevisionId;
      const resolvedExpectedDigest = input.expectedDigest ?? planning.plan.currentDigest;
      if (
        resolvedExpectedRevisionId !== planning.plan.currentRevisionId ||
        resolvedExpectedDigest !== planning.plan.currentDigest
      ) {
        return errorOutput(
          "stale_plan_revision",
          "Plan revision uses a stale base revision; re-read the current revision identity first.",
        );
      }
      const manifest = planning.source.manifestsById[planning.source.currentManifestId];
      // C5 (AR-R15): normalize and stamp the kernel envelope BEFORE the
      // digest is calculated, so the digest binds the stamped submission.
      const normalized = normalizePlanSubmission(
        input.revision,
        submissionActuals(projection, manifest, context.runId, clock),
      );
      if (!normalized.ok) {
        return errorOutput(
          normalized.failure.code,
          `Plan revision is refused: ${normalized.failure.message}`,
          [normalized.failure.message],
        );
      }
      const revision = buildExecutionPlanRevision(normalized.revision);
      if (planning.plan.revisionHistoryIds.includes(revision.revisionId)) {
        return errorOutput(
          "duplicate_plan_revision",
          `Planning revision id ${revision.revisionId} is already in the revision history.`,
        );
      }
      const validation = validateExecutionPlanRevision(
        revision,
        manifest,
        amendmentHistoryOf(planning),
      );
      if (!validation.valid) {
        return errorOutput(
          "invalid_plan_revision",
          `Plan revision is invalid: ${validation.issues.map((issue) => issue.message).join(" ")}`,
          validation.issues.map((issue) => issue.message),
        );
      }
      const revised = appendEvent(store, {
        runId: context.runId,
        type: "planning.plan_revised",
        occurredAt: clock(),
        actor: { role: "architect", id: context.actor.id },
        idempotencyKey: `planning-plan:${revision.revisionId}`,
        payload: {
          revision: structuredClone(revision),
          expectedRevisionId: resolvedExpectedRevisionId,
          expectedDigest: resolvedExpectedDigest,
        },
      }, {
        type: "architect_action",
        action: "plan_reconciled",
        referenceId: revision.revisionId,
      });
      return revisedDuringCritiqueResolution(revised, projection, revision);
    },
  });
}

/**
 * Accepted critique findings are resolved by a revision and then resolve_plan_critique citing it,
 * before the revision's coverage review -- one Architect action. Ending the action at the revision
 * stranded the critique ("returned ... without a typed action", tunnel run), so while a submitted
 * critique awaits resolution the revision is a step, not the action's decision.
 */
export function revisedDuringCritiqueResolution(
  output: ToolExecutionOutput,
  projection: ReturnType<typeof rebuildSchedulerProjection>,
  revision: { revisionId: string; digest: string },
): ToolExecutionOutput {
  const critique = projection.planCritique?.current;
  if (output.isError || critique?.status !== "submitted" || (critique.blockingFindingIds ?? []).length === 0) return output;
  const { lifecycle: _decision, ...step } = output;
  return {
    ...step,
    content: [
      ...step.content,
      {
        type: "text",
        text: `Plan revised for plan critique ${critique.critiqueId}. Now call resolve_plan_critique (alone in its turn) ` +
          `resolving ${critique.blockingFindingIds!.join(", ")}; cite planRevisionId ${revision.revisionId} and planDigest ` +
          `${revision.digest} on each plan_reconciled finding.`,
      },
    ],
  };
}

interface PatchPlanInput {
  revisionId: string;
  expectedRevisionId?: string;
  expectedDigest?: string;
  upsertTasks?: Record<string, unknown>[];
  removeTaskIds?: string[];
  upsertPhases?: Record<string, unknown>[];
  removePhaseIds?: string[];
  upsertRequirements?: Record<string, unknown>[];
  removeRequirementIds?: string[];
  upsertPlanningDecisions?: Record<string, unknown>[];
  removePlanningDecisionIds?: string[];
  validationObligations?: string[];
}

const PATCH_SECTIONS = [
  ["tasks", "upsertTasks", "removeTaskIds"],
  ["phases", "upsertPhases", "removePhaseIds"],
  ["requirements", "upsertRequirements", "removeRequirementIds"],
  ["planningDecisions", "upsertPlanningDecisions", "removePlanningDecisionIds"],
] as const;

/**
 * Revise the plan by naming only what changes. Whole-plan revisions re-sent ~84 KB per revision and
 * one wrong field threw the whole call away (tunnel run). The patch is applied to the current
 * revision and goes through revise_planning_plan's exact path (normalization, validation, the
 * plan_revised event), so the kernel sees an ordinary complete revision.
 */
/** An upsert names an existing id and only the fields that change; new items are validated whole by the kernel. */
function idOnlyRequired(schema: Record<string, unknown>): Record<string, unknown> {
  return { ...schema, required: ["id"] };
}

function patchPlanTool(
  store: SchedulerStore,
  revise: NativeTool<RevisePlanInput>,
): NativeTool<PatchPlanInput> {
  const idList = { type: "array", items: { type: "string", minLength: 1 } };
  return lifecycleTool({
    name: "patch_planning_plan",
    description:
      "Revise the current plan by listing only the changes: upsert tasks, phases, requirements or planning " +
      "decisions by id (for an existing id send only the fields that change, they are merged onto the item; a new " +
      "id needs the complete item) and remove by id; " +
      "validationObligations replaces the list when given. Everything else is carried over from the current " +
      "revision. Links the kernel derives (requirement contributingTaskIds, phase requirementIds and " +
      "contributingTaskIds) are re-derived from the tasks and requirements. Prefer this over revise_planning_plan.",
    schema: {
      type: "object",
      properties: {
        revisionId: { type: "string", minLength: 1, description: "The new revision id." },
        expectedRevisionId: { type: "string", minLength: 1 },
        expectedDigest: { type: "string", minLength: 1 },
        upsertTasks: { type: "array", items: idOnlyRequired(TASK_CONTRACT_SCHEMA) },
        removeTaskIds: idList,
        upsertPhases: { type: "array", items: idOnlyRequired(PHASE_SCHEMA) },
        removePhaseIds: idList,
        upsertRequirements: { type: "array", items: idOnlyRequired(REQUIREMENT_SCHEMA) },
        removeRequirementIds: idList,
        upsertPlanningDecisions: {
          type: "array",
          items: {
            type: "object",
            properties: { id: { type: "string" }, description: { type: "string" } },
            required: ["id", "description"],
          },
        },
        removePlanningDecisionIds: idList,
        validationObligations: { type: "array", items: { type: "string", minLength: 1 } },
      },
      required: ["revisionId"],
      additionalProperties: false,
    },
    validate: (input) => {
      if (!isRecord(input)) return { ok: false, issues: ["The patch must be an object."] };
      const issues: string[] = [];
      if (!nonEmpty(input.revisionId)) issues.push("revisionId (the new revision id) is required.");
      for (const key of ["expectedRevisionId", "expectedDigest"] as const) {
        if (input[key] !== undefined && !nonEmpty(input[key])) issues.push(`${key} must be non-empty when given.`);
      }
      for (const [, upsert, remove] of PATCH_SECTIONS) {
        const items = input[upsert];
        if (items !== undefined && (!Array.isArray(items) || items.some((item) => !isRecord(item) || !nonEmpty(item.id)))) {
          issues.push(`${upsert} must be an array of items that each have an id.`);
        }
        const ids = input[remove];
        if (ids !== undefined && (!Array.isArray(ids) || ids.some((id) => !nonEmpty(id)))) {
          issues.push(`${remove} must be an array of ids.`);
        }
      }
      if (
        input.validationObligations !== undefined &&
        (!Array.isArray(input.validationObligations) || input.validationObligations.some((item) => !nonEmpty(item)))
      ) {
        issues.push("validationObligations must be an array of non-empty strings.");
      }
      return issues.length ? { ok: false, issues } : { ok: true, value: input as unknown as PatchPlanInput };
    },
    execute: async (input, context) => {
      const denied = architectOnly(context);
      if (denied) return denied;
      const plan = rebuildSchedulerProjection(store.readRun(context.runId)).planning?.plan;
      if (!plan) return errorOutput("plan_not_drafted", "No plan revision exists yet; draft one with draft_planning_plan.");
      const current = plan.revisionsById[plan.currentRevisionId] as unknown as Record<string, unknown>;
      const revision: Record<string, unknown> = Object.fromEntries(
        Object.entries(structuredClone(current))
          .filter(([key]) => !(KERNEL_STAMPED_REVISION_FIELDS as readonly string[]).includes(key)),
      );
      const unknownIds: string[] = [];
      for (const [section, upsert, remove] of PATCH_SECTIONS) {
        let items = [...((revision[section] as Record<string, unknown>[] | undefined) ?? [])];
        for (const id of input[remove] ?? []) {
          if (!items.some((item) => item.id === id)) unknownIds.push(`${section}:${id}`);
          items = items.filter((item) => item.id !== id);
        }
        for (const item of input[upsert] ?? []) {
          const index = items.findIndex((candidate) => candidate.id === item.id);
          // Merge onto the existing item: omitted fields (links such as accountablePhaseId included) carry
          // over. A replacing upsert dropped a task's phase link while the phase side was being re-derived.
          if (index >= 0) items[index] = { ...items[index], ...structuredClone(item) };
          else items.push(structuredClone(item));
        }
        revision[section] = items;
      }
      if (unknownIds.length) {
        return errorOutput(
          "unknown_plan_ids",
          `The patch removes ids that are not in revision ${plan.currentRevisionId}: ${unknownIds.join(", ")}.`,
        );
      }
      if (input.validationObligations) revision.validationObligations = [...input.validationObligations];
      // Derived links and per-revision stamps are re-derived from the patched revision; carrying the
      // stored copies would conflict with any changed task link.
      for (const requirement of revision.requirements as Record<string, unknown>[]) delete requirement.contributingTaskIds;
      for (const phase of revision.phases as Record<string, unknown>[]) {
        delete phase.requirementIds;
        delete phase.contributingTaskIds;
      }
      for (const task of revision.tasks as Record<string, unknown>[]) delete task.requiredBase;
      revision.revisionId = input.revisionId;
      return await revise.execute({
        revision: revision as unknown as PlanSubmissionRevision,
        ...(input.expectedRevisionId !== undefined ? { expectedRevisionId: input.expectedRevisionId } : {}),
        ...(input.expectedDigest !== undefined ? { expectedDigest: input.expectedDigest } : {}),
      }, context);
    },
  });
}

/**
 * Kernel actuals at submission. The new revision has not been reviewed,
 * so coverageReviewId is authoritatively absent. Budget lineage continues;
 * existing semantic decision times come from durable plan/ledger records.
 */
function submissionActuals(
  projection: SchedulerProjection,
  manifest: ApprovedSourceManifest,
  runId: string,
  clock: () => string,
): PlanSubmissionActuals {
  const planning = projection.planning;
  const currentRevision = planning?.plan !== undefined
    ? planning.plan.revisionsById[planning.plan.currentRevisionId]
    : undefined;
  return {
    runId,
    sourceManifestId: manifest.manifestId,
    sourceManifestDigest: manifest.artifactDigest,
    workflowPolicyVersion: projection.planningPolicyVersion ?? 1,
    createdAt: clock(),

    ...(currentRevision?.repairBudgetLineageId !== undefined
      ? { repairBudgetLineageId: currentRevision.repairBudgetLineageId }
      : {}),
    ledgerRequirements: planning?.ledger?.requirements,
    ...(currentRevision !== undefined ? { priorRevision: currentRevision } : {}),
  };
}



function amendmentHistoryOf(
  planning: NonNullable<ReturnType<typeof rebuildSchedulerProjection>["planning"]>,
) {
  return planning.source.manifestHistoryIds.flatMap((manifestId) => {
    const amendment = planning.source.manifestsById[manifestId]?.amendment;
    return amendment ? [amendment] : [];
  });
}

interface LifecycleToolOptions<T> {
  name: string;
  description: string;
  schema: Record<string, unknown>;
  validate: (input: unknown) => ValidationResult<T>;
  execute: NativeTool<T>["execute"];
  /** Only reads or records a read and never ends the action (see ToolDefinition.batchable). */
  batchable?: boolean;
}

function lifecycleTool<T>(options: LifecycleToolOptions<T>): NativeTool<T> {
  return {
    definition: {
      name: options.name,
      description: options.description,
      inputSchema: options.schema,
      readOnly: false,
      effect: "none",
      lifecycle: true,
      ...(options.batchable ? { batchable: true } : {}),
    },
    validate: options.validate,
    execute: options.execute,
  };
}

function validateObject<T>(
  input: unknown,
  parse: (value: Record<string, unknown>) => T | null,
  issue: string,
): ValidationResult<T> {
  if (!isRecord(input)) return { ok: false, issues: [issue] };
  const value = parse(input);
  return value ? { ok: true, value } : { ok: false, issues: [issue] };
}

function appendEvent(
  store: SchedulerStore,
  event: NewSchedulerEvent,
  lifecycle: NonNullable<ToolExecutionOutput["lifecycle"]>,
): ToolExecutionOutput {
  try {
    const events = store.readRun(event.runId);
    const projection = events.length > 0
      ? rebuildSchedulerProjection(events)
      : undefined;
    if (projection) {
      assertPendingUserGuidanceAllowsEvent(projection, event);
      assertOpenArchitectQuestionAllowsEvent(projection, event);
    }
    const appended = store.append(event);
    return {
      content: [{ type: "json", value: lifecycleEventResult(appended) }],
      isError: false,
      lifecycle,
    };
  } catch (error) {
    return errorOutput(
      "mechanical_transition_rejected",
      error instanceof Error ? error.message : String(error),
    );
  }
}

function architectOnly(context: ToolExecutionContext): ToolExecutionOutput | null {
  return context.actor.role === "architect"
    ? null
    : errorOutput("architect_only", "Only the Architect may use this tool.");
}

/**
 * T9 triage-first ordering (per-tool half): plan-progressing planning tools
 * require a durable triage decision of `build`. The durable read tool is
 * exempt — triage and answer turns may inspect the source. The reducer
 * refuses forged events as well.
 */
function triageBuildRequired(projection: SchedulerProjection): ToolExecutionOutput | null {
  if (projection.planningTriageDecision !== "build") {
    return errorOutput(
      "triage_required",
      "Planning requires a durable triage decision of build; record triage first."
    );
  }
  return null;
}

function errorOutput(code: string, message: string, issues?: string[]): ToolExecutionOutput {
  return {
    content: [{ type: "text", text: message }],
    isError: true,
    error: { code, message, ...(issues ? { issues } : {}) },
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function nonEmpty(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}
