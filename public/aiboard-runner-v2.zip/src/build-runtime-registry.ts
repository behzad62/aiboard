import type { BuildRuntime, BuildStepResult } from "./build-runtime.js";
import { emptyUsage } from "./budget-ledger.js";
import type {
  BuildObservabilitySnapshot,
  BuildTranscriptPage,
} from "./build-observability.js";
import type { IntegrationFileSnapshot } from "./integration-manager.js";
import type { NativeBuildUsageProjection } from "./model-usage-projection.js";
import type {
  ProjectHandoffChoice,
  SchedulerEvent,
  SchedulerProjection,
} from "./scheduler-store.js";
import type { ApprovedSourceInputV1 } from "./native-planning-provisioner.js";
import type {
  ExplicitStartRequestV1,
  PlanningExportDocument,
  PlanningReadinessSnapshot,
  ValidatedSourceAmendmentRequest,
} from "./planning-controls.js";

export interface BuildControlPlane {
  projection(runId: string): SchedulerProjection;
  usage(runId: string): NativeBuildUsageProjection;
  observability(runId: string): Promise<BuildObservabilitySnapshot>;
  contextManifests?(runId: string): import("./context-manifest-store.js").ContextManifest[];
  transcript(runId: string, afterSequence?: number): Promise<BuildTranscriptPage>;
  files(runId: string): Promise<IntegrationFileSnapshot>;
  events(runId: string, afterSequence?: number): SchedulerEvent[];
  step(runId: string): Promise<BuildStepResult>;
  runUntilBlocked(runId: string, maxSteps?: number): Promise<BuildStepResult>;
  activate(runId: string): void;
  submitUserGuidance(runId: string, input: UserGuidanceControlInput): Promise<SchedulerProjection>;
  answerArchitectQuestion(runId: string, input: ArchitectQuestionAnswerControlInput): Promise<SchedulerProjection>;
  pause(runId: string, reason: string, idempotencyKey: string): Promise<SchedulerProjection>;
  resume(runId: string, idempotencyKey: string): Promise<SchedulerProjection>;
  continue(runId: string, idempotencyKey: string): Promise<SchedulerProjection>;
  selectArchitectHandoff(
    runId: string,
    runtimeId: string,
    idempotencyKey: string,
    requiredSequence?: number,
  ): Promise<SchedulerProjection>;
  selectVerifierRuntime(
    runId: string,
    runtimeId: string,
    idempotencyKey: string,
    requiredSequence?: number,
  ): Promise<SchedulerProjection>;
  registerPlanningSource(
    runId: string,
    input: { approvedSource: ApprovedSourceInputV1; idempotencyKey: string },
  ): Promise<SchedulerProjection>;
  amendPlanningSource(
    runId: string,
    request: ValidatedSourceAmendmentRequest,
  ): Promise<SchedulerProjection>;
  authorizeExplicitPlanStart(
    runId: string,
    request: ExplicitStartRequestV1,
  ): Promise<SchedulerProjection>;
  setAnswerReview(runId: string, optedIn: boolean, idempotencyKey: string): Promise<SchedulerProjection>;
  planningReadiness(runId: string): PlanningReadinessSnapshot;
  planningSchedule?(runId: string): import("./planning-view-contracts.js").NativePlanningSchedule | undefined;
  planningExport(runId: string): PlanningExportDocument;
  extendRepairCycles(
    runId: string,
    additionalRepairPlans: number,
    idempotencyKey: string,
  ): Promise<SchedulerProjection>;
  selectProjectHandoff(
    runId: string,
    choice: ProjectHandoffChoice,
    idempotencyKey: string
  ): Promise<SchedulerProjection>;
}

export interface UserGuidanceControlInput {
  guidanceId: string;
  text: string;
  version: number;
  idempotencyKey: string;
}

export interface ArchitectQuestionAnswerControlInput {
  questionId: string;
  expectedVersion: number;
  answer: string;
  idempotencyKey: string;
}

export class BuildRuntimeRegistry implements BuildControlPlane {
  private readonly runtimes = new Map<string, BuildRuntime>();
  private readonly pumps = new Map<string, Promise<void>>();

  register(runtime: BuildRuntime): void {
    if (this.runtimes.has(runtime.id)) {
      throw new Error(`Build runtime ${runtime.id} is already registered.`);
    }
    this.runtimes.set(runtime.id, runtime);
  }

  unregister(runId: string): void {
    this.runtimes.delete(runId);
  }

  projection(runId: string): SchedulerProjection {
    return this.require(runId).projection();
  }

  usage(runId: string): NativeBuildUsageProjection {
    this.require(runId);
    return {
      scopeId: runId,
      reservations: {},
      activeSegments: {},
      effective: emptyUsage(),
      lifetime: emptyUsage(),
      window: { index: 1 },
      lastSequence: 0,
      attributedModelReservationCount: 0,
      models: [],
    };
  }

  async observability(runId: string): Promise<BuildObservabilitySnapshot> {
    return {
      runId,
      budget: this.usage(runId),
      toolCallCount: 0,
      agents: [],
      tools: [],
      evidence: [],
      memories: [],
      skills: [],
      processes: [],
      providers: [],
      events: [],
      git: { integrationBranch: "", integrationRevision: "", commits: [] },
      contextManifestCount: 0,
    };
  }

  async transcript(runId: string, afterSequence = 0): Promise<BuildTranscriptPage> {
    this.require(runId);
    return { turns: [], cursor: afterSequence };
  }

  async files(runId: string): Promise<IntegrationFileSnapshot> {
    this.require(runId);
    throw new Error("Revision-backed files require the native Build manager.");
  }

  events(runId: string, afterSequence = 0): SchedulerEvent[] {
    return this.require(runId).events(afterSequence);
  }

  async step(runId: string): Promise<BuildStepResult> {
    return await this.require(runId).step();
  }

  async runUntilBlocked(
    runId: string,
    maxSteps?: number
  ): Promise<BuildStepResult> {
    return await this.require(runId).runUntilBlocked(maxSteps);
  }

  activate(runId: string): void {
    if (this.pumps.has(runId)) return;
    const pump = this.require(runId).runUntilBlocked().then(() => undefined).finally(() => {
      this.pumps.delete(runId);
    });
    this.pumps.set(runId, pump);
    void pump.catch(() => undefined);
  }

  async submitUserGuidance(
    runId: string,
    input: UserGuidanceControlInput
  ): Promise<SchedulerProjection> {
    const projection = this.require(runId).submitUserGuidance(input);
    this.wake(runId);
    return projection;
  }

  async answerArchitectQuestion(
    runId: string,
    input: ArchitectQuestionAnswerControlInput
  ): Promise<SchedulerProjection> {
    const projection = this.require(runId).answerArchitectQuestion(input);
    this.wake(runId);
    return projection;
  }

  async pause(runId: string, reason: string, idempotencyKey: string): Promise<SchedulerProjection> {
    return this.require(runId).pause(reason, idempotencyKey);
  }

  async resume(runId: string, idempotencyKey: string): Promise<SchedulerProjection> {
    return this.require(runId).resume(idempotencyKey);
  }

  async continue(runId: string, idempotencyKey: string): Promise<SchedulerProjection> {
    return this.require(runId).continue(idempotencyKey);
  }

  async selectArchitectHandoff(
    runId: string,
    runtimeId: string,
    idempotencyKey: string,
    requiredSequence?: number,
  ): Promise<SchedulerProjection> {
    return this.require(runId).selectArchitectHandoff(runtimeId, idempotencyKey, requiredSequence);
  }

  async selectVerifierRuntime(
    runId: string,
    runtimeId: string,
    idempotencyKey: string,
    requiredSequence?: number,
  ): Promise<SchedulerProjection> {
    return this.require(runId).selectVerifierRuntime(runtimeId, idempotencyKey, requiredSequence);
  }

  async registerPlanningSource(
    runId: string,
    input: { approvedSource: ApprovedSourceInputV1; idempotencyKey: string },
  ): Promise<SchedulerProjection> {
    return await this.require(runId).registerPlanningSource(input);
  }

  async amendPlanningSource(
    runId: string,
    request: ValidatedSourceAmendmentRequest,
  ): Promise<SchedulerProjection> {
    return await this.require(runId).amendPlanningSource(request);
  }

  async authorizeExplicitPlanStart(
    runId: string,
    request: ExplicitStartRequestV1,
  ): Promise<SchedulerProjection> {
    return await this.require(runId).authorizeExplicitPlanStart(request);
  }

  async setAnswerReview(runId: string, optedIn: boolean, idempotencyKey: string): Promise<SchedulerProjection> {
    return await this.require(runId).setAnswerReview(optedIn, idempotencyKey);
  }

  planningReadiness(runId: string): PlanningReadinessSnapshot {
    return this.require(runId).planningReadiness();
  }

  planningSchedule(runId: string): import("./planning-view-contracts.js").NativePlanningSchedule {
    return this.require(runId).planningSchedule();
  }

  planningExport(runId: string): PlanningExportDocument {
    return this.require(runId).planningExport();
  }

  async extendRepairCycles(
    runId: string,
    additionalRepairPlans: number,
    idempotencyKey: string,
  ): Promise<SchedulerProjection> {
    return this.require(runId).extendRepairCycles(additionalRepairPlans, idempotencyKey);
  }

  async selectProjectHandoff(
    _runId: string,
    _choice: ProjectHandoffChoice,
    _idempotencyKey: string
  ): Promise<SchedulerProjection> {
    throw new Error("Final project handoff requires the native Build manager.");
  }

  private require(runId: string): BuildRuntime {
    const runtime = this.runtimes.get(runId);
    if (!runtime) throw new Error(`Unknown build runtime ${runId}.`);
    return runtime;
  }

  private wake(runId: string): void {
    const active = this.pumps.get(runId);
    if (!active) {
      this.activate(runId);
      return;
    }
    void active.finally(() => this.activate(runId)).catch(() => undefined);
  }
}
