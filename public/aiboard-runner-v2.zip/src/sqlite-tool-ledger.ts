import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";

import type {
  BeginToolInvocation,
  ToolInvocationLedger,
  ToolLedgerDecision,
  ToolLedgerEvent,
  ToolLedgerEventType,
} from "./tool-ledger.js";
import type { ToolResult } from "./agent-contracts.js";

interface EventRow {
  sequence: number;
  invocation_key: string;
  invocation_key_hex: string;
  event_type: ToolLedgerEventType;
  fingerprint: string;
  occurred_at: string;
  payload_json: string | null;
}

export interface SqliteToolLedgerOptions {
  /** Opens an existing durable ledger without schema or journal mutations. */
  readOnly?: boolean;
}

export class SqliteToolLedger implements ToolInvocationLedger {
  private readonly database: DatabaseSync;
  private readonly readOnly: boolean;

  constructor(databasePath: string, options: SqliteToolLedgerOptions = {}) {
    this.readOnly = options.readOnly ?? false;
    if (!this.readOnly) mkdirSync(dirname(databasePath), { recursive: true });
    this.database = new DatabaseSync(databasePath, { readOnly: this.readOnly });
    if (this.readOnly) return;
    this.database.exec(`
      PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS tool_events (
        sequence INTEGER PRIMARY KEY AUTOINCREMENT,
        invocation_key TEXT NOT NULL,
        event_type TEXT NOT NULL,
        fingerprint TEXT NOT NULL,
        occurred_at TEXT NOT NULL,
        payload_json TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_tool_events_key
      ON tool_events(invocation_key, sequence);
    `);
  }

  begin(input: BeginToolInvocation): ToolLedgerDecision {
    this.database.exec("BEGIN IMMEDIATE");
    try {
      const events = this.readRows(input.key);
      if (events.some((event) => event.fingerprint !== input.fingerprint)) {
        this.database.exec("COMMIT");
        return { state: "conflict" };
      }
      const completed = [...events]
        .reverse()
        .find((event) => event.event_type === "tool.completed");
      if (completed) {
        const result = decodeResult(completed);
        this.database.exec("COMMIT");
        return { state: "completed", result };
      }
      if (events.length > 0 && !input.replaySafe) {
        this.database.exec("COMMIT");
        return { state: "in_doubt" };
      }
      this.insert(
        input.key,
        events.length > 0 ? "tool.retry_started" : "tool.started",
        input.fingerprint,
        input.occurredAt,
        JSON.stringify({
          runId: input.runId,
          sessionId: input.sessionId,
          callId: input.callId,
          toolName: input.toolName,
          ...(input.extensionId ? { extensionId: input.extensionId } : {}),
          effect: input.effect,
          access: input.access,
          outsideWorkspace: input.outsideWorkspace,
        })
      );
      this.database.exec("COMMIT");
      return { state: "new" };
    } catch (error) {
      this.database.exec("ROLLBACK");
      throw error;
    }
  }

  complete(
    key: string,
    fingerprint: string,
    result: ToolResult,
    occurredAt: string
  ): void {
    this.database.exec("BEGIN IMMEDIATE");
    try {
      const events = this.readRows(key);
      if (events.some((event) => event.fingerprint !== fingerprint)) {
        throw new Error(`Tool invocation ${key} has a conflicting fingerprint.`);
      }
      if (!events.some((event) => event.event_type === "tool.completed")) {
        this.insert(
          key,
          "tool.completed",
          fingerprint,
          occurredAt,
          JSON.stringify(result)
        );
      }
      this.database.exec("COMMIT");
    } catch (error) {
      this.database.exec("ROLLBACK");
      throw error;
    }
  }

  events(key: string): ToolLedgerEvent[] {
    return decodeEvents(this.readRows(key));
  }

  listRun(runId: string): ToolLedgerEvent[] {
    const rows = (
      this.database
        .prepare(
          `SELECT sequence, invocation_key, event_type, fingerprint,
                  hex(invocation_key) AS invocation_key_hex,
                  occurred_at, payload_json
           FROM tool_events ORDER BY sequence ASC`
        )
        .all() as unknown as EventRow[]
    ).filter((row) => invocationKey(row).startsWith(`${runId}\0`));
    return decodeEvents(rows);
  }

  close(): void {
    this.database.close();
  }

  private readRows(key: string): EventRow[] {
    return this.database
      .prepare(
        `SELECT sequence, invocation_key, event_type, fingerprint,
                hex(invocation_key) AS invocation_key_hex,
                occurred_at, payload_json
         FROM tool_events WHERE invocation_key = ? ORDER BY sequence ASC`
      )
      .all(key) as unknown as EventRow[];
  }

  private insert(
    key: string,
    type: ToolLedgerEventType,
    fingerprint: string,
    occurredAt: string,
    payload: string | null
  ): void {
    this.database
      .prepare(
        `INSERT INTO tool_events (
          invocation_key, event_type, fingerprint, occurred_at, payload_json
        ) VALUES (?, ?, ?, ?, ?)`
      )
      .run(key, type, fingerprint, occurredAt, payload);
  }
}

function decodeEvents(rows: readonly EventRow[]): ToolLedgerEvent[] {
  const extensionIds = new Map<string, string>();
  return rows.map((row) => {
    const key = invocationKey(row);
    const event = decodeEvent(row, extensionIds.get(key));
    if (event.extensionId) extensionIds.set(key, event.extensionId);
    return event;
  });
}

function decodeEvent(
  row: EventRow,
  inheritedExtensionId?: string,
): ToolLedgerEvent {
  const key = invocationKey(row);
  const [runId, sessionId, callId] = key.split("\0");
  let toolName: string | undefined;
  let extensionId = inheritedExtensionId;
  let metadata: Record<string, unknown> | undefined;
  if (row.event_type === "tool.completed") {
    toolName = decodeResult(row).toolName;
  } else if (row.payload_json) {
    try {
      const payload = JSON.parse(row.payload_json) as Record<string, unknown>;
      metadata = payload;
      toolName = typeof payload.toolName === "string" ? payload.toolName : undefined;
      extensionId = validExtensionId(payload.extensionId)
        ? payload.extensionId
        : inheritedExtensionId;
    } catch {
      toolName = undefined;
    }
  }
  return {
    sequence: row.sequence,
    key,
    type: row.event_type,
    fingerprint: row.fingerprint,
    occurredAt: row.occurred_at,
    ...(runId ? { runId } : {}),
    ...(sessionId ? { sessionId } : {}),
    ...(callId ? { callId } : {}),
    ...(toolName ? { toolName } : {}),
    ...(extensionId ? { extensionId } : {}),
    ...(metadata?.effect === "none" ||
    metadata?.effect === "workspace" ||
    metadata?.effect === "external"
      ? { effect: metadata.effect }
      : {}),
    ...(isAccessRequest(metadata?.access)
      ? { access: metadata.access }
      : {}),
    ...(typeof metadata?.outsideWorkspace === "boolean"
      ? { outsideWorkspace: metadata.outsideWorkspace }
      : {}),
    ...(row.event_type === "tool.completed"
      ? { result: decodeResult(row) }
      : {}),
  };
}

function validExtensionId(value: unknown): value is string {
  return typeof value === "string" && /^[a-z][a-z0-9.-]{0,63}$/.test(value);
}

function invocationKey(row: EventRow): string {
  return Buffer.from(row.invocation_key_hex, "hex").toString("utf8");
}

function isAccessRequest(value: unknown): value is import("./agent-contracts.js").ToolAccessRequest {
  return (
    typeof value === "object" &&
    value !== null &&
    !Array.isArray(value) &&
    typeof (value as { capability?: unknown }).capability === "string"
  );
}

function decodeResult(row: EventRow): ToolResult {
  if (!row.payload_json) {
    throw new Error(`Completed tool event ${row.sequence} has no result.`);
  }
  try {
    return JSON.parse(row.payload_json) as ToolResult;
  } catch (error) {
    throw new Error(`Tool event ${row.sequence} contains invalid result JSON.`, {
      cause: error,
    });
  }
}
